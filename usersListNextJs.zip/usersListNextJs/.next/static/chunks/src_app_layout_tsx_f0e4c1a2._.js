(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_layout_tsx_f0e4c1a2._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_layout_tsx_f0e4c1a2._.js",
  "chunks": [
    "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_90e16360._.js",
    "static/chunks/node_modules_next_dist_9a2d5fdb._.js",
    "static/chunks/src_app_globals_b805903d.css"
  ],
  "source": "dynamic"
});
