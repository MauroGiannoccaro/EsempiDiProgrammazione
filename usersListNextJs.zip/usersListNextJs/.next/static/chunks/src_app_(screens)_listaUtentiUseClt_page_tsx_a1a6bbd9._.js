(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_(screens)_listaUtentiUseClt_page_tsx_a1a6bbd9._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_(screens)_listaUtentiUseClt_page_tsx_a1a6bbd9._.js",
  "chunks": [
    "static/chunks/_3d9811c4._.js"
  ],
  "source": "dynamic"
});
