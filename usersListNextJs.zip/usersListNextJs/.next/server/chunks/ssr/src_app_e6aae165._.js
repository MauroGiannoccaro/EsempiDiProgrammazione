module.exports = {

"[project]/src/app/store/FormStore.ts [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "formButtonStyle": (()=>formButtonStyle),
    "formStore": (()=>formStore),
    "formStyle": (()=>formStyle)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zustand$2f$esm$2f$react$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/zustand/esm/react.mjs [app-ssr] (ecmascript)");
;
const formStyle = " flex flex-col gap-4 w-full max-w-md mx-auto bg-white p-6 rounded-lg shadow-md";
const formButtonStyle = "bg-blue-500 text-white px-4 py-2 rounded-md shadow-lg hover:bg-blue-700 transition";
const formStore = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zustand$2f$esm$2f$react$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["create"])((set)=>({
        formData: {
            firstName: '',
            lastName: '',
            email: '',
            phone: '',
            city: '',
            state: ''
        },
        setFormDataFirstStep: (data)=>set((state)=>({
                    formData: {
                        ...state.formData,
                        ...data
                    }
                })),
        setFormDataSecondStep: (data)=>set((state)=>({
                    formData: {
                        ...state.formData,
                        ...data
                    }
                })),
        setFormDataThirdStep: (data)=>set((state)=>({
                    formData: {
                        ...state.formData,
                        ...data
                    }
                }))
    }));
}}),
"[project]/src/app/pages/formPage/thirdStep/actions.ts [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "submitData": (()=>submitData)
});
const submitData = (data)=>{
    const errors = {};
    if (!data.firstName || data.firstName.length < 2) {
        errors.firstName = '❌Il nome deve contenere almeno 2 caratteri';
    }
    if (!data.lastName || data.lastName.length < 2) {
        errors.lastName = '❌Il cognome deve contenere almeno 2 caratteri';
    }
    const emailPattern = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/;
    if (!data.email || !emailPattern.test(data.email)) {
        errors.email = '❌Inserisci un indirizzo email valido';
    }
    const phonePattern = /^\d{10,15}$/;
    if (!data.phone || !phonePattern.test(data.phone)) {
        errors.phone = '❌Il numero di telefono deve essere valido';
    }
    if (!data.city || data.city.length < 2) {
        errors.city = '❌La città deve contenere almeno 2 caratteri';
    }
    if (!data.state || data.state.length < 2) {
        errors.state = '❌Lo stato deve contenere almeno 2 caratteri';
    }
    if (Object.keys(errors).length > 0) {
        return errors;
    }
    return "ok";
};
}}),
"[project]/src/app/pages/formPage/thirdStep/page.tsx [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>ThirdStep)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$hook$2d$form$2f$dist$2f$index$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-hook-form/dist/index.esm.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$store$2f$FormStore$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/app/store/FormStore.ts [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$pages$2f$formPage$2f$thirdStep$2f$actions$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/app/pages/formPage/thirdStep/actions.ts [app-ssr] (ecmascript)");
'use client';
;
;
;
;
;
;
function ThirdStep() {
    const { register, handleSubmit, formState: { errors } } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$hook$2d$form$2f$dist$2f$index$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useForm"])();
    const formData = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$store$2f$FormStore$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["formStore"])((state)=>state.formData);
    const setThirdStep = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$store$2f$FormStore$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["formStore"])((state)=>state.setFormDataThirdStep);
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRouter"])();
    const [serverError, setServerError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(null);
    const onSubmit = async (data)=>{
        setServerError(null); // Reset errori precedenti
        const result = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$pages$2f$formPage$2f$thirdStep$2f$actions$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["submitData"])({
            ...formData,
            ...data
        });
        if (result !== "ok") {
            console.log("Errore dal server:", result);
            const errors = [];
            Object.keys(result).forEach((key)=>{
                if (result[key]) {
                    errors.push(`${key}: ${result[key]}`);
                }
            });
            setServerError(errors);
            return;
        }
        // Se non ci sono errori, procedi con il form
        setThirdStep(data);
        console.log("Dati inviati:", {
            ...formData,
            ...data
        });
        router.push('/pages/formPage/lastPage');
    };
    const onPrev = ()=>{
        router.push('/pages/formPage/secondStep');
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("form", {
        onSubmit: handleSubmit(onSubmit),
        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$store$2f$FormStore$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["formStyle"],
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                ...register('city', {
                    required: "La città è obbligatoria",
                    minLength: {
                        value: 2,
                        message: "Minimo 2 caratteri"
                    }
                }),
                placeholder: "Città",
                className: "border p-2 rounded"
            }, void 0, false, {
                fileName: "[project]/src/app/pages/formPage/thirdStep/page.tsx",
                lineNumber: 54,
                columnNumber: 13
            }, this),
            errors.city && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "text-red-500",
                children: [
                    "❌",
                    errors.city.message
                ]
            }, void 0, true, {
                fileName: "[project]/src/app/pages/formPage/thirdStep/page.tsx",
                lineNumber: 59,
                columnNumber: 29
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                ...register('state', {
                    required: "Lo stato è obbligatorio",
                    minLength: {
                        value: 2,
                        message: "Minimo 2 caratteri"
                    }
                }),
                placeholder: "Stato",
                className: "border p-2 rounded"
            }, void 0, false, {
                fileName: "[project]/src/app/pages/formPage/thirdStep/page.tsx",
                lineNumber: 61,
                columnNumber: 13
            }, this),
            errors.state && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "text-red-500",
                children: [
                    "❌",
                    errors.state.message
                ]
            }, void 0, true, {
                fileName: "[project]/src/app/pages/formPage/thirdStep/page.tsx",
                lineNumber: 66,
                columnNumber: 30
            }, this),
            serverError && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "bg-red-100 p-3 rounded-md",
                children: serverError.map((error, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "text-red-500",
                        children: error
                    }, index, false, {
                        fileName: "[project]/src/app/pages/formPage/thirdStep/page.tsx",
                        lineNumber: 72,
                        columnNumber: 25
                    }, this))
            }, void 0, false, {
                fileName: "[project]/src/app/pages/formPage/thirdStep/page.tsx",
                lineNumber: 70,
                columnNumber: 17
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex justify-between",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        type: "button",
                        onClick: onPrev,
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$store$2f$FormStore$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["formButtonStyle"],
                        children: "Indietro"
                    }, void 0, false, {
                        fileName: "[project]/src/app/pages/formPage/thirdStep/page.tsx",
                        lineNumber: 78,
                        columnNumber: 17
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        type: "submit",
                        className: "bg-green-500 text-white px-4 py-2 rounded-md shadow-lg hover:bg-green-700 transition",
                        children: "Invia"
                    }, void 0, false, {
                        fileName: "[project]/src/app/pages/formPage/thirdStep/page.tsx",
                        lineNumber: 79,
                        columnNumber: 17
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/app/pages/formPage/thirdStep/page.tsx",
                lineNumber: 77,
                columnNumber: 13
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/app/pages/formPage/thirdStep/page.tsx",
        lineNumber: 53,
        columnNumber: 9
    }, this);
}
}}),

};

//# sourceMappingURL=src_app_e6aae165._.js.map