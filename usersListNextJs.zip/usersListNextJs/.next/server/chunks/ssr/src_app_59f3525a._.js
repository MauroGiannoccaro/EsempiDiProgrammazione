module.exports = {

"[project]/src/app/store/FormStore.ts [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "formButtonStyle": (()=>formButtonStyle),
    "formStore": (()=>formStore),
    "formStyle": (()=>formStyle)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zustand$2f$esm$2f$react$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/zustand/esm/react.mjs [app-ssr] (ecmascript)");
;
const formStyle = " flex flex-col gap-4 w-full max-w-md mx-auto bg-white p-6 rounded-lg shadow-md";
const formButtonStyle = "bg-blue-500 text-white px-4 py-2 rounded-md shadow-lg hover:bg-blue-700 transition";
const formStore = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zustand$2f$esm$2f$react$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["create"])((set)=>({
        formData: {
            firstName: '',
            lastName: '',
            email: '',
            phone: '',
            city: '',
            state: ''
        },
        setFormDataFirstStep: (data)=>set((state)=>({
                    formData: {
                        ...state.formData,
                        ...data
                    }
                })),
        setFormDataSecondStep: (data)=>set((state)=>({
                    formData: {
                        ...state.formData,
                        ...data
                    }
                })),
        setFormDataThirdStep: (data)=>set((state)=>({
                    formData: {
                        ...state.formData,
                        ...data
                    }
                }))
    }));
}}),
"[project]/src/app/pages/formPage/firstStep/page.tsx [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$hook$2d$form$2f$dist$2f$index$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-hook-form/dist/index.esm.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$store$2f$FormStore$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/app/store/FormStore.ts [app-ssr] (ecmascript)");
'use client';
;
;
;
;
//controllo d'errore volutamente su server alla fine
function FirstStep() {
    const { register, handleSubmit } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$hook$2d$form$2f$dist$2f$index$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useForm"])();
    const setFirstStep = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$store$2f$FormStore$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["formStore"])((state)=>state.setFormDataFirstStep);
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRouter"])();
    const onNext = (data)=>{
        setFirstStep({
            firstName: data.firstName,
            lastName: data.lastName
        });
        router.push('/pages/formPage/secondStep');
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("form", {
        onSubmit: handleSubmit(onNext),
        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$store$2f$FormStore$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["formStyle"],
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                ...register('firstName', {
                    required: true
                }),
                placeholder: "Nome",
                className: "border p-2 rounded"
            }, void 0, false, {
                fileName: "[project]/src/app/pages/formPage/firstStep/page.tsx",
                lineNumber: 24,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                ...register('lastName', {
                    required: true
                }),
                placeholder: "Cognome",
                className: "border p-2 rounded"
            }, void 0, false, {
                fileName: "[project]/src/app/pages/formPage/firstStep/page.tsx",
                lineNumber: 25,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                type: "submit",
                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$store$2f$FormStore$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["formButtonStyle"],
                children: "Avanti"
            }, void 0, false, {
                fileName: "[project]/src/app/pages/formPage/firstStep/page.tsx",
                lineNumber: 26,
                columnNumber: 13
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/app/pages/formPage/firstStep/page.tsx",
        lineNumber: 23,
        columnNumber: 9
    }, this);
}
const __TURBOPACK__default__export__ = FirstStep;
}}),

};

//# sourceMappingURL=src_app_59f3525a._.js.map