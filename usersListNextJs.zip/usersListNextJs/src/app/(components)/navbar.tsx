import Link from "next/link";
import About from "../(screens)/about/page";
import Contacts from "../(screens)/contacts/page";

export default function Navbar() {
 
  const cardStyle= "flex items-center justify-center h-full bg-stone-600 text-teal-50 p-2 rounded-md shadow-xl";

  return (
    <div className="flex flex-row items-center p-[10px] border-amber-600 bg-gray-500 h-[85px] gap-[20px] justify-stretch align-stretch">
      <div className="flex items-center justify-center h-full bg-stone-600 text-teal-50 p-2 rounded-md ">
        <Link href="/listaUtenti">Lista Utenti Random Server Side </Link>
      </div>
      <div className={cardStyle}>
        <Link href="/listaUtentiUseClt">Lista Utenti Random Client Side</Link>
      </div>
      <div className={cardStyle}>
        <Link href="/listaUtentiScp">Lista Utenti Random Single Page</Link>
      </div>
      <div className={cardStyle}>
      <Link href="/about">about</Link>
      </div>
      <div className={cardStyle}>
      <Link href="/contacts">contact</Link>
      </div>
    </div>
  );
}
