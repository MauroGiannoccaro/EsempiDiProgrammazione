export default function JsonLd() {
    return (
        <script
            type="application/ld+json"
            dangerouslySetInnerHTML={{
                __html: JSON.stringify({
                    "@context": "https://schema.org",
                    "@type": "UsersApp",
                    url: "https://www.example.com",
                    name: "Example Website",
                    description: "A sample website for demonstration purposes.",
                    publisher: {
                        "@type": "Organization",
                        name: "Example Organization",
                        url: "https://www.example.org",
                    },
                }),
            }}
        />
    );
}