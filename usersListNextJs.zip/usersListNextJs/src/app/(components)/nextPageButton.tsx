"use client";

import { fetchSsideStore } from "@/app/store/store";
import { useRouter } from "next/navigation";
import { use, useState } from "react";
import { set } from "react-hook-form";

export default function NextPageButton({ nextPage }: { nextPage: number }) {
    const router = useRouter();
    const [currentPage, setCurrentPage] = useState(1);

    // Funzione per resettare lo store e navigare alla pagina successiva
    const handleNextPage = () => {
        setCurrentPage((page)=> page=currentPage+1);
        // fetchSsideStore.setState({ users: [] }); // Reset dello store
        console.log("users", fetchSsideStore.getState().users.length); // Log dello stato dello store
        router.push(`?page=${currentPage+1}`); // Navigazione alla pagina successiva
        // fetchSsideStore.setState({ fetchOn: false }); // Imposta fetchOn su true        
    };

    return (
        <div className="flex flex-row items-center gap-3 justify-center mt-4">
            <button
                onClick={handleNextPage}
                className="border-x-orange-700 w-2xs shadow-md bg-amber-100 shadow-amber-400 h-7 mt-4 ml-9.5"
            >
                Next
            </button>
            <div>
                La Pagina corrente è: {currentPage}
            </div>
        </div>
    );
}
