'use client';

import { useRouter } from 'next/navigation';
import { fetchSsideStore } from '../store/store';

interface ButtonProps {
  label: string;
}

export default function Button({ label }: ButtonProps) {
  const router = useRouter();

  const handleClick = () => {
   fetchSsideStore.setState({ users: [] });
   fetchSsideStore.setState({ fetchOn: true });
   router.back();
  };

  return (
    <button
      onClick={handleClick}
      className={`bg-blue-500 text-white px-4 py-2 rounded-md shadow-md hover:bg-blue-700 transition mt-2`}
    >
      {label}
    </button>
  );
}
