export default function NotFound() {
    return (
      <div style={{ textAlign: "center", padding: "50px" }}>
        <h1>404 - Pagina non trovata</h1>
        <p>Ops! La pagina che stai cercando non esiste.</p>
        <a href="/" style={{ color: "blue", textDecoration: "underline" }}>Torna alla Home</a>
      </div>
    );
  }
  