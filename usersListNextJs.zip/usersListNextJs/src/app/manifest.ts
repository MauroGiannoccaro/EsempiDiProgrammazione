export default function manifest() {
    return {
        name: 'Next.js App',
        short_name: 'Next.js',
        description: 'A Next.js app with a manifest file.',
        start_url: '/',
        display: 'standalone',
        theme_color: '#ffffff',
        background_color: '#ffffff',
        
    };
}