// app/context/UserContext.tsx
"use client";

import React, { createContext, useContext, useState, ReactNode } from "react";

// Definisci il tipo dello stato che vuoi gestire nel contesto
interface User {
  name: string;
  email: string;
}

interface UserContextType {
  user: User | null;
  setUser: (user: User) => void;
}

// Crea il contesto con valori di default
const UserContext = createContext<UserContextType | undefined>(undefined);

// Crea il provider per il contesto
export const UserProvider = ({ children }: { children: ReactNode }) => {
  const [user, setUser] = useState<User | null>(null);

  return (
    <UserContext.Provider value={{ user, setUser }}>
      {children}
    </UserContext.Provider>
  );
};

// Crea un hook personalizzato per usare il contesto facilmente
export const useUserContext = (): UserContextType => {
  const context = useContext(UserContext);
  if (!context) {
    throw new Error("useUserContext must be used within a UserProvider");
  }
  return context;
};
