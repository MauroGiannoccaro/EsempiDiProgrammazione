"use client";

import { useEffect } from "react";
import { usePageStore } from "@/app/store/pageStore";
import { useSearchParams } from "next/navigation";

export default function PageUpdater() {
  const { setPage } = usePageStore();  // Funzione per aggiornare la pagina nello store
  const searchParams = useSearchParams();  

  useEffect(() => {
    
    const page = searchParams.get("page");
    console.log("Pagina attuale (Client):", page);
    if (page) {
      setPage(parseInt(page +1, 10));  
    }
  }, [searchParams, setPage]);  // Rileva i cambiamenti nei parametri di ricerca

  return null; 
}
