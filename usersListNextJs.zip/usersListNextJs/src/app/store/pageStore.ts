"use client"; 

import { create } from "zustand";

interface PageState {
  page: number;
  setPage: (newPage: number) => void;
}

export const usePageStore = create<PageState>((set, get) => ({
  page: 1, 
  setPage: (newPage) => set({ page: newPage }), 
}));
