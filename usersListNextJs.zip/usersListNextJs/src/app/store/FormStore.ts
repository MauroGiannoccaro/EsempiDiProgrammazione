import { create } from 'zustand';

export const formStyle =" flex flex-col gap-4 w-full max-w-md mx-auto bg-white p-6 rounded-lg shadow-md";
export const formButtonStyle = "bg-blue-500 text-white px-4 py-2 rounded-md shadow-lg hover:bg-blue-700 transition";

export interface FormData {
    formData: {
        firstName: string;
        lastName: string;
        email: string;
        phone: string;
        city: string;
        state: string;
    };
    setFormDataFirstStep: (data: Partial<FormData["formData"]>) => void;
    setFormDataSecondStep: (data: Partial<FormData["formData"]>) => void;
    setFormDataThirdStep: (data: Partial<FormData["formData"]>) => void;
}

export const formStore = create<FormData>((set) => ({
    formData: {
        firstName: '',
        lastName: '',
        email: '',
        phone: '',
        city: '',
        state: '',
    },
    setFormDataFirstStep: (data) => set((state) => ({
        formData: { ...state.formData, ...data }
    })),
    setFormDataSecondStep: (data) => set((state) => ({
        formData: { ...state.formData, ...data }
    })),
    setFormDataThirdStep: (data) => set((state) => ({
        formData: { ...state.formData, ...data }
    })),
}));
