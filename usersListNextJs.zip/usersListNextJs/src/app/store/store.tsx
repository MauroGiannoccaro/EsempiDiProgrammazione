import { create } from "zustand";
import { Users } from "../type/types";

interface fetchStore {
  users: Users[];
  setUsers: (users: Users[]) => void;
  id: string | null;
  setId: (id: string | null) => void;
  fetchOn: boolean
}

interface UserStore {
  users: Users[];
  selectedUser: Users | null;
  loading: boolean;
  error: string | null;
  currentPage: number;
  fetchUsers: (page: number) => Promise<void>;
  setUsers: (users: Users[]) => void;
  setSelectedUser: (user: Users) => void;
  setLoading: (loading: boolean) => void;
  setError: (error: string | null) => void;
}

export const fetchSsideStore = create<fetchStore>((set, get) => ({
  users: [],
  setUsers: (users: Users[]) => set({ users }),
  id: "",
  setId: (id: string | null) => set({ id }),
  fetchOn: false,
}));
  
export const fetchUsersStore = create<UserStore>((set) => ({
  users: [],
  selectedUser: null,
  loading: false,
  error: null,
  currentPage: 1,

  fetchUsers: async (page: number) => {
    try {
      const response = await fetch(`https://randomuser.me/api/?page=${page}&results=10`);
      const data = await response.json();
      set({ users: data.results });
    } catch (error) {
      set({ error: "Errore durante il recupero degli utenti" });
    }
  },

  setUsers: (users: Users[]) => set({ users }),
  setSelectedUser: (user: Users) => set({ selectedUser: user }),
  setLoading: (loading: boolean) => set({ loading }),
  setError: (error: string | null) => set({ error }),
}));
