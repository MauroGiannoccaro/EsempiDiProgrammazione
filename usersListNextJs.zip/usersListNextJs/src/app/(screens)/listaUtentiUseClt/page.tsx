import React from 'react'
import UserSlugClt from '../(components)/usersListClt/page'

function listaUtentiUseClt() {
  return (
    <div>
      <UserSlugClt></UserSlugClt>
    </div>
  )
}

export default listaUtentiUseClt
