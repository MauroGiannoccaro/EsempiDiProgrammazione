"use client";

import { useEffect } from "react";
import { useStore } from "zustand";

import { Users } from "@/app/type/types";
import { useRouter } from "next/navigation";
import { fetchUsersStore } from "@/app/store/store";

export default function UserSlug() {
  const selectedUser = useStore(fetchUsersStore, (state) => state.selectedUser);
  const router = useRouter();

  return (
    <div className="p-6">
      {selectedUser ? (
        <div className="flex flex-col gap-4 bg-gray-100 p-6 rounded-lg shadow-lg">
          <h1 className="text-2xl font-bold">Dettagli Utente</h1>
          <p className="text-lg">Nome: {selectedUser.name.first} {selectedUser.name.last}</p>
          <p className="text-lg">Email: {selectedUser.email}</p>
          <p className="text-lg">Telefono: {selectedUser.phone}</p>
          <p className="text-lg">
            Indirizzo: {selectedUser.location.street.name} {selectedUser.location.street.number}, 
            {selectedUser.location.city}, {selectedUser.location.state}
          </p>
          <p className="text-lg">Data di Nascita: {new Date(selectedUser.dob.date).toLocaleDateString()}</p>
        </div>
      ) : (
        <div className="flex flex-col gap-4">
          <h1 className="text-2xl font-bold">Nessun utente selezionato</h1>
        </div>
      )}

      <div className="mt-4">
        <button 
          onClick={() => router.back()} 
          className="bg-blue-500 text-white px-4 py-2 rounded-lg shadow-md hover:bg-blue-600 transition-all"
        >
          Torna Indietro
        </button>
      </div>
    </div>
  );
}
