import React from 'react'
import UserSlug from '../(components)/usersSlug/page'
import { usePageStore } from '../../store/pageStore'

function Contacts() {
  return (
    <div>contacts
       
    </div>
    
  )
}

export default Contacts