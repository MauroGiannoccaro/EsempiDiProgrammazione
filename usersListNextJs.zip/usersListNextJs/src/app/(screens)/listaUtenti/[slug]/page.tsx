import { headers } from "next/headers";
import { Users } from "@/app/type/types";
import { notFound } from "next/navigation";
import Link from "next/link";
import Button from "@/app/(components)/backPageButton";

type PageProps = {
  params: Promise<{ id: string }>
  searchParams: Promise<{ [key: string]: string | string[] | undefined }>
}

export default async function UserDetailsPage({ params, searchParams }: PageProps) {
   const resolvedSearchParams = await searchParams;
   if (!resolvedSearchParams.userData) return notFound();

  const userData = Array.isArray(resolvedSearchParams.userData) ? resolvedSearchParams.userData[0] : resolvedSearchParams.userData;
  const user: Users = JSON.parse(userData);
  // const headersList = await headers();
  // const referer = headersList.get("referer") || "/listaUtenti";

  return (
    <div className="p-6 mx-auto max-w-2xl bg-white rounded-lg shadow-md">
      <h1>Dettagli Utente</h1>
      <div className="flex flex-col gap-4 bg-gray-100 p-6 rounded-lg shadow-lg">
        <img src={user.picture.thumbnail} alt={user.name.first} className="rounded-full w-24 h-24 mb-4" />
        <p className="text-xl font-semibold">{user.name.first} {user.name.last}</p>
        <p>Email: {user.email}</p>
        <p>Telefono: {user.phone}</p>
        <p>Indirizzo: {user.location?.city}, {user.location?.state}</p>
        <p>Data di Nascita: {new Date(user.dob?.date).toLocaleDateString()}</p>
      </div> 

      {/* Pulsante "Torna Indietro" senza onClick */}
      {/* <Link href={referer}>
        <button className="mt-4 bg-blue-500 text-white px-4 py-2 rounded-md shadow-md hover:bg-blue-700 transition">
          Torna Indietro
        </button>
      </Link> */}
      <Button label="Torna Indietro" />
    </div>
  );
}
