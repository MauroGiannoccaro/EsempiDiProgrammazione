import UserSlug from '@/app/(screens)/(components)/usersSlug/page'
import React from 'react'
import UserSlugClt from '../(components)/usersListClt/page'
type PageProps = {
  params: Promise<{ id: string }>
  searchParams: Promise<{ [key: string]: string | string[] | undefined }>
}
function UsersList({ searchParams }: PageProps) {
  return (
    <div>
      <UserSlug searchParams={{
        page: undefined,
      }}></UserSlug>
    </div>
  )
}
export default UsersList