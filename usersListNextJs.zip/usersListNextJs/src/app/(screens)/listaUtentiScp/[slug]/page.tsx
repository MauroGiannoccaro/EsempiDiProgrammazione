"use client"; 
import Link from "next/link";
import { useSearchParams } from "next/navigation";

export default function UserDetail() {
  const searchParams = useSearchParams();
  const name = searchParams.get("name");
  const email = searchParams.get("email");
  const picture = searchParams.get("picture");

  return (
    <div className="max-w-md mx-auto mt-10 p-6 bg-white shadow-lg rounded-lg">
      <img className="w-24 h-24 rounded-full mx-auto" src={picture || ""} alt={name || "Utente"} />
      <h1 className="text-xl text-center mt-4">{name}</h1>
      <p className="text-center text-gray-600">{email}</p>

      <div className="mt-4 text-center">
        <Link href="/listaUtenti" className="text-blue-500 underline">Torna alla lista</Link>
      </div>
    </div>
  );
} 