import React from 'react'
import UsersPage from '../(components)/users/pages'



function page() {
  return (
    <div>
        <UsersPage></UsersPage> 
    </div>
  )
}

export default page
