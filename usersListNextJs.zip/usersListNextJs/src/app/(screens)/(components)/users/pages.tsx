import { Users } from "@/app/type/types";

export default async function UsersPage() {
    let users: Users[] = [];

    try {
        const response = await fetch("http://localhost:3000/api/get", {
            cache: "no-store",
        });

        if (!response.ok) {
            throw new Error("Errore nella richiesta");
        }

        users = await response.json();
    } catch (error) {
        console.error("Errore nel caricamento utenti:", error);
    }
    console.log(users);
    return (
        <div className="flex flex-col overflow-x-auto h-[550px]">  
            <h1>Lista Utenti</h1><br />
            <div className="flex flex-wrap gap-4 items-stretch justify-start ">
                {users.length > 0 ? (
                    users.map((user) => (
                        <div 
                            key={user.login.uuid} 
                            className="basis-1/4 bg-stone-600 p-4 rounded-md text-amber-50 shadow-md shadow-amber-600"
                        >
                            <img 
                                src={user.picture.thumbnail} 
                                alt={user.name.first} 
                                className="w-full h-auto mb-2 rounded-full" 
                            />
                            <p>{user.name.first} {user.name.last}</p> 
                            <p>{user.email}</p>
                        </div>
                    ))
                ) : (
                    <div>
                        <p>Errore o nessun utente trovato.</p>
                    </div>
                )}
            </div>
        </div>
    );
}
