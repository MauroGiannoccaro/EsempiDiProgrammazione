
import NextPageButton from "@/app/(components)/nextPageButton";
import { fetchSsideStore } from "@/app/store/store";
import { Users } from "@/app/type/types";
import next from "next";
import Link from "next/link";

export default async function UserSlug({ searchParams }: { searchParams: { page?: string } }) {
  const currentPage = searchParams?.page ? parseInt(searchParams.page, 10) : 1;
  const resolvedSearchParams = await searchParams;
  const nextPage = currentPage + 1;

  // Controlla se ci sono utenti nello store
  let users: Users[] = fetchSsideStore.getState().users || [];
  console.log("users", users.length, fetchSsideStore.getState().fetchOn);

  if (!fetchSsideStore.getState().fetchOn) {
    const response = await fetch(`http://localhost:3000/api/getUsers?page=${currentPage}`, {
      cache: "no-store",
    });

    if (!response.ok) {
      throw new Error("Errore nel recupero degli utenti");
    }

    users = await response.json();
    fetchSsideStore.setState({ users });
    console.log("users", fetchSsideStore.getState().users);
  }

  return (
    <div className="flex flex-wrap items-stretch justify-stretch overflow-x-auto overflow-y-auto h-[550px]">
      <h1>Lista Utenti</h1>

      <div className="flex flex-wrap gap-2 items-stretch justify-stretch">
        {users.map((user) => (
          <Link
            key={user.login.uuid}
            href={{
              pathname: `/listaUtenti/${user.login.uuid}`,
              query: { userData: JSON.stringify(user) }  // Passa i dati come query param
            }}
          >
            <div className="basis-1/3 flex-grow-1 flex-1 m-2 bg-stone-600 p-2 rounded-md text-amber-50 shadow-md shadow-amber-600">
              <img className="shadow-amber-600" src={user.picture.thumbnail} alt={user.name.first} />
              <p>{user.name.first} {user.name.last}</p>
              <p>{user.email}</p>
            </div>
          </Link>
        ))}
      </div>
      <NextPageButton nextPage={nextPage} />
    </div>
  );
}