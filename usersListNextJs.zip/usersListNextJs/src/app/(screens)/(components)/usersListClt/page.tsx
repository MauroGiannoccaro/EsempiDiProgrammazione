"use client";

import { useEffect, useState } from "react";
import { Users } from "@/app/type/types";
import Link from "next/link";
import { useStore } from "zustand"; 
import { fetchUsersStore } from "../../../store/store";

export default function UserSlugClt() {
  const [currentPage, setCurrentPage] = useState(1);
  const setLoading = fetchUsersStore((state) => state.setLoading);
  const loading = useStore(fetchUsersStore, (state) => state.loading); 
  const error = useStore(fetchUsersStore, (state) => state.error);
  const setError = fetchUsersStore((state) => state.setError); 
  const users = useStore(fetchUsersStore, (state) => state.users);
  const setUsers = fetchUsersStore((state) => state.setUsers);
  const setSelectedUser = fetchUsersStore((state) => state.setSelectedUser);

  useEffect(() => {
    if (users.length == 0) {
      const fetchUsers = async () => {
        console.log("Sto facendo la fetch", currentPage);
        setLoading(true);
        setError(null);
        await fetchUsersStore.getState().fetchUsers(currentPage);
        setLoading(false);
      };
      fetchUsers().catch((err) => {
        setError(err.message);
        setLoading(false);
      });
    }
  }, [currentPage]);

  const goToPage = (page: number) => {
    setUsers([]); 
    setCurrentPage(page);
  };

  function onHandle(user: Users) {
    setSelectedUser(user);
  }

  return (
    <div className="flex flex-col overflow-x-auto overflow-y-auto h-[550px] p-4">
      <h1>Lista Utenti - Pagina {currentPage}</h1>

      {loading && <p>Caricamento utenti...</p>}
      {error && <p className="text-red-500">{error}</p>}

      <div className="flex flex-wrap gap-2 items-stretch justify-stretch">
        {users.map((user: Users) => (
          <div key={user.login.uuid} className="basis-1/3 flex-1 m-2 bg-stone-600 p-2 rounded-md text-amber-50 shadow-md shadow-amber-600">
            <img className="shadow-amber-600" src={user.picture.thumbnail} alt={user.name.first} />
            <p>{user.name.first} {user.name.last}</p>
            <p>{user.email}</p>
            {/* Usa Link per evitare un refresh completo */}
            <Link href={`/listaUtentiUseClt/${user.login.uuid}`} onClick={() => onHandle(user)}>
              <span className="text-blue-500 underline cursor-pointer">Dettagli</span>
            </Link>
          </div>
        ))}
      </div>

      <div className="mt-4">
        <button
          onClick={() => goToPage(currentPage + 1)}
          className="border-x-orange-700 w-2xs bg-amber-100 shadow-amber-400 h-7 mt-4 ml-9.5"
        >
          Next
        </button>
      </div>
    </div>
  );
}
