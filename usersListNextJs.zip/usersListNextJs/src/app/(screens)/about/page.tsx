import JsonLd from '@/app/(components)/JsonLd'
import React from 'react'

function About() {
  return (
    <div>
      about
      <JsonLd />
    </div>
  )
}

export default About
