import { NextRequest, NextResponse } from 'next/server';

const documentData = {
  introduzione: {
    title: "Introduzione alla documentazione",
    content: "Benvenuto nella documentazione! Qui troverai tutte le informazioni necessarie per utilizzare il nostro sistema.",
  },
  installazione: {
    title: "Guida all'installazione",
    content: "Per installare il sistema, segui i seguenti passi: 1) Scarica il pacchetto, 2) Estrai i file, 3) Esegui il setup.",
  },
  configurazione: {
    title: "Configurazione avanzata",
    content: "In questa sezione, esplorerai la configurazione avanzata del sistema, inclusi i parametri personalizzati.",
  },
};

export async function GET(request: NextRequest) {
  // Estrai il parametro 'slug' dalla URL (usando NextRequest)
  const { pathname } = request.nextUrl;
  const slug = pathname.split('/').pop();  // Ottieni l'ultimo segmento della path come slug

  const document = documentData[slug as keyof typeof documentData];

  if (document) {
    return NextResponse.json(document);
  } else {
    return NextResponse.json({ message: "Documento non trovato" }, { status: 404 });
  }
}
