import { NextRequest, NextResponse } from "next/server";

export async function GET(request: NextRequest) {
  try {
    const page = request.nextUrl.searchParams.get("page") || "1"; 
    const resultsPerPage = 10; 
    const offset = (parseInt(page) - 1) * resultsPerPage;

    const response = await fetch(`https://randomuser.me/api/?results=${resultsPerPage}&page=${page}`, {
      cache: "no-store",
    });

    if (!response.ok) {
      throw new Error("Errore nella fetch esterna");
    }

    const data = await response.json();
   
    return NextResponse.json(data.results); 
  } catch (error) {
    return NextResponse.json({ error: "Errore nell'API" }, { status: 500 });
  }
}
