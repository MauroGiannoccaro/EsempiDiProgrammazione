import { NextRequest, NextResponse } from "next/server";

export async function GET(request: NextRequest) {
  // Estrai il parametro 'slug' dalla URL
  // const slug = request.nextUrl.pathname.split('/').pop();  // Ottieni l'ultimo segmento della path come slug

  const response = await fetch("https://randomuser.me/api/?results=10", {
    cache: "no-store",
  });

  const data = await response.json();
 
  return NextResponse.json(data.results);
}
