export default function robots() {
  return {
    rules: {
      userAgent: '*',
      allow: '/',
      disallow: '/private/',
    },
    sitemap: 'https://nextjs-sitemap-test-one.vercel.app/sitemap.xml',
  };
}