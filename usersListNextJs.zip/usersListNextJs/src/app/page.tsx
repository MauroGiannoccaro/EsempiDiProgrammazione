import "./styles/home.css"

export default function Home() {
  return (
    <div className="container">
      <div className="flex flex-col gap-4 items-center justify-center h-full bg-amber-600 text-white w-[600px] h-[100px] mx-80 rounded-lg shadow-lg ">
        <h1>Esercitazione next.js, Tailwind,</h1>
        <h1> Zustand, server action, useForm, middleware:</h1>
        <h2>------------------------</h2>
        <h2>Liste Utenti Client Side</h2>
        <h2>Liste Utenti Server Side</h2>
        <h2>Documents and Blog slug</h2>
        <h2>Form Page on 3 Steps and Server Action Validate</h2>
      </div>
    </div>

  );
}
