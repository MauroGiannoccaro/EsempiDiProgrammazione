import { MetadataRoute } from "next";

export default function sitemap() : Promise<MetadataRoute.Sitemap> {
  const baseUrl = "https://nextjs-sitemap-test-one.vercel.app";

  const staticRoutes = [
    "/",
    "/about",
    "/pages/blog",
    "/listaUtenti",
  ].map((route) => ({
    url: `${baseUrl}${route}`,
    lastModified: new Date(),
  }))

  const blogPosts = [
    { slug: "post-1", date: "2023-01-01" },
    { slug: "post-2", date: "2023-02-01" },
  ];

  const blogRoutes = blogPosts.map((post) => ({
    url: `${baseUrl}/pages/blog/${post.slug}`,
    lastModified: new Date(post.date),
  }))

  return Promise.resolve([...staticRoutes, ...blogRoutes]);
}