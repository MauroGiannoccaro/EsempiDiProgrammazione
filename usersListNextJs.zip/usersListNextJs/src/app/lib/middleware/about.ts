import { headers } from 'next/headers';
import { NextResponse } from 'next/server';
export function aboutMiddleware(request: Request) {
    if (request.url.includes('/about')) {
        console.log('About middleware triggered!');
        const response = NextResponse.next();
        response.headers.set('X-Custom-Header', 'true');
        return response;
    }
}