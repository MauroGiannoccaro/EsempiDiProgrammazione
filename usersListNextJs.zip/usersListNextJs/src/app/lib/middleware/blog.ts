import { headers } from 'next/headers';
import { NextResponse } from 'next/server';
export function blogMiddleware(request: Request) {
    if (request.url.includes('/pages/blog')) {
        console.log('Blog middleware triggered!');
        const response = NextResponse.next();
        response.headers.set('X-Custom-Header', 'true');
        return response;
    }
}