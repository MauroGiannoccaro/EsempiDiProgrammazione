import Link from "next/link";
import React from "react";

function Pages() {

  const linkPages="bg-amber-950 w-[300px] p-2 rounded-md text-center shadow-xl";

  return (
    <div className="bg-amber-800 text-white p-6 min-h-screen flex flex-col order-last ml-60 -mt-5">
      <h1 className="text-2xl font-bold mb-4">Pages:</h1>
      
      <div className="space-y-3">
        <div className={linkPages}>
          <Link href="/pages/blog" className="hover:underline">
            Blog
          </Link>
        </div>
        <div className={linkPages}>
          <Link href="/pages/documents" className="hover:underline">
            Documents slug
          </Link>
        </div>
        <div className={linkPages}>
          <Link href="/pages/formPage" className="hover:underline">
            Form Page on 3 Steps and Server Action Validate
          </Link>
        </div>
      </div>
    </div>
  );
}

export default Pages;
