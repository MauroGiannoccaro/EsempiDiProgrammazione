'use client';

import { set, useForm } from 'react-hook-form';
import { formButtonStyle, formStore, formStyle } from '@/app/store/FormStore';
import { useRouter } from 'next/navigation';

//controllo d'errore volutamente su server alla fine

function secondStep() {
    const { register, handleSubmit } = useForm();
    const setSecondStep = formStore((state) => state.setFormDataSecondStep);
    const router = useRouter();

    const onNext = (data: any) => {
        setSecondStep({
            email: data.email,
            phone: data.phone,
        });
        router.push('/pages/formPage/thirdStep');
    };

    const onPrev = () => {
        router.push('/pages/formPage/firstStep');
    };

    return (
        <form onSubmit={handleSubmit(onNext)} className={formStyle}>
            <input type="email" {...register('email', { required: true })} placeholder="Email" className="border p-2 rounded" />
            <input type="tel" {...register('phone', { required: true })} placeholder="Telefono" className="border p-2 rounded" />
            <div className="flex justify-between">
                <button type="button" onClick={onPrev} className={formButtonStyle}>Indietro</button>
                <button type="submit" className={formButtonStyle}>Avanti</button>
            </div>
        </form>
    );
}
export default secondStep;