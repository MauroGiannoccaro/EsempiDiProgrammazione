interface FormData {
    firstName: string;
    lastName: string;
    email: string;
    phone: string;
    city: string;
    state: string;
  }
  
  export const submitData = (data: FormData) => {
    const errors: { [key: string]: string } = {};
  
    if (!data.firstName || data.firstName.length < 2) {
      errors.firstName = '❌Il nome deve contenere almeno 2 caratteri';
    }
  
    if (!data.lastName || data.lastName.length < 2) {
      errors.lastName = '❌Il cognome deve contenere almeno 2 caratteri';
    }

    const emailPattern = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/;
    if (!data.email || !emailPattern.test(data.email)) {
      errors.email = '❌Inserisci un indirizzo email valido';
    }
  
    const phonePattern = /^\d{10,15}$/;
    if (!data.phone || !phonePattern.test(data.phone)) {
      errors.phone = '❌Il numero di telefono deve essere valido';
    }

    if (!data.city || data.city.length < 2) {
      errors.city = '❌La città deve contenere almeno 2 caratteri';
    }

    if (!data.state || data.state.length < 2) {
      errors.state = '❌Lo stato deve contenere almeno 2 caratteri';
    }
    if (Object.keys(errors).length > 0) {
    return errors;
    }
    return "ok"
  };
  