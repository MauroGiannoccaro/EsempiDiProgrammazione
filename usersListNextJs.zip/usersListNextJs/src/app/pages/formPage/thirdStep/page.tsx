'use client';

import { useForm } from 'react-hook-form';
import { useRouter } from 'next/navigation';
import { formButtonStyle, formStore, formStyle } from '@/app/store/FormStore';
import { useState } from 'react';
import { submitData } from './actions';

interface ThirdStepFormData {
  city: string;
  state: string;
}

// controllo su server e client

export default function ThirdStep() {
    const { register, handleSubmit, formState: { errors } } = useForm<ThirdStepFormData>();
    const formData = formStore((state) => state.formData);
    const setThirdStep = formStore((state) => state.setFormDataThirdStep);
    const router = useRouter();
    const [serverError, setServerError] = useState<string[] | null>(null);

    const onSubmit = async (data: ThirdStepFormData) => {
        setServerError(null); // Reset errori precedenti

        const result = await submitData({ ...formData, ...data });

        if (result !== "ok") {
            console.log("Errore dal server:", result);

            const errors: string[] = [];
            Object.keys(result).forEach((key) => {
                if (result[key]) {
                    errors.push(`${key}: ${result[key]}`);
                }
            });

            setServerError(errors);
            return;
        }

        // Se non ci sono errori, procedi con il form
        setThirdStep(data);
        console.log("Dati inviati:", { ...formData, ...data });
        router.push('/pages/formPage/lastPage');
    };

    const onPrev = () => {
        router.push('/pages/formPage/secondStep');
    };

    return (
        <form onSubmit={handleSubmit(onSubmit)} className={formStyle}>
            <input 
                {...register('city', { required: "La città è obbligatoria", minLength: { value: 2, message: "Minimo 2 caratteri" } })} 
                placeholder="Città" 
                className="border p-2 rounded" 
            />
            {errors.city && <p className="text-red-500">❌{errors.city.message}</p>}

            <input 
                {...register('state', { required: "Lo stato è obbligatorio", minLength: { value: 2, message: "Minimo 2 caratteri" } })} 
                placeholder="Stato" 
                className="border p-2 rounded" 
            />
            {errors.state && <p className="text-red-500">❌{errors.state.message}</p>}

            {/* Mostra errori dal server */}
            {serverError && (
                <div className="bg-red-100 p-3 rounded-md">
                    {serverError.map((error, index) => (
                        <p key={index} className="text-red-500">{error}</p>
                    ))}
                </div>
            )}

            <div className="flex justify-between">
                <button type="button" onClick={onPrev} className={formButtonStyle}>Indietro</button>
                <button type="submit" className="bg-green-500 text-white px-4 py-2 rounded-md shadow-lg hover:bg-green-700 transition">Invia</button>
            </div>
        </form>
    );
}
