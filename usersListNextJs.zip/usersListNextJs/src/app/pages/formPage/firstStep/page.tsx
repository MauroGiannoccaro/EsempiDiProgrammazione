'use client';

import { set, useForm } from 'react-hook-form';
import { useRouter } from 'next/navigation';
import { formButtonStyle, formStore, formStyle } from '@/app/store/FormStore';

//controllo d'errore volutamente su server alla fine

function FirstStep() {
    const { register, handleSubmit } = useForm();
    const setFirstStep = formStore((state) => state.setFormDataFirstStep);
    const router = useRouter();

    const onNext = (data: any) => {
        setFirstStep({
            firstName: data.firstName,
            lastName: data.lastName,
        });
        router.push('/pages/formPage/secondStep');
    };

    return (
        <form onSubmit={handleSubmit(onNext)} className={formStyle}>
            <input {...register('firstName', { required: true })} placeholder="Nome" className="border p-2 rounded" />
            <input {...register('lastName', { required: true })} placeholder="Cognome" className="border p-2 rounded" />
            <button type="submit" className={formButtonStyle}>Avanti</button>
        </form>
    );
}
 export default FirstStep;