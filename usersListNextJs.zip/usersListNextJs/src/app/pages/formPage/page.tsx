// 'use client';

// import { useForm, FieldValues } from 'react-hook-form';
// import { formStore } from '@/app/store/FormStore';
// import { useState } from 'react';


// export default function MultiStepForm() {
//     const [step, setStep] = useState(1);
//     const { register, handleSubmit, watch } = useForm();
//     const formData = formStore((state) => state.formData);
//     const setFirstStep = formStore((state) => state.setFormDataFirstStep);
//     const setSecondStep = formStore((state) => state.setFormDataSecondStep);
//     const setThirdStep = formStore((state) => state.setFormDataThirdStep);

//     const nextSecondStep = () => {
//         setFirstStep({
//             firstName: watch('firstName'),
//             lastName: watch('lastName')
//         });
//         setStep(2);
//     };

//     const nextThirdStep = () => {
//         setSecondStep({
//             email: watch('email'),
//             phone: watch('phone')
//         });
//         setStep(3);
//     };

//     const prevStep = () => setStep((prev) => prev - 1);

//     const onSubmit = (data: FieldValues) => {
//         setThirdStep({
//             city: watch('city'),
//             state: watch('state')
//         });
//         console.log("Dati inviati:", { ...formData, ...data });
//     };

//     return (
//         <form onSubmit={handleSubmit(onSubmit)} className="bg-white p-6 rounded-lg shadow-lg flex flex-col gap-4">
//             {step === 1 && (
//                 <>
//                     <input {...register('firstName', { required: true })}  placeholder="Nome" className="border p-2 rounded" />
//                     <input {...register('lastName', { required: true })} placeholder="Cognome" className="border p-2 rounded" />
//                     <button type="button" onClick={nextSecondStep} className="bg-blue-500 text-white px-4 py-2 rounded-md shadow-lg hover:bg-blue-700 transition">Avanti</button>
//                 </>
//             )}
//             {step === 2 && (
//                 <>
//                     <input type="email" {...register('email', { required: true })}  placeholder="Email" className="border p-2 rounded" />
//                     <input type="tel" {...register('phone', { required: true })}  placeholder="Telefono" className="border p-2 rounded" />
//                     <div className="flex justify-between">
//                         <button type="button" onClick={prevStep} className="bg-gray-500 text-white px-4 py-2 rounded-md shadow-lg hover:bg-gray-700 transition">Indietro</button>
//                         <button type="button" onClick={nextThirdStep} className="bg-blue-500 text-white px-4 py-2 rounded-md shadow-lg hover:bg-blue-700 transition">Avanti</button>
//                     </div>
//                 </>
//             )}
//             {step === 3 && (
//                 <>
//                     <input {...register('city', { required: true })} defaultValue={formData.city} placeholder="Città" className="border p-2 rounded" />
//                     <input {...register('state', { required: true })} defaultValue={formData.state} placeholder="Stato" className="border p-2 rounded" />
//                     <div className="flex justify-between">
//                         <button type="button" onClick={prevStep} className="bg-gray-500 text-white px-4 py-2 rounded-md shadow-lg hover:bg-gray-700 transition">Indietro</button>
//                         <button type="submit" className="bg-green-500 text-white px-4 py-2 rounded-md shadow-lg hover:bg-green-700 transition">Invia</button>
//                     </div>
//                 </>
//             )}
//         </form>
//     );
// }


import React from 'react'
import FirstStep from './firstStep/page'

function page() {
  return (
    <div>
        <FirstStep />
    </div>
  )
}

export default page