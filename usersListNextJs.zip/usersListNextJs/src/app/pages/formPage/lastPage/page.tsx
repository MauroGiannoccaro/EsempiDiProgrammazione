"use client"

import { formStore } from '@/app/store/FormStore';
import React from 'react'

function lastPage() {

    const formData = formStore((state) => state.formData);

    return (
        <div className='flex flex-col items-center justify-center bg-amber-400 mx-auto w-[400px] h-[500px] rounded-lg shadow-lg'>
            <h1>✅Dati inviati con Successo:</h1>
            <p>Nome: {formData.firstName}</p>
            <p>Cognome: {formData.lastName}</p>
            <p>Email: {formData.email}</p>
            <p>Telefono: {formData.phone}</p>
            <p>Città: {formData.city}</p>
            <p>Stato: {formData.state}</p>
        </div>
    )
}

export default lastPage; 
