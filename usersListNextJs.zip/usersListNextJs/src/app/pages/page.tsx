import React from 'react'
import Blog from './blog/page'

function page() {
  return (
    <div><Blog></Blog></div>
  )
}

export default page