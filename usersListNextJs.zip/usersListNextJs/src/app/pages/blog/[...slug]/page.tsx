import { notFound } from "next/navigation";
type PageProps = {
  params: Promise<{ slug: string[] }>
  searchParams: Promise<{ [key: string]: string | string[] | undefined }>
}
const posts = [
  { slug: "introduzione-nextjs", title: "Introduzione a Next.js", content: "Benvenuto in Next.js!", category: "nextjs" },
  { slug: "uso-api-routes", title: "Come usare le API Routes", content: "Ecco come funzionano le API Routes.", category: "api" },
];

export default async function BlogDynamicPage({ params }: PageProps) {
  const { slug } = await params;

  if (!slug) return <h1>Elenco delle categorie</h1>; // Quando è solo `/blog`
  if (slug.length === 1) return <h1>Categoria: {slug[0]}</h1>; // Quando è `/blog/categoria`

  const post = posts.find((p) => p.slug === slug[1]);

  if (!post) {
    notFound(); 
  }

  return (
    <div>
      <h1>{post?.title}</h1>
      <p>{post?.content}</p>
    </div>
  );
}
