import Link from "next/link";

// Simuliamo un database di post
const posts = [
  { slug: "introduzione-nextjs", title: "Introduzione a Next.js", category: "nextjs" },
  { slug: "uso-api-routes", title: "Come usare le API Routes", category: "api" },
];

export default function BlogPage() {
  return (
    <div>
      <h1>Blog</h1>
      <ul>
        {posts.map((post) => (
          <li key={post.slug}>
            <Link href={`/pages/blog/${post.category}/${post.slug}`}>
              {post.title}
            </Link>
          </li>
        ))}
      </ul>
    </div>
  );
}
