import Link from "next/link";

interface documentsProps {
  slug: string;
  title: string;
}

const documents: documentsProps[] = [
  { slug: "introduzione", title: "Introduzione alla documentazione" },
  { slug: "installazione", title: "Guida all'installazione" },
  { slug: "configurazione", title: "Configurazione avanzata" },
];

export default function DocumentationPage() {
  return (
    <div>
      <h1>Documentazione</h1>
      <ul>
        {documents.map((doc) => (
          <li key={doc.slug}>
            <Link href={`/pages/documents/${doc.slug}`}>
              {doc.title}
            </Link>
          </li>
        ))}
      </ul>
    </div>
  );
}
