import { notFound } from "next/navigation"; // Utilizziamo notFound per gestire errori
import { Users } from "@/app/type/types"; // Importa il tipo Users, se necessario per il tuo caso

type PageProps = {
    params: Promise<{ slug: string[] }>
    searchParams: Promise<{ [key: string]: string | string[] | undefined }>
}

const documentContent: Record<string, { title: string; content: string }> = {
    introduzione: {
        title: "Introduzione alla documentazione",
        content: "Benvenuto nella documentazione! Qui troverai tutte le informazioni necessarie per utilizzare il nostro sistema.",
    },
    installazione: {
        title: "Guida all'installazione",
        content: "Per installare il sistema, segui i seguenti passi: 1) Scarica il pacchetto, 2) Estrai i file, 3) Esegui il setup.",
    },
    configurazione: {
        title: "Configurazione avanzata",
        content: "In questa sezione, esplorerai la configurazione avanzata del sistema, inclusi i parametri personalizzati.",
    },
};

async function fetchDocument(slug: string) {
    return documentContent[slug];
}

export default async function DocumentPage({ params }: PageProps) {
    const { slug } = (await params);

    if (!slug) {
        notFound();
    }

    const document = documentContent[slug.toString()];
    console.log("Document:", document);
    if (!document) {
        notFound();
    }
    return (
        <div>
            <h1>{slug}</h1>
            <h1>{document.title}</h1>
            <p>{document.content}</p>
        </div>
    );
}

