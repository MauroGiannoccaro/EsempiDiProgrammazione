// middleware.ts
import { NextRequest, NextResponse } from 'next/server';
import { fetchSsideStore } from './app/store/store';
import { aboutMiddleware } from './app/lib/middleware/about';
import { blogMiddleware } from './app/lib/middleware/blog';

export function middleware(request: NextRequest) {
  console.log('Middleware is running!');
  const url = request.nextUrl;
  
  const blogResponse = blogMiddleware(request)
  if (blogResponse) return blogResponse;

  const aboutResponse = aboutMiddleware(request)
  if (aboutResponse) return aboutResponse;


  // Se l'utente clicca su un link dell'utente, salviamo l'ID nel cookie
  if (url.pathname.startsWith('/listaUtenti')) {
    
    const userId = url.pathname.split('/').pop(); // Estrae l'ID utente dall'URL
    fetchSsideStore.setState({ id: userId }); // Salva l'ID utente nello stato globale
    console.log('User ID:', fetchSsideStore.getState().id);
    const response = NextResponse.next();

    // Salva l'ID dell'utente nei cookies
    if (userId) {
      response.cookies.set('userId', userId, { httpOnly: true, path: '/' });
    }

    return response;
  }

  return NextResponse.next();
}

export const config = {
  matcher: ['/listaUtenti/:slug*', '/about/:slug*', '/pages/blog'], // Applica il middleware solo a queste rotte
};
