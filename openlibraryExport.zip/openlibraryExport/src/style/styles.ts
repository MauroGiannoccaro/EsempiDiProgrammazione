export const container ="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 drop-shadow-2xl p-4 bg-orange-400 rounded-3xl shadow-md shadow-orange-300 md:w-[700px] lg:w-[1000px] sm:w-[400px] xl:w-[1200px]"
export const containerList = `
   grid
      grid-cols-1
      sm:grid-cols-2
      md:grid-cols-3
      lg:grid-cols-4
      gap-x-6 
      gap-y-2
      auto-rows-auto
      overflow-auto
      bg-orange-400
`;