import { Book, Doc } from "@/types/types";
import { create } from "zustand";

type bookStoreType = {
    book: Doc[];
    setBook: (Book: Doc[]) => void;
    slug: string;
    setSlug: (slug: string) => void;
};

export const libraryStore = create <bookStoreType>((set) => ({
    book: [],
    setBook: (book) => set({ book }),
    slug: "",
    setSlug: (slug) => set({ slug }),
}));            

type urlStoreType = {
    url: string[];
    setUrl: (url: string) => void;
};

export const urlLibrary = create <urlStoreType>((set)=> ({
    url: ['https://openlibrary.org/search.json?q=harry+potter', "https://openlibrary.org/search.json?q=the+lord+of+the+rings"],
    setUrl: (url: string) => set((state) => ({ url: [...state.url, url] })),
}));
