import { Book, Doc } from "@/types/types";
import { BehaviorSubject } from "rxjs";
import { create } from "zustand";

type bookStoreType = {
    book: Doc[];
    setBook: (Book: Doc[]) => void;
    slug: string;
    setSlug: (slug: string) => void;
};

export const libraryStore = create <bookStoreType>((set) => ({
    book: [],
    setBook: (book) => set({ book }),
    slug: "",
    setSlug: (slug) => set({ slug }),
}));            

type urlStoreType = {
    url: string[];
    libraries: {
        id: string;
        name: string;
    }[];
    setUrl: (url: string) => void;
    setLibrary: (libraries: { id: string; name: string }[]) => void;
};

export const urlLibrary = create <urlStoreType>((set)=> ({
    url: ['https://openlibrary.org/search.json?q=harry+potter', "https://openlibrary.org/search.json?q=the+lord+of+the+rings"],
    libraries: [],
    setUrl: (url: string) => set((state) => ({ url: [...state.url, url] })),
    setLibrary: (libraries : {id: string, name: string}[]) => set({ libraries }),
}));

// BehaviorSubject

const initialUrl: string | null = null;

const userSubject = new BehaviorSubject<string | null>(initialUrl);

export const selectionStore = {
  id$: userSubject.asObservable(),     
  getId: () => userSubject.getValue(),
  setId: (id: string | null) => userSubject.next(id),
};