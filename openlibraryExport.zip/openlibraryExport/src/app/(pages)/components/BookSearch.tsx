'use client';

import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import { searchObservable, searchSubject } from "@/app/lib/datastream";
import { selectionStore, urlLibrary } from "@/app/store/LibraryStore";

type Book = {
  title: string;
  key: string;
};

export default function BookSearch() {
  const [loading, setLoading] = useState(false);
  const libraries = urlLibrary((state) => state.libraries);
  const setLibrary = urlLibrary((state) => state.setLibrary);
  const [selectedId, setSelectedId] = useState(selectionStore.getId());
  const router = useRouter();
  console.log("selected id:", selectedId);
  useEffect(() => {
    const subscriptionId = selectionStore.id$.subscribe(setSelectedId);
    const subscription = searchObservable.subscribe((data) => {
      const docs = data.docs || [];
      setLibrary(
        docs.map((lib: Book) => ({
          id: lib.key,
          name: lib.title,
        }))
      );
      setLoading(false);
    });

    return () => { subscription.unsubscribe(), subscriptionId.unsubscribe() };
  }, []);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const query = e.target.value;
    setLoading(true);
    searchSubject.next(query);
  };

  const handleSelect = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const selectedId = e.target.value;
    selectionStore.setId(selectedId);
    if (selectedId) {
      router.push(`/Library/nome?name=${selectedId}`);
    }
  };

  return (
    <div className="flex flex-col items-center justify-center bg-gray-800">
      <div className="p-2 mb-6 shadow-2xs shadow-blue-600 rounded-3xl h-[50px]">
        <input
          type="text"
          placeholder="Cerca un libro..."
          onChange={handleInputChange}
          className="border px-2 py-1 w-full mb-4 bg-white shadow-blue-600 rounded-3xl"
        />
        {loading ? <p className="text-white">Caricamento...</p> : <p className="text-inherit">...</p>}
        {/* <ul>
          {results.map((book) => (
            <li key={book.key}>{book.title}</li>
          ))}
        </ul> */}
      </div>
      <div>
        <div className="w-full max-w-md flex flex-col items-center gap-4 mt-5">
          <select
            onChange={handleSelect}
            className={`w-full p-2 rounded-md ${libraries.length > 0 ? 'bg-white text-black' : 'bg-gray-700  text-white'}`}
            defaultValue={selectedId || ""}
          >
            <option value="" disabled>
              {libraries.length > 0 ? "Seleziona un libro..." : "Libri non disponibili"}
            </option>
            {libraries.map((lib) => (
              <option key={lib.id} value={lib.name}>
                {lib.name}
              </option>
            ))}
          </select>
        </div>

      </div>
      {libraries.length > 0 && (
        <div className="mt-5 mb-2 rounded-3xl bg-blue-600 p-4 hover:bg-blue-700 hover:shadow-2xl cursor-pointer w-[220px]">
          <button className="..." onClick={() => {
            if (selectedId) {
              router.push(`/Library/nome?name=${selectedId}`);
            }
          }}>
            <p className="cursor-pointer">Vai alla Libreria scelta ➡️</p>
          </button>
        </div>
      )}
    </div>
  );
}
