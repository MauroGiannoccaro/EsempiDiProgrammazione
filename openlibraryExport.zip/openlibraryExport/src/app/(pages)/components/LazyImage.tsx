import Image from 'next/image';

type Props = {
  src: string;
  alt: string;
  width: number;
  height: number;
};

export default function LazyImage({ src, alt, width, height }: Props) {
  return (
    <div className="bg-gray-800 rounded-2xl overflow-hidden">
      <Image
        src={src}
        alt={alt}
        width={width}
        height={height}
        layout="intrinsic"
        className="drop-shadow-2xl rounded-2xl transition-transform duration-300 transform hover:scale-90"
      />
    </div>
  );

}
