import Link from 'next/link'
import React from 'react'

const Navbar = () => {
  return (
    <div className='bg-blue-500 p-4 text-white flex shadow-2xs justify-center shadow-blue-400 bordeder-2 border-blue-700 rounded-3xl mb-2 mt-1 align-middle'>
      <Link href="/" className='text-2xl font-bold'>
        Home
      </Link>
    </div>
  )
}

export default Navbar