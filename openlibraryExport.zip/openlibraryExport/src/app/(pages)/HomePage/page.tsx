// Questo file NON deve avere `'use client'`

import { libraryStore } from "@/app/store/LibraryStore";
import Savedata from "./Savedata";

const HomePage = async () => {
  const libraries = [
    { id: 0, name: 'Harry Potter' },
    { id: 1, name: 'Lord of The Ring' },
  ];

  let data = null;

  try {
    const res = await fetch('http://localhost:3000/api/handlerData', {
      cache: 'no-store',
    });

    if (!res.ok) {
      throw new Error('Errore nella fetch');
    }

    data = await res.json();
    console.log('Dati ricevuti lato server:', data.books, data.id);
  } catch (error) {
    console.error('Errore server-side:', error);
  }

  return (
    <div className="flex flex-col items-center justify-center min-h-screen gap-6 bg-gray-800 px-4">
      <div className="flex flex-col items-center justify-center gap-4 bg-blue-500 p-4 rounded-3xl mt-2 mb-30">
        <h1 className="text-4xl font-bold text-white">Library Home Page</h1>
      </div>
      {/* 
      {data && (
        <div className="text-white">
          <p>Dati ricevuti:</p>
          <pre>{JSON.stringify(data, null, 2)}</pre>
        </div>
      )} */}

      <form
        action="/Library/identificativo"
        method="get"
        className="w-full max-w-md flex flex-col items-center gap-4"
      >
        <select
          name="id"
          className="w-full p-2 rounded-md bg-gray-700 text-white"
        >
          {libraries.map((lib) => (
            <option key={lib.id} value={lib.id}>
              {lib.name}
            </option>
          ))}
        </select>
        <button
          type="submit"
          className="bg-blue-500 hover:bg-blue-600 text-white px-4 py-2 rounded shadow-2xl shadow-blue-600"
        >
          Vai alla libreria scelta
        </button>
      </form>
      <Savedata />
    </div>
  );
};

export default HomePage;
