"use client"

import { libraryStore } from '@/app/store/LibraryStore';
import React, { use, useEffect } from 'react'

const Savedata = () => {

    const save = libraryStore(state => state.setBook);

      async function getData() {
        try {
            const res = await fetch('http://localhost:3000/api/handlerData', {
                method: 'GET',
                headers: { 'Content-Type': 'application/json' },
            });

            const data = await res.json();
            save(data.books);
            console.log('Dati mandati:', data);
            if (!res.ok) {
                throw new Error(data.error || 'Errore sconosciuto');
            }

        } catch (err: any) {

        }
    };
    useEffect(() => {
        getData();
    },[])

  return (
    <></>
  )
}

export default Savedata