"use client"
import { libraryStore } from '@/app/store/LibraryStore'
import { containerList } from '@/style/styles';
import router, { useRouter } from 'next/navigation';
import React, { useEffect, useState } from 'react'

function SelectedLibraryList() {

  const books = libraryStore(state => state.book);
  const router = useRouter();
  console.log("sto nella pagina:", books);
  return (
    <div>
      <div className="flex flex-col items-center justify-center min-h-screen gap-6 bg-gray-700">
        <div className='flex flex-col items-center justify-center gap-4 bg-blue-500 p-4 rounded-3xl mb-1 shadow-md shadow-blue-600 w-[150px] mt-6'>
          <h1>Lista Libri</h1>
        </div>
        <div className={containerList}>
          {books.map((book, index) => (
            <div key={index} className='p-4 bg-white rounded shadow-md  shadow-amber-200 mb-4 ml-4 mr-4 mt-5'>
              <p>{index}.</p>
              <h2>Titolo: {book.title}</h2>
              <p>Autore: {book.author_name}</p>
            </div>
          ))}
        </div>
        <div className='flex gap-4 -mt-2 mb-10'>
          <button
            className='bg-gray-600 text-white px-4 py-2 rounded cursor-pointer'
            onClick={() => router.back()}
          >
            Torna alla Library
          </button>
        </div>
      </div>
    </div>
  );
}

export default SelectedLibraryList