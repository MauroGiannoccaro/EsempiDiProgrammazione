import React from 'react'

function LibrarySkeletron() {
    return (
        <div className="flex flex-col items-center justify-center min-h-screen gap-6 bg-gray-700 w-full h-full">
            <div className="flex flex-col items-center justify-center gap-4 bg-blue-500 p-4 rounded-3xl mt-2">
                <h1 className="text-3xl text-white">Library</h1>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 drop-shadow-2xl p-4 bg-orange-400 rounded-3xl w-[1400px] h-[600px]">
                {Array.from({ length: 6 }).map((_, index) => (
                    <div key={index} className="p-4 bg-white rounded shadow animate-pulse">
                        <div className="h-6 bg-gray-300 rounded mb-2"></div>
                        <div className="h-4 bg-gray-300 rounded mb-2"></div>
                        <div className="h-4 bg-gray-300 rounded mb-2"></div>
                    </div>
                ))}
            </div>
            <div className="flex justify-center gap-4 mt-4">
                <button className="px-3 py-1 bg-gray-800 text-white rounded disabled:opacity-50">Indietro</button>
                <span className="text-white">Pagina 1 di 10</span>
                <button className="px-3 py-1 bg-gray-800 text-white rounded disabled:opacity-50">Avanti</button>
            </div>
            <div className="flex gap-4 mt-3 mb-2">
                <button className="bg-gray-600 text-white px-4 py-2 rounded">Torna alla Home</button>
                <button className="bg-gray-600 text-white px-4 py-2 rounded">Passa i Dati</button>
            </div>
        </div>
    )
}


export default LibrarySkeletron

