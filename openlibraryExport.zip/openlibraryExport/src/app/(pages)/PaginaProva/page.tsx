"use client"
import { libraryStore } from '@/app/store/LibraryStore'
import React, { useEffect, useState } from 'react'

function page() {


 
   const books: any[] = libraryStore.getState().book;
  console.log("sto nella pagina:",books);
  return (
    <div>
        <h1>Pagina Prova</h1>
        {books.map((book, index) => (
            <div key={index} className="flex flex-col items-center justify-center min-h-screen gap-6 bg-gray-700">
            <h2>{book.title}</h2>
            <p>{book.description}</p>
            </div>
        ))}
       
    </div>
  )
}

export default page