'use client';

import { lazy, Suspense, useEffect, useState } from 'react';
import { libraryStore, urlLibrary } from '@/app/store/LibraryStore';
import { Doc } from '@/types/types';
import Link from 'next/link';
import { useSearchParams } from 'next/navigation';
import { fetchWithInterceptor } from '@/app/interceptor/fetchInterceptor';
import LibrarySkeletron from '../../skeletron/Libraryskeletron';
import "../../../../style/styles.ts";
import { container } from '../../../../style/styles';

export default function LibraryPage() {
    const searchParams = useSearchParams();
    const name = searchParams ? searchParams.get('name') : null;
    const [loading, setLoading] = useState(true);
    const [currentPage, setCurrentPage] = useState(1);
    const [charging, setCharging] = useState(true);
    const save = libraryStore(state => state.setBook);
    const saveSlug = libraryStore(state => state.setSlug);
    const savedBooks = libraryStore(state => state.book);
    const savedSlug = libraryStore(state => state.slug);
console.log("sto nella pagina:", name);
    const setUrl = urlLibrary((state) => state.setUrl);
    const LazyImage = lazy(() => import('../../components/LazyImage'));

    const booksPerPage = 5;

    const originalWarn = console.warn;

    console.warn = (...args) => {
        if (args[0]?.includes('Image with src')) {
            return;
        }
        originalWarn(...args);
    };
    async function saveData(dataToSave: Doc[], id: string) {
        try {
            const res = await fetch('http://localhost:3000/api/handlerData', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ dataToSave, id }),
            });

            const data = await res.json();
            console.log('Dati salvati con POST:', data);
        } catch (err) {
            console.error('Errore nel salvataggio POST:', err);
        }
    }

    useEffect(() => {
        if (!name) return;

        const fetchAll = async () => {
            try {
                // Recupera da API interna
                const res = await fetch('http://localhost:3000/api/handlerData', {
                    method: 'GET',
                    headers: { 'Content-Type': 'application/json' },
                });

                const data = await res.json();

                if ( data?.books?.length > 0 && data.books[0].title && data.books[0].title === name && data.books.length > 0) {
                    console.log('Dati già presenti recuperati con GET');
                    save(data.books);
                    saveSlug(name);
                    setCharging(false);
                    setLoading(false);
                    return;
                }

                // Altrimenti, fetch da API OpenLibrary
                const resApi = await fetchWithInterceptor(`/getData?id=${name}`, {
                    cache: 'no-store',
                });

                const externalData = await resApi.json();
                save(externalData.Book.docs);
                setUrl(externalData.Book.documentation_url);
                saveData(externalData.Book.docs, name);
                saveSlug(name);

                console.log('Dati ottenuti da fetch esterna');
            } catch (err) {
                console.error('Errore durante il recupero dati:', err);
            } finally {
                setCharging(false);
                setLoading(false);
            }
        };

        fetchAll();
    }, [name]);

    if (loading) return <LibrarySkeletron/>;

    const books: Doc[] = savedBooks;
    if (!books || books.length === 0) return <h1>Nessun libro trovato</h1>;

    const startIndex = (currentPage - 1) * booksPerPage;
    const endIndex = startIndex + booksPerPage;
    const currentBooks = books.slice(startIndex, endIndex);
    const totalPages = Math.ceil(books.length / booksPerPage);

    return (
        <div className="flex flex-col items-center justify-center min-h-screen gap-6 bg-gray-700">
            <div className="flex flex-col items-center justify-center gap-4 bg-blue-500 p-4 rounded-3xl mt-6 shadow-md shadow-blue-600">
            <h1 className="text-3xl text-white">Library</h1>
            </div>

            <div className={container}>
                {currentBooks.map((book) => (
                    <div key={book.key} className="p-4 bg-white rounded shadow-md shadow-orange-100">
                        <h2 className="font-bold">{book.title}</h2>
                        <p>{book.author_name?.join(', ') || 'Autore sconosciuto'}</p>
                        <p>{book.first_publish_year}</p>
                        {book.cover_i && (
                            <Suspense fallback={<p>....Caricamento</p>}>
                                <LazyImage
                                    src={`https://covers.openlibrary.org/b/id/${book.cover_i}-L.jpg`}
                                    alt={book.title}
                                    width={400}
                                    height={600}
                                />
                            </Suspense>
                        )}
                    </div>
                ))}
            </div>

            <div className="flex justify-center gap-4 mt-4">
                <button
                    disabled={currentPage === 1}
                    onClick={() => setCurrentPage((prev) => prev - 1)}
                    className="px-3 py-1 bg-gray-800 text-white rounded disabled:opacity-50 cursor-pointer"
                >
                    Indietro
                </button>
                <span className="text-white">Pagina {currentPage} di {totalPages}</span>
                <button
                    disabled={currentPage === totalPages}
                    onClick={() => setCurrentPage((prev) => prev + 1)}
                    className="px-3 py-1 bg-gray-800 text-white rounded disabled:opacity-50 cursor-pointer"
                >
                    Avanti
                </button>
            </div>

            <div className="flex gap-4 mt-3 mb-5">
                <Link href="/" className="bg-gray-600 text-white px-4 py-2 rounded">Torna alla Home</Link>
                <Link href="/SelectedLibraryList" className="bg-gray-600 text-white px-4 py-2 rounded">Lista Libri</Link>
            </div>
        </div>
    );
}
