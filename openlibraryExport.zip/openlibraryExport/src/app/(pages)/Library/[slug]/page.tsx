import LibraryPage from './LibraryPage';

type PageProps = {
    searchParams: { [key: string]: string | string[] | undefined };
};

export default function Page({ searchParams }: PageProps) {
    // // const id =  searchParams?.id;
    // console.log('searchParams:', searchParams);
    // console.log('id:', id);
 
    // if (!id) {
    //     return <div>Loading...</div>;
    // }
    // const idString = Array.isArray(id) ? id[0] : id;

    // console.log('ID ottenuto dalla query string:', idString);

    // Passa l'id alla LibraryPage come parametro
    return <LibraryPage />;
}
