import HomePage from "./(pages)/HomePage/page";

export default function Home() {
  return (
    <div>
      <HomePage />
    </div>
  );
}
