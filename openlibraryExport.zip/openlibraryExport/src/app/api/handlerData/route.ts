import { Doc } from '@/types/types';

let books: Doc[] = [];
let id = "";

export async function POST(request: Request) {
    const body = await request.json();
    books = body.dataToSave;          
    id = body.id;
    console.log('Ricevuti dal client (POST):', books, id);

    return new Response(JSON.stringify({
        message: 'Libri ricevuti!',
        books,
        id,
    }), {
        status: 200,
        headers: {
            'Content-Type': 'application/json',
        }
    });
}

export async function GET() {
    console.log('Richiesta GET: restituisco book');

    return new Response(JSON.stringify({
        message: 'Libri recuperati!',
        books,
        id,
    }), {
        status: 200,
        headers: {
            'Content-Type': 'application/json',
        }
    });
}
