
import { urlLibrary } from "@/app/store/LibraryStore";
import { Book } from "@/types/types";
import { NextRequest, NextResponse } from "next/server";

export async function GET(request: NextRequest) {
    const id = request.nextUrl.searchParams.get("id") || "0";
    
    try {
        const response = await fetch(urlLibrary.getState().url[parseInt(id, 10)], {
            cache: "no-store",
        });
        if (!response.ok) {
            throw new Error(`Errore nella fetch esterna: ${response.status}`);
        }

        const data : Book = await response.json();

        console.log("sto nella fetch:",data);

        return NextResponse.json({ Book: data });
    } catch (error) {
        console.error("Errore nella API route:", error);
        return NextResponse.json({ error: "Errore nell'API" }, { status: 500 });
    }
}
