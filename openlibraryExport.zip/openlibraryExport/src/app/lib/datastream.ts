import { from, Subject } from 'rxjs';
import { debounceTime, distinctUntilChanged, switchMap } from 'rxjs/operators';

export const searchSubject = new Subject<string>();

export const searchObservable = searchSubject.pipe(
  debounceTime(300),
  distinctUntilChanged(),
  switchMap((query) =>
    from(fetch(`https://openlibrary.org/search.json?q=${encodeURIComponent(query)}`)
      .then(res => res.json()))
  )
);
/*
[Input utente] 
     |
     v
searchSubject.next(query)
     |
     v
[searchObservable pipeline]
 ┌──────────────┬──────────────┬────────────────────────┐
 │ debounceTime │ distinctUntil│ switchMap(fetch(query))│
 │    (300ms)   │ Changed      │  (cancella fetch vecchi)│
 └──────────────┴──────────────┴────────────────────────┘
     |
     v
[Response JSON da OpenLibrary]
     |
     v
onNext (data => {
  setResults(data.docs);
  setLoading(false);
})
     |
     v
[Render dei <li> con i titoli dei libri]
*/