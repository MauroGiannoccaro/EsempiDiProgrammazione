export async function fetchWithInterceptor(input: RequestInfo, init?: RequestInit) {
  // Interceptor "prima della richiesta"
  console.log("➡️ Intercetto richiesta a:", input);

  // Converti input in stringa URL
  let url = typeof input === 'string' ? input : input.url;

  // Aggiungi il prefisso '/api se non presente'
  if (!url.startsWith('/api')) {
    url = '/api' + (url.startsWith('/') ? '' : '/') + url;
  }

  const modifiedInit: RequestInit = {
    ...init,
    headers: {
      ...init?.headers,
      Authorization: "", // token opzionale
    },
  };

  try {
    const response = await fetch(url, modifiedInit);

    console.log("Risposta ricevuta:", response.status);

    if (!response.ok) {
      console.warn(" Risposta non OK");
    }

    return response;
  } catch (error) {
    console.error(" Errore nella fetch:", error);
    throw error;
  }
}
