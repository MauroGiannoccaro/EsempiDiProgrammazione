module.exports = {

"[project]/src/app/(pages)/components/Navbar/LazyImage.tsx [app-ssr] (ecmascript, async loader)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "server/chunks/ssr/_c49a1c70._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/app/(pages)/components/Navbar/LazyImage.tsx [app-ssr] (ecmascript)");
    });
});
}}),

};