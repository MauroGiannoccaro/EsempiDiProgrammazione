module.exports = {

"[project]/src/app/store/LibraryStore.tsx [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "libraryStore": (()=>libraryStore),
    "selectionStore": (()=>selectionStore),
    "urlLibrary": (()=>urlLibrary)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$rxjs$2f$dist$2f$cjs$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/rxjs/dist/cjs/index.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zustand$2f$esm$2f$react$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/zustand/esm/react.mjs [app-ssr] (ecmascript)");
;
;
const libraryStore = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zustand$2f$esm$2f$react$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["create"])((set)=>({
        book: [],
        setBook: (book)=>set({
                book
            }),
        slug: "",
        setSlug: (slug)=>set({
                slug
            })
    }));
const urlLibrary = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zustand$2f$esm$2f$react$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["create"])((set)=>({
        url: [
            'https://openlibrary.org/search.json?q=harry+potter',
            "https://openlibrary.org/search.json?q=the+lord+of+the+rings"
        ],
        libraries: [],
        setUrl: (url)=>set((state)=>({
                    url: [
                        ...state.url,
                        url
                    ]
                })),
        setLibrary: (libraries)=>set({
                libraries
            })
    }));
// BehaviorSubject
const initialUrl = null;
const userSubject = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$rxjs$2f$dist$2f$cjs$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["BehaviorSubject"](initialUrl);
const selectionStore = {
    id$: userSubject.asObservable(),
    getId: ()=>userSubject.getValue(),
    setId: (id)=>userSubject.next(id)
};
}}),
"[project]/src/app/interceptor/fetchInterceptor.tsx [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "fetchWithInterceptor": (()=>fetchWithInterceptor)
});
async function fetchWithInterceptor(input, init) {
    // Interceptor "prima della richiesta"
    console.log("➡️ Intercetto richiesta a:", input);
    // Converti input in stringa URL
    let url = typeof input === 'string' ? input : input.url;
    url = url.replace(/ /g, '+');
    console.log("URL:", url);
    // Aggiungi il prefisso '/api se non presente'
    if (!url.startsWith('/api')) {
        url = '/api' + (url.startsWith('/') ? '' : '/') + url;
    }
    const modifiedInit = {
        ...init,
        headers: {
            ...init?.headers,
            Authorization: ""
        }
    };
    try {
        const response = await fetch(url, modifiedInit);
        console.log("Risposta ricevuta:", response.status, response.url);
        if (!response.ok) {
            console.warn(" Risposta non OK");
        }
        return response;
    } catch (error) {
        console.error(" Errore nella fetch:", error);
        throw error;
    }
}
}}),
"[project]/src/app/(pages)/skeletron/Libraryskeletron.tsx [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
;
function LibrarySkeletron() {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "flex flex-col items-center justify-center min-h-screen gap-6 bg-gray-700 w-full h-full",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex flex-col items-center justify-center gap-4 bg-blue-500 p-4 rounded-3xl mt-2",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                    className: "text-3xl text-white",
                    children: "Library"
                }, void 0, false, {
                    fileName: "[project]/src/app/(pages)/skeletron/Libraryskeletron.tsx",
                    lineNumber: 7,
                    columnNumber: 17
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/app/(pages)/skeletron/Libraryskeletron.tsx",
                lineNumber: 6,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 drop-shadow-2xl p-4 bg-orange-400 rounded-3xl w-[1400px] h-[600px]",
                children: Array.from({
                    length: 6
                }).map((_, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "p-4 bg-white rounded shadow animate-pulse",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "h-6 bg-gray-300 rounded mb-2"
                            }, void 0, false, {
                                fileName: "[project]/src/app/(pages)/skeletron/Libraryskeletron.tsx",
                                lineNumber: 13,
                                columnNumber: 25
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "h-4 bg-gray-300 rounded mb-2"
                            }, void 0, false, {
                                fileName: "[project]/src/app/(pages)/skeletron/Libraryskeletron.tsx",
                                lineNumber: 14,
                                columnNumber: 25
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "h-4 bg-gray-300 rounded mb-2"
                            }, void 0, false, {
                                fileName: "[project]/src/app/(pages)/skeletron/Libraryskeletron.tsx",
                                lineNumber: 15,
                                columnNumber: 25
                            }, this)
                        ]
                    }, index, true, {
                        fileName: "[project]/src/app/(pages)/skeletron/Libraryskeletron.tsx",
                        lineNumber: 12,
                        columnNumber: 21
                    }, this))
            }, void 0, false, {
                fileName: "[project]/src/app/(pages)/skeletron/Libraryskeletron.tsx",
                lineNumber: 10,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex justify-center gap-4 mt-4",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        className: "px-3 py-1 bg-gray-800 text-white rounded disabled:opacity-50",
                        children: "Indietro"
                    }, void 0, false, {
                        fileName: "[project]/src/app/(pages)/skeletron/Libraryskeletron.tsx",
                        lineNumber: 20,
                        columnNumber: 17
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: "text-white",
                        children: "Pagina 1 di 10"
                    }, void 0, false, {
                        fileName: "[project]/src/app/(pages)/skeletron/Libraryskeletron.tsx",
                        lineNumber: 21,
                        columnNumber: 17
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        className: "px-3 py-1 bg-gray-800 text-white rounded disabled:opacity-50",
                        children: "Avanti"
                    }, void 0, false, {
                        fileName: "[project]/src/app/(pages)/skeletron/Libraryskeletron.tsx",
                        lineNumber: 22,
                        columnNumber: 17
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/app/(pages)/skeletron/Libraryskeletron.tsx",
                lineNumber: 19,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex gap-4 mt-3 mb-2",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        className: "bg-gray-600 text-white px-4 py-2 rounded",
                        children: "Torna alla Home"
                    }, void 0, false, {
                        fileName: "[project]/src/app/(pages)/skeletron/Libraryskeletron.tsx",
                        lineNumber: 25,
                        columnNumber: 17
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        className: "bg-gray-600 text-white px-4 py-2 rounded",
                        children: "Passa i Dati"
                    }, void 0, false, {
                        fileName: "[project]/src/app/(pages)/skeletron/Libraryskeletron.tsx",
                        lineNumber: 26,
                        columnNumber: 17
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/app/(pages)/skeletron/Libraryskeletron.tsx",
                lineNumber: 24,
                columnNumber: 13
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/app/(pages)/skeletron/Libraryskeletron.tsx",
        lineNumber: 5,
        columnNumber: 9
    }, this);
}
const __TURBOPACK__default__export__ = LibrarySkeletron;
}}),
"[project]/src/style/styles.ts [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "container": (()=>container),
    "containerList": (()=>containerList)
});
const container = "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 drop-shadow-2xl p-4 bg-orange-400 rounded-3xl shadow-md shadow-orange-300 md:w-[700px] lg:w-[1000px] sm:w-[400px] xl:w-[1200px]";
const containerList = `
   grid
      grid-cols-1
      sm:grid-cols-2
      md:grid-cols-3
      lg:grid-cols-4
      gap-x-6 
      gap-y-2
      auto-rows-auto
      overflow-auto
      bg-orange-400
`;
}}),
"[project]/src/app/(pages)/Library/[slug]/LibraryPage.tsx [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>LibraryPage)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$store$2f$LibraryStore$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/app/store/LibraryStore.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/app-dir/link.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$interceptor$2f$fetchInterceptor$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/app/interceptor/fetchInterceptor.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$pages$292f$skeletron$2f$Libraryskeletron$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/app/(pages)/skeletron/Libraryskeletron.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$style$2f$styles$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/style/styles.ts [app-ssr] (ecmascript)");
'use client';
;
;
;
;
;
;
;
;
;
function LibraryPage() {
    const searchParams = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useSearchParams"])();
    const name = searchParams ? searchParams.get('name') : null;
    const [loading, setLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(true);
    const [currentPage, setCurrentPage] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(1);
    const [charging, setCharging] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(true);
    const save = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$store$2f$LibraryStore$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["libraryStore"])((state)=>state.setBook);
    const saveSlug = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$store$2f$LibraryStore$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["libraryStore"])((state)=>state.setSlug);
    const savedBooks = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$store$2f$LibraryStore$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["libraryStore"])((state)=>state.book);
    const savedSlug = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$store$2f$LibraryStore$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["libraryStore"])((state)=>state.slug);
    console.log("sto nella pagina:", name);
    const setUrl = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$store$2f$LibraryStore$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["urlLibrary"])((state)=>state.setUrl);
    const LazyImage = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["lazy"])(()=>__turbopack_context__.r("[project]/src/app/(pages)/components/LazyImage.tsx [app-ssr] (ecmascript, async loader)")(__turbopack_context__.i));
    const booksPerPage = 5;
    const originalWarn = console.warn;
    console.warn = (...args)=>{
        if (args[0]?.includes('Image with src')) {
            return;
        }
        originalWarn(...args);
    };
    async function saveData(dataToSave, id) {
        try {
            const res = await fetch('http://localhost:3000/api/handlerData', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    dataToSave,
                    id
                })
            });
            const data = await res.json();
            console.log('Dati salvati con POST:', data);
        } catch (err) {
            console.error('Errore nel salvataggio POST:', err);
        }
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        if (!name) return;
        const fetchAll = async ()=>{
            try {
                // Recupera da API interna
                const res = await fetch('http://localhost:3000/api/handlerData', {
                    method: 'GET',
                    headers: {
                        'Content-Type': 'application/json'
                    }
                });
                const data = await res.json();
                if (data?.books?.length > 0 && data.books[0].title && data.books[0].title === name && data.books.length > 0) {
                    console.log('Dati già presenti recuperati con GET');
                    save(data.books);
                    saveSlug(name);
                    setCharging(false);
                    setLoading(false);
                    return;
                }
                // Altrimenti, fetch da API OpenLibrary
                const resApi = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$interceptor$2f$fetchInterceptor$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["fetchWithInterceptor"])(`/getData?id=${name}`, {
                    cache: 'no-store'
                });
                const externalData = await resApi.json();
                save(externalData.Book.docs);
                setUrl(externalData.Book.documentation_url);
                saveData(externalData.Book.docs, name);
                saveSlug(name);
                console.log('Dati ottenuti da fetch esterna');
            } catch (err) {
                console.error('Errore durante il recupero dati:', err);
            } finally{
                setCharging(false);
                setLoading(false);
            }
        };
        fetchAll();
    }, [
        name
    ]);
    if (loading) return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$pages$292f$skeletron$2f$Libraryskeletron$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
        fileName: "[project]/src/app/(pages)/Library/[slug]/LibraryPage.tsx",
        lineNumber: 97,
        columnNumber: 25
    }, this);
    const books = savedBooks;
    if (!books || books.length === 0) return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
        children: "Nessun libro trovato"
    }, void 0, false, {
        fileName: "[project]/src/app/(pages)/Library/[slug]/LibraryPage.tsx",
        lineNumber: 100,
        columnNumber: 46
    }, this);
    const startIndex = (currentPage - 1) * booksPerPage;
    const endIndex = startIndex + booksPerPage;
    const currentBooks = books.slice(startIndex, endIndex);
    const totalPages = Math.ceil(books.length / booksPerPage);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "flex flex-col items-center justify-center min-h-screen gap-6 bg-gray-700",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex flex-col items-center justify-center gap-4 bg-blue-500 p-4 rounded-3xl mt-6 shadow-md shadow-blue-600",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                    className: "text-3xl text-white",
                    children: "Library"
                }, void 0, false, {
                    fileName: "[project]/src/app/(pages)/Library/[slug]/LibraryPage.tsx",
                    lineNumber: 110,
                    columnNumber: 13
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/app/(pages)/Library/[slug]/LibraryPage.tsx",
                lineNumber: 109,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$style$2f$styles$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["container"],
                children: currentBooks.map((book)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "p-4 bg-white rounded shadow-md shadow-orange-100",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                className: "font-bold",
                                children: book.title
                            }, void 0, false, {
                                fileName: "[project]/src/app/(pages)/Library/[slug]/LibraryPage.tsx",
                                lineNumber: 116,
                                columnNumber: 25
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                children: book.author_name?.join(', ') || 'Autore sconosciuto'
                            }, void 0, false, {
                                fileName: "[project]/src/app/(pages)/Library/[slug]/LibraryPage.tsx",
                                lineNumber: 117,
                                columnNumber: 25
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                children: book.first_publish_year
                            }, void 0, false, {
                                fileName: "[project]/src/app/(pages)/Library/[slug]/LibraryPage.tsx",
                                lineNumber: 118,
                                columnNumber: 25
                            }, this),
                            book.cover_i && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Suspense"], {
                                fallback: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    children: "....Caricamento"
                                }, void 0, false, {
                                    fileName: "[project]/src/app/(pages)/Library/[slug]/LibraryPage.tsx",
                                    lineNumber: 120,
                                    columnNumber: 49
                                }, void 0),
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(LazyImage, {
                                    src: `https://covers.openlibrary.org/b/id/${book.cover_i}-L.jpg`,
                                    alt: book.title,
                                    width: 400,
                                    height: 600
                                }, void 0, false, {
                                    fileName: "[project]/src/app/(pages)/Library/[slug]/LibraryPage.tsx",
                                    lineNumber: 121,
                                    columnNumber: 33
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/src/app/(pages)/Library/[slug]/LibraryPage.tsx",
                                lineNumber: 120,
                                columnNumber: 29
                            }, this)
                        ]
                    }, book.key, true, {
                        fileName: "[project]/src/app/(pages)/Library/[slug]/LibraryPage.tsx",
                        lineNumber: 115,
                        columnNumber: 21
                    }, this))
            }, void 0, false, {
                fileName: "[project]/src/app/(pages)/Library/[slug]/LibraryPage.tsx",
                lineNumber: 113,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex justify-center gap-4 mt-4",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        disabled: currentPage === 1,
                        onClick: ()=>setCurrentPage((prev)=>prev - 1),
                        className: "px-3 py-1 bg-gray-800 text-white rounded disabled:opacity-50 cursor-pointer",
                        children: "Indietro"
                    }, void 0, false, {
                        fileName: "[project]/src/app/(pages)/Library/[slug]/LibraryPage.tsx",
                        lineNumber: 134,
                        columnNumber: 17
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: "text-white",
                        children: [
                            "Pagina ",
                            currentPage,
                            " di ",
                            totalPages
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/(pages)/Library/[slug]/LibraryPage.tsx",
                        lineNumber: 141,
                        columnNumber: 17
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        disabled: currentPage === totalPages,
                        onClick: ()=>setCurrentPage((prev)=>prev + 1),
                        className: "px-3 py-1 bg-gray-800 text-white rounded disabled:opacity-50 cursor-pointer",
                        children: "Avanti"
                    }, void 0, false, {
                        fileName: "[project]/src/app/(pages)/Library/[slug]/LibraryPage.tsx",
                        lineNumber: 142,
                        columnNumber: 17
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/app/(pages)/Library/[slug]/LibraryPage.tsx",
                lineNumber: 133,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex gap-4 mt-3 mb-5",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                        href: "/",
                        className: "bg-gray-600 text-white px-4 py-2 rounded",
                        children: "Torna alla Home"
                    }, void 0, false, {
                        fileName: "[project]/src/app/(pages)/Library/[slug]/LibraryPage.tsx",
                        lineNumber: 152,
                        columnNumber: 17
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                        href: "/SelectedLibraryList",
                        className: "bg-gray-600 text-white px-4 py-2 rounded",
                        children: "Lista Libri"
                    }, void 0, false, {
                        fileName: "[project]/src/app/(pages)/Library/[slug]/LibraryPage.tsx",
                        lineNumber: 153,
                        columnNumber: 17
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/app/(pages)/Library/[slug]/LibraryPage.tsx",
                lineNumber: 151,
                columnNumber: 13
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/app/(pages)/Library/[slug]/LibraryPage.tsx",
        lineNumber: 108,
        columnNumber: 9
    }, this);
}
}}),

};

//# sourceMappingURL=src_365ad0e8._.js.map