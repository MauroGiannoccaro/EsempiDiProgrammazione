module.exports = {

"[project]/src/app/(pages)/components/Navbar/LazyImage.tsx [app-ssr] (ecmascript, async loader)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "server/chunks/ssr/node_modules_861d644f._.js",
  "server/chunks/ssr/src_app_(pages)_components_Navbar_LazyImage_tsx_281463be._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/app/(pages)/components/Navbar/LazyImage.tsx [app-ssr] (ecmascript)");
    });
});
}}),

};