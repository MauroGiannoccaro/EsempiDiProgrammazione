(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_app_(pages)_components_LazyImage_tsx_cbf4a425._.js",
  "static/chunks/_567f0d41._.js"
],
    source: "dynamic"
});
