(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_app_(pages)_components_LazyImage_tsx_cb28a7f2._.js",
  "static/chunks/_f0162a4d._.js"
],
    source: "dynamic"
});
