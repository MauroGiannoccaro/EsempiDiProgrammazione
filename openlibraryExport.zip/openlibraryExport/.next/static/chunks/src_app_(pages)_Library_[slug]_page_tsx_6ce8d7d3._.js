(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_app_(pages)_components_LazyImage_tsx_ef1c1b1b._.js",
  "static/chunks/_20ddf545._.js"
],
    source: "dynamic"
});
