(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_cc8a1459._.js",
  "static/chunks/src_app_b98b87eb._.js"
],
    source: "dynamic"
});
