(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_app_(pages)_components_Navbar_LazyImage_tsx_d5e48d59._.js",
  "static/chunks/_83d01456._.js"
],
    source: "dynamic"
});
