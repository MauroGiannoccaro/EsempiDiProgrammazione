(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([typeof document === "object" ? document.currentScript : undefined, {

"[project]/src/app/(pages)/components/LazyImage.tsx [app-client] (ecmascript, async loader)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/node_modules_next_15251bc2._.js",
  "static/chunks/src_app_(pages)_components_LazyImage_tsx_c5b46268._.js",
  "static/chunks/src_app_(pages)_components_LazyImage_tsx_ac972903._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/app/(pages)/components/LazyImage.tsx [app-client] (ecmascript)");
    });
});
}}),
}]);