/* eslint-disable react/no-unstable-nested-components */
/* eslint-disable react/react-in-jsx-scope */
import { createBottomTabNavigator, BottomTabNavigationOptions } from '@react-navigation/bottom-tabs';
import { NavigationContainer } from '@react-navigation/native';
import { Text} from 'react-native';
import CalendarPage from './src/pages/CalendarPage';
import Weather from './src/pages/Weather';
import { AppProvider } from './src/store/AppContext';


export type TabsParamList = {
  Weather: undefined;
  CalendarPage: undefined;
};

const Tabs = createBottomTabNavigator<TabsParamList>();

const configOptions: BottomTabNavigationOptions = {
  headerTitleAlign: 'center',
  headerTintColor: 'white',
  headerStyle: { backgroundColor: '#FFA500' },
  tabBarStyle: { backgroundColor: 'black', borderTopWidth: 0 },
  tabBarActiveTintColor: 'white',
  tabBarInactiveTintColor: 'grey',
  tabBarActiveBackgroundColor: '#FFA500',
  tabBarInactiveBackgroundColor: '#FFB347',
  tabBarLabelStyle: { fontSize: 18, marginTop: -9 },
};

const App = () => {
  return (
      <AppProvider>
        <NavigationContainer>
          <Tabs.Navigator initialRouteName="Weather" screenOptions={configOptions}>
            <Tabs.Screen
              name="Weather"
              component={Weather}
              options={{
                headerTitle: 'Weather',
                tabBarIcon: () => <Text>☀️</Text>,
              }} />
            <Tabs.Screen
              name="CalendarPage"
              component={CalendarPage}
              options={{
                headerTitle: 'Calendar',
                tabBarIcon: () => <Text>📅</Text>,
              }} />
          </Tabs.Navigator>
        </NavigationContainer>
      </AppProvider>
  );
};

export default App;
