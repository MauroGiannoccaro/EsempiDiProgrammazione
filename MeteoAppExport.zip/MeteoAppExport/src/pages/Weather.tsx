/* eslint-disable react/react-in-jsx-scope */
/* eslint-disable react-native/no-inline-styles */

import { ScrollView, Text, View } from 'react-native';
import { useAppContext } from '../store/AppContext';
import WeatherCardComponent from './components/WeatherCardComponent';
import stylesWeather from './styles/WeatherCardComponent.js';
import styles from './styles/Homepage.js';
// import NavigationButtonsComponent from './components/NavigationButtonsComponent';

// import GeolocationComponent from './components/GeolocationComponent';

function Weather() {
    const { meteoParameters, isLoading, error } = useAppContext();
    console.log('sto in weather', meteoParameters);

    if (isLoading) {
        return (

            <View>
                <Text>Loading weather data...</Text>
            </View>
        );
    }

    if (error) {
        return (
            <View style={styles.container}>
                <Text>Error: {error}</Text>
            </View>
        );
    }

    return (

        <View style={stylesWeather.containerPage}>
            <ScrollView showsVerticalScrollIndicator={false}>
                {/* <GeolocationComponent /> */}
                    {/* Rendering Condizionale di WeatherCardComponent */}
                    {meteoParameters.current_weather && (
                        <WeatherCardComponent meteoParameters={meteoParameters} />
                    )}
                    <View style={{display: 'flex', flexDirection: 'row', gap: 10, width: '100%', marginLeft: 30}}>
                    {/* <NavigationButtonsComponent
                        firstPage='Weather'
                        secondPage='CalendarPage'
                    /> */}
                    </View>
            </ScrollView>
        </View>
    );
}

export default Weather;
