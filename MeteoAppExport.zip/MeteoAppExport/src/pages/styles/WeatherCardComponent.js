import { StyleSheet, Platform } from 'react-native';

const styles = StyleSheet.create({
    containerWeather: {
        flexGrow: 1,
        padding: '2%',
        height: '30%',
        marginTop: '2%',
        marginLeft: '1%',
        width: '100%',
    },
    containerPage: {
       backgroundColor: 'lightgrey',
    },
    transparentBox: {
        padding: '2%',
        width: '90%',
        marginTop: '10%',
        marginLeft: '5%',
        alignItems: 'center',
        backgroundColor: 'rgba(141, 217, 231, 0.89)', /* Colore nero con trasparenza al 50% */
        border: '2px solid #fff', /* Bordo bianco */
        boxShadow: '0 4px 8px rgba(0, 0, 0, 0.2)', /* Ombra */
        color: '#fff', /* Testo bianco */
        textAlign: 'center',
        fontSize: '18px',
    },
    hourlyScrollView: {
        maxHeight: 300, // Altezza massima per rendere il contenuto scrollabile
    },
    emoticonTab:{
    backgroundColor: 'white',
    borderRadius: 10,
    width: '10%',
    alignItems: 'center',
    marginLeft: '45%',
    marginTop: '2%',
    },
    scrollView: {
        flex: 1,
    },
    card: {
        display: 'flex',
        flexDirection: 'space-between',
        width: '90%',
        marginLeft: '6%',
        gap: '2%',
        overflow: 'scroll',
        borderRadius: 10,
        backgroundColor: 'rgba(141, 217, 231, 0.89)', // Azzurrino Trasparente
        padding: 10,
        marginVertical: 8,
        alignItems: 'center',
        borderWidth: 2,
        borderColor: 'rgba(135, 206, 250, 0.71)', // Colore del bordo
        shadowColor: '#000',
        shadowOffset: { width: 4, height: 4 },
        shadowOpacity: 0.5,
        shadowRadius: 15,
        // Ombra per Android
        ...Platform.select({
            android: {
                elevation: 2,
                transform: [{ translateX: -5 }, { translateY: 3 }],
                overflow: 'hidden',
            },
        }),
    },
    buttonContainer: {
        display: 'flex',
        flexDirection: 'row',
        gap: 10,
        width: '70%',
        marginBottom: 10,
        alignItems: 'center',
        marginTop: 12,
    },
    text: {
        fontSize: 25,
        fontWeight: 'bold',
        color: '#4682B4',
    },
    hourly: {
        flexDirection: 'row',
        borderRadius: 10,
        width: '100px',
        height: '6%',
        alignItems: 'center',
        margin: '3%',
        justifyContent: 'center',
        boxShadow: '0 4px 8px rgba(0, 0, 0, 0.2)',
        backgroundColor: 'white',
        marginVertical: 5,
        gap: '1%',
        marginTop: '3%',
        transformext: {
            fontSize: 25,
        },
      },
      calendar: {
        width: '100%',
        boxShadow: '0 4px 8px rgba(0, 0, 0, 0.2)',
        marginTop: -10,
        marginLeft: -5,
        borderRadius: 30,
        backgroundColor: 'rgba(173, 216, 230, 0.7)',
        padding: 10,
      },
      weatherEmoticon: {
        fontSize: 24,
    },

});

export default styles;
