import { StyleSheet } from 'react-native';

export default StyleSheet.create({
  container: {
    display: 'flex',
    flexDirection: 'column',
    flexGrow: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#FFF',
    padding: 10,
    gap: 10,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
    marginTop: 20,
  },
  buttonContainer: {
    flexDirection: 'column',
    gap: 10,
    width: '80%',
    marginBottom: 10,
  },
  button: {
    backgroundColor: '#1E90FF',
    paddingVertical: 10,
    paddingHorizontal: 20,
    borderRadius: 5,
    marginHorizontal: 10, // Spazio esterno orizzontale tra i pulsanti
    marginVertical: 10, // Spazio esterno verticale sopra e sotto i pulsanti
  },
  buttonText: {
    color: '#FFF',
    fontSize: 16,
  },
  errorText: {
    color: 'red',
  },
  calendar: {
    width: '130%',
    marginTop: 20,
    marginLeft: -25,
    borderRadius: 15,
    backgroundColor: 'rgba(173, 216, 230, 0.7)',
    padding: 20,
  },
});
