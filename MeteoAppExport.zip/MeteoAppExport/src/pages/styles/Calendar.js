import {StyleSheet} from 'react-native';

const stylesCalendar = StyleSheet.create({
  input: {
    width: '80%',
    borderColor: 'lightgray',
    borderWidth: 1,
    backgroundColor: 'white',
    marginBottom: 10,
    padding: 10,
    marginTop: 15,
  },
  containerCalendar: {
    padding: 10,
    backgroundColor: 'rgba(236, 233, 205, 0.7)',
    borderRadius: 20,
    flexGrow: 1,
    width: '90%',
  },
  calendar: {
    width: '100%', // Cambiato a 100% per evitare overflow
    height: 350, // Altezza fissa
    marginTop: 40,
    marginLeft: 0, // Rimosso margine negativo
    borderRadius: 20,
    padding: 10,
    backgroundColor: 'rgba(236, 233, 205, 0.7)',
  },
  calendarView: {
    width: '90%',
    marginTop: '2%',
    marginLeft: '4%',
    marginBottom: 10,
    borderColor: 'rgba(236, 233, 205, 0.7)',
    height: 350, // Altezza fissa per calendarView
    borderRadius: 20,
  },
  inputView: {
    flexDirection: 'column',
    backgroundColor: 'rgba(236, 233, 205, 0.7)',
    width: '90%',
    marginLeft: '4%',
    marginTop: -4,
    marginBottom: 10, // Cambiato a 10
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 20,
  },
  appointmentView: {
    flexDirection: 'column',
    width: '95%',
    padding: 10,
    backgroundColor: 'lightgrey',
    marginVertical: 5,
    borderRadius: 10,
    shadowColor: '#000',
    shadowOffset: {width: 0, height: 4},
    shadowOpacity: 0.2,
    shadowRadius: 8,
    elevation: 5,
  },
  errorInput: {
    borderColor: 'red',
  },
  appointmentText: {
    fontSize: 18,
    color: 'white',
    margin: 0,
  },
  appointmentListContainer: {
    flexGrow: 1,
    width: '100%',
    marginBottom: 20,
  },
  appointmentList: {
    flexGrow: 1,
    marginTop: 5,
    marginLeft: '4%',
  },
  containerPage: {
    backgroundColor: 'rgba(236, 220, 74, 0.9)',
    flexGrow: 1,
    width: '100%',
    padding: 10,
  },
  scrollView: {
    flexGrow: 1,
  },
  buttonCalendar: {
   marginBottom: 2,
  },
});

export default stylesCalendar;
