
/* eslint-disable @typescript-eslint/no-shadow */


import React, { useState, useTransition, useEffect, useCallback, lazy, Suspense} from 'react';
import { Alert, ScrollView, View} from 'react-native';
import { Calendar } from 'react-native-calendars';
import { useAppContext } from '../store/AppContext';
import { getWeatherEmoticon } from '../utils/emoticonUtis';
import { validateTime, validateDescription } from '../utils/ValidateUtil';
import stylesCalendar from './styles/Calendar';
import { Appointment } from '../types/Appoinment';
// import CalendarAppointmentCard from "./components/calendarAppoinmentCard";
const CalendarAppointmentCard = lazy(() => import('./components/CalendarAppoinmentCard'));

// import LoadingImg from '../assets/Loading_icon.gif';


const CalendarPage = () => {
    const { selectedDate, filteredData, averagePrecipitation, onDayPress } = useAppContext();
    const [appointment, setAppointment] = useState<Appointment[]>([]);
    const [time, setTime] = useState('');
    const [description, setDescription] = useState('');
    const [filteredDataAppointment, setFilteredDataAppointment] = useState<Appointment[]>([]);
    const [descriptionError, setDescriptionError] = useState(false);
    const [, startTransition] = useTransition();
console.log('sto in calendar', filteredData);

    useEffect(() => {
        console.log(appointment);
        if (appointment) {
            startTransition(() => {
                const filtered = appointment.filter(item => item.date === selectedDate);
                console.log('filtered', filtered);
                setFilteredDataAppointment(filtered);
            });
        }
    }, [appointment, selectedDate]);

    function onHandlePress() {
        const formatTime = (time: string) => {
            const regex = /^([01]?\d|2[0-3]):([0-5]\d)$/;
            const match = time.match(regex);
            if (match) {
                const [_, hour, minute] = match;
                const fData = `${hour.length === 1 ? '0' + hour : hour}:${minute}`;
                console.log(fData, time);
                return fData;
            }
            return time;
        };
        const formattedTime = formatTime(time);

        if (validateTime(formattedTime) && validateDescription(description)) {
            setAppointment(prev =>
                [...prev,
                {
                    date: selectedDate,
                    time: formattedTime,
                    description: description,
                    color: getRandomColor(),
                }]);
            setDescriptionError(false);
        } else {
            setDescriptionError(true);
        }
    }
    const getRandomColor = useCallback(() => {
        const letters = '0123456789ABCDEF';
        let color;
        do {
            color = '#';
            for (let i = 0; i < 6; i++) {
                color += letters[Math.floor(Math.random() * 16)];
            }
        } while (color === '#FFFFFF');
        return color;
    }, []);

    const deleteAppointment = useCallback((appointmentD: Appointment) => {
        Alert.alert(
            'Conferma Eliminazione',
            'Sei sicuro di voler eliminare questo appuntamento?',
            [
                {
                    text: 'Annulla',
                    style: 'cancel',
                },
                {
                    text: 'Elimina',
                    onPress: () => {
                        setAppointment(prev => prev.filter((item) => item !== appointmentD));
                    },
                    style: 'destructive',
                },
            ]
        );
    }, []);

    function getDayTimeEmoticon(time: string) {
        console.log('time calendar', time);
        const getEmo = filteredData.find(data => data.time.split(':')[0] === time.split(':')[0]);
        if (getEmo) {
            return getWeatherEmoticon(getEmo.precipitation);
        }
    }
    return (
        <ScrollView style={stylesCalendar.containerPage}>
            <View style={stylesCalendar.scrollView}>
                <View style={stylesCalendar.calendarView}>
                    <Calendar
                        onDayPress={onDayPress}
                        markedDates={{
                            [selectedDate]: { selected: true },
                        }}
                        theme={{
                            selectedDayBackgroundColor: '#00adf5',
                            selectedDayTextColor: '#ffffff',
                            todayTextColor: '#00adf5',
                            dayTextColor: '#2d4150',
                            textDisabledColor: '#d9e1e8',
                            backgroundColor: 'rgba(236, 233, 205, 0.7)',
                            calendarBackground: 'rgba(236, 233, 205, 0.7)',
                        }}
                    />
                </View>
                <CalendarAppointmentCard
                    descriptionError={descriptionError}
                    setTime={setTime}
                    selectedDate={selectedDate}
                    setDescription={setDescription}
                    setDescriptionError={setDescriptionError}
                    onHandlePress={onHandlePress}
                    filteredDataAppointment={filteredDataAppointment}
                    deleteAppointment={deleteAppointment}
                    getDayTimeEmoticon={getDayTimeEmoticon}
                    averagePrecipitation={averagePrecipitation}
                />
            </View>
            <Suspense fallback={'loading'}/>
        </ScrollView>
    );
};

export default CalendarPage;
