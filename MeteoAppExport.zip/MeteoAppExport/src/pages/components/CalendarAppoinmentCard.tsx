import React, { memo } from "react";
import { View, TextInput, Text, Button, TouchableOpacity, ScrollView } from "react-native";
import { getWeatherEmoticon } from "../../utils/emoticonUtis";
import stylesCalendar from "../styles/Calendar";
import { Appointment } from "../../types/Appoinment";


interface CalendarAppointmentCardProps {
    descriptionError: boolean;
    setTime: React.Dispatch<React.SetStateAction<string>>;
    selectedDate: string;
    setDescription: React.Dispatch<React.SetStateAction<string>>;
    setDescriptionError: React.Dispatch<React.SetStateAction<boolean>>;
    onHandlePress: () => void;
    filteredDataAppointment: Appointment[];
    deleteAppointment: (appointment: Appointment) => void;
    getDayTimeEmoticon: (time: string) => string | undefined;
    averagePrecipitation: number;
}

const CalendarAppointmentCard = memo(({
    descriptionError,
    setTime,
    selectedDate,
    setDescription,
    setDescriptionError,
    onHandlePress,
    filteredDataAppointment,
    deleteAppointment,
    getDayTimeEmoticon,
    averagePrecipitation,
}: CalendarAppointmentCardProps) => {
    return (
        <ScrollView style={stylesCalendar.containerPage}>
            <View style={stylesCalendar.scrollView}>
                <View style={stylesCalendar.inputView}>
                    <TextInput
                        placeholder="Inserisci un orario"
                        style={stylesCalendar.input}
                        onChangeText={setTime}
                        value={selectedDate + getWeatherEmoticon(averagePrecipitation)}
                    />
                    <TextInput
                        placeholder="Inserisci un orario"
                        style={[stylesCalendar.input, descriptionError && stylesCalendar.errorInput]}
                        onChangeText={(Text) => {
                            setTime(Text);
                            setDescriptionError(false);
                        }}
                    />
                    {descriptionError && <Text>Inserisci un orario valido HH:mm</Text>}
                    <TextInput
                        placeholder="Inserisci una descrizione"
                        style={[stylesCalendar.input, descriptionError && stylesCalendar.errorInput]}
                        onChangeText={(Text) => {
                            setDescription(Text);
                            setDescriptionError(false);
                        }}
                        numberOfLines={4}
                        multiline
                    />
                    <Text>{descriptionError && <Text>Inserisci una descrizione valida max 300 parole</Text>}</Text>
                    <View style={stylesCalendar.buttonCalendar}>
                        <Button title="Salva" onPress={onHandlePress} />
                    </View>
                </View>
                <View style={stylesCalendar.appointmentListContainer}>
                    <View style={stylesCalendar.appointmentList}>
                        {filteredDataAppointment && filteredDataAppointment.length > 0 ? filteredDataAppointment.map((item, index) => (
                            <View key={index} style={[stylesCalendar.appointmentView, { backgroundColor: item.color }]}>
                                <Text style={{ color: 'white' }}>{index + 1} Appointment:</Text>
                                <TouchableOpacity onPress={() => deleteAppointment(item)}>
                                    <Text style={{ textAlign: 'right', color: 'white' }}>Delete 🗑️</Text>
                                </TouchableOpacity>
                                <Text style={stylesCalendar.appointmentText}>{item.date + getDayTimeEmoticon(item.time)}</Text>
                                <Text style={stylesCalendar.appointmentText}>{item.time}</Text>
                                <Text style={stylesCalendar.appointmentText}>{item.description}</Text>
                            </View>
                        )) : (
                            <View style={stylesCalendar.appointmentView}>
                                <Text style={stylesCalendar.appointmentText}>Non ci sono appuntamenti</Text>
                            </View>
                        )}
                    </View>
                </View>
            </View>
        </ScrollView>
    );
});

export default CalendarAppointmentCard;
