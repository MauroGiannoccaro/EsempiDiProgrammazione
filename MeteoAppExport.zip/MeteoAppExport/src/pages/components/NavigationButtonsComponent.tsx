import React from 'react';
import { Text, TouchableOpacity, View } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import styles from '../styles/Homepage';
import { BottomTabNavigationProp } from '@react-navigation/bottom-tabs';
import { TabsParamList } from '../../../App';


type ScreenNavigationProp = BottomTabNavigationProp<TabsParamList, 'Weather'>;

type TabsComponentProps = {
    firstPage: keyof TabsParamList;
    secondPage: keyof TabsParamList;
};

const NavigationButtonsComponent = React.memo(({ firstPage, secondPage }: TabsComponentProps) => {
    const navigation = useNavigation<ScreenNavigationProp>();

    return (
        <View style={styles.buttonContainer}>
            <TouchableOpacity
                style={styles.button}
                onPress={() => {
                    if (navigation) {
                        navigation.navigate(firstPage);
                    }
                }}
            >
                <Text style={styles.buttonText}>
                    {(firstPage === 'Weather') ? `Vai a ${firstPage}` : `Vai a ${firstPage}`}
                </Text>
            </TouchableOpacity>
            <TouchableOpacity
                style={styles.button}
                onPress={() => {
                    if (navigation) {
                        navigation.navigate(secondPage);
                    }
                }}>
                <Text style={styles.buttonText}>{`Vai a ${secondPage}`}</Text>
            </TouchableOpacity>
        </View>
    );
});

export default NavigationButtonsComponent;
