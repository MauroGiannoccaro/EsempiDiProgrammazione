import React, { useState, useEffect } from 'react';
import {
    View,
    Text,
    Button,
    Platform,
    StyleSheet,
    Alert,
} from 'react-native';

import {
    check,
    request,
    PERMISSIONS,
    RESULTS,
    openSettings,
} from 'react-native-permissions';
import Geolocation from '@react-native-community/geolocation';
import type { PermissionStatus } from 'react-native-permissions';

type Location = {
    latitude: number;
    longitude: number;
};

const GeolocationComponent = () => {
    const [location, setLocation] = useState<Location | null>(null);
    const [permissionStatus, setPermissionStatus] = useState<PermissionStatus | null>(null);
    console.log('sto in geolocation', location);

    // Function to check the current permission status
    const checkPermission = async () => {
        let status;
        try {
            if (Platform.OS === 'ios') {
                status = await check(PERMISSIONS.IOS.LOCATION_WHEN_IN_USE);
            } else if (Platform.OS === 'android') {
                status = await check(PERMISSIONS.ANDROID.ACCESS_FINE_LOCATION);
            }
            if (status === RESULTS.GRANTED || status === RESULTS.DENIED) {
                setPermissionStatus(status);
            } else {
                console.warn('Permission check error:', status);
                setPermissionStatus('denied');
            }
        } catch (error) {
            console.warn('Permission check error:', error);
            setPermissionStatus('denied');
        }
    };

    // Function to request location permission
    const requestLocationPermission = async () => {
        let status;
        try {
            if (Platform.OS === 'ios') {
                status = await request(PERMISSIONS.IOS.LOCATION_WHEN_IN_USE);
            } else if (Platform.OS === 'android') {
                status = await request(PERMISSIONS.ANDROID.ACCESS_FINE_LOCATION);
            }
            if (status === RESULTS.GRANTED) {
                getCurrentLocation();
            } else {
                if (status === RESULTS.DENIED) {
                    handlePermissionDenied(status);
                }
            }
        } catch (error) {
            console.warn('Permission request error:', error);
            Alert.alert('Error', 'Failed to request location permission.');
        }
    };

    // Function to handle permission denied
    const handlePermissionDenied = (status: PermissionStatus) => {
        if (status === RESULTS.DENIED) {
            Alert.alert(
                'Permission Denied',
                'Location permission is required to show your current location.',
                [
                    {
                        text: 'Retry',
                        onPress: () => requestLocationPermission(),
                    },
                    {
                        text: 'Cancel',
                        style: 'cancel',
                    },
                ]
            );
        } else if (status === RESULTS.BLOCKED) {
            Alert.alert(
                'Permission Blocked',
                'Location permission is blocked. Please enable it in settings.',
                [
                    {
                        text: 'Open Settings',
                        onPress: () => openSettings(),
                    },
                    {
                        text: 'Cancel',
                        style: 'cancel',
                    },
                ]
            );
        }
    };

    // Function to get the current location
    const getCurrentLocation = () => {
        Geolocation.getCurrentPosition(
            (            position: { coords: { latitude: any; longitude: any; }; }) => {
                const { latitude, longitude } = position.coords;
                setLocation({ latitude, longitude });
                console.log('Latitude:', latitude, 'Longitude:', longitude);
            },
            (            error: any) => {
                console.warn('Geolocation error:', error);
                Alert.alert('Error', 'Failed to get current location.');
            },
            {
                enableHighAccuracy: true,
                timeout: 15000,
                maximumAge: 10000,
            }
        );
    };

    // Check permission status on component mount
    useEffect(() => {
        checkPermission();
    }, []);

    return (
        <View style={styles.container}>
            <Text style={styles.title}>Geolocation Example</Text>
            <Text style={styles.status}>
                Permission Status: {permissionStatus || 'Unknown'}
            </Text>
            {location ? (
                <View style={styles.locationContainer}>
                    <Text style={styles.locationText}>
                        Latitude: {location.latitude}
                    </Text>
                    <Text style={styles.locationText}>
                        Longitude: {location.longitude}
                    </Text>
                </View>
            ) : (
                <Text style={styles.noLocation}>No location available.</Text>
            )}
            <View style={styles.buttonContainer}>
                <Button
                    title="Request Permission & Get Location"
                    onPress={requestLocationPermission}
                />
            </View>
            {permissionStatus === RESULTS.DENIED && (
                <View style={styles.buttonContainer}>
                    <Button
                        title="Open Settings"
                        onPress={() => openSettings().catch(() => console.warn('Cannot open settings'))}
                    />
                </View>
            )}
        </View>
    );
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
        padding: 20,
        backgroundColor: '#f0f0f0',
        justifyContent: 'center',
    },
    title: {
        fontSize: 24,
        marginBottom: 20,
        textAlign: 'center',
    },
    status: {
        fontSize: 16,
        marginBottom: 10,
        textAlign: 'center',
    },
    locationContainer: {
        marginVertical: 20,
        alignItems: 'center',
    },
    locationText: {
        fontSize: 18,
    },
    noLocation: {
        fontSize: 16,
        textAlign: 'center',
        color: 'gray',
    },
    buttonContainer: {
        marginTop: 20,
    },
});

export default GeolocationComponent;
