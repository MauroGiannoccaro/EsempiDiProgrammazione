import React from 'react';
import { ScrollView, View, Text, Button } from 'react-native';
import { Calendar } from 'react-native-calendars';
import { useAppContext } from '../../store/AppContext';
import { meteo } from '../../types/meteo';
import { getWeatherEmoticon } from '../../utils/emoticonUtis';
import styles from '../styles/WeatherCardComponent';


interface WeatherCardComponentProps {
    meteoParameters: meteo;
}

const WeatherCardComponent = React.memo(({ meteoParameters }: WeatherCardComponentProps) => {
    const { currentPage, averagePrecipitation, itemsPerPage, filteredData, onDayPress, currentData, pageCounter, selectedDate, handleNextPage, handlePreviousPage } = useAppContext();

    return (
        <ScrollView showsVerticalScrollIndicator={true} style={styles.scrollView}>
            <View style={styles.containerWeather}>
                <Calendar
                    onDayPress={onDayPress}
                    markedDates={{
                        [selectedDate]: { selected: true },
                    }}
                    theme={{
                        selectedDayBackgroundColor: '#0a0df5',
                        selectedDayTextColor: '#ffffff',
                        todayTextColor: '#00adf5',
                        dayTextColor: '#2d4150',
                        monthTextColor: '#4682B4',
                        textDisabledColor: '#4682B4',
                        calendarBackground: 'rgba(173, 216, 230, 0.7)',
                    }}
                    style={styles.calendar}
                />
            </View>
            <View style={styles.transparentBox}>
                <Text style={styles.text}>Weather of the Day</Text>
                <Text>Tempo Attuale:</Text>
                <Text>Giorno: {meteoParameters.current_weather.time.split('T')[0]}</Text>
                <Text>Temperature: {meteoParameters.current_weather.temperature}°C</Text>
                <Text>Windspeed: {meteoParameters.current_weather.windspeed} km/h</Text>
                <Text>Winddirection: {meteoParameters.current_weather.winddirection}°</Text>
                <Text>Is Day: {meteoParameters.current_weather.is_day ? 'Yes' : 'No'}</Text>
                <Text>Latitudine: {meteoParameters.latitude}</Text>
                <Text>Longitudine: {meteoParameters.longitude}</Text>
            </View>
            <View style={styles.emoticonTab}>
            <Text style={styles.weatherEmoticon}>{getWeatherEmoticon(averagePrecipitation)}</Text>
                </View>
            <View style={styles.card}>
                <View style={styles.hourlyScrollView}>
                    <Text style={styles.text}>Temperature per ora</Text>
                    {currentData.map((data, index) => (
                        <View key={index} style={styles.hourly}>
                            <Text>Ora: {data.time}</Text>
                            <Text>Temp: {data.temperature}°C</Text>
                            <Text>Precip: {getWeatherEmoticon(data.precipitation)} {data.precipitation} mm</Text>
                        </View>
                    ))}
                </View>
                <View style={styles.buttonContainer}>
                    <Button title="Previous" onPress={handlePreviousPage} disabled={currentPage === 0} />
                    <Text>{currentPage + 1}</Text>
                    <Text>Pages: {pageCounter.map((page, index) => <Text key={index}>...{page}</Text>)}</Text>
                    <Button title="Next" onPress={handleNextPage} disabled={(currentPage + 1) * itemsPerPage >= filteredData.length} />
                </View>
            </View>
        </ScrollView>
    );
});

export default WeatherCardComponent;
