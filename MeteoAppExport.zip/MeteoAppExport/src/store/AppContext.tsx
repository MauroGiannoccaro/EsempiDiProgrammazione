/* eslint-disable react-hooks/exhaustive-deps */
import React, { createContext, useEffect, useState, useContext, ReactNode, startTransition, useCallback, useMemo } from 'react';
import { meteo } from '../types/meteo';
import FetchApi from '../api/FetchApi';

// Definizione del tipo di contesto
interface AppContextType {
    url: string;
    meteoParameters: meteo;
    error: string;
    setError: React.Dispatch<React.SetStateAction<string>>;
    isLoading: boolean;
    setIsLoading: React.Dispatch<React.SetStateAction<boolean>>;
    setUrl: React.Dispatch<React.SetStateAction<string>>;
    setMeteoParameters: React.Dispatch<React.SetStateAction<meteo>>;
    selectedDate: string
    setSelectedDate: React.Dispatch<React.SetStateAction<string>>
    currentPage: number;
    averagePrecipitation: number;
    setCurrentPage: React.Dispatch<React.SetStateAction<number>>;
    onDayPress: (day: { dateString: string; })=>void;
    itemsPerPage: number;
    filteredData: Array<{
        time: string;
        temperature: number;
        precipitation: number;
    }>,
    currentData: Array<{
        time: string;
        temperature: number;
        precipitation: number;
    }>;
    pageCounter: number[];
    handleNextPage: () => void;
    handlePreviousPage: () => void;
}

// Creazione del contesto
export const AppContext = createContext<AppContextType | undefined>(undefined);

// Creazione del hook per utilizzare il contesto
export const useAppContext = (): AppContextType => {
    const context = useContext(AppContext);
    if (!context) {
        throw new Error('useAppContext must be used within an AppProvider');
    }
    return context;
};

// Creazione del componente provider
export const AppProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
    const [latitudeDefault] = useState(45.464203);
    const [selectedDate, setSelectedDate] = useState<string>(new Date().toISOString().split('T')[0]);
    const [longitudeDefault] = useState(9.190336);
    const [startDateDefault] = useState(new Date().toISOString().split('T')[0]);
    const [endDateDefault] = useState(new Date().toISOString().split('T')[0]);
    const [averagePrecipitation, setAveragePrecipitation] = useState<number>(0);
    const [pageCounter, setPageCounter] = useState<number[]>([1]);
    const [currentPage, setCurrentPage] = useState<number>(0);
    const itemsPerPage = 8;

    // Creazione del valore di default del contesto
    const defaultContextValue: AppContextType = {
        url: `https://api.open-meteo.com/v1/forecast?latitude=${latitudeDefault}&longitude=${longitudeDefault}&start_date=${startDateDefault}&end_date=${endDateDefault}&current_weather=true&hourly=temperature_2m,precipitation&timezone=Europe/Rome`,
        meteoParameters: {} as meteo,
        error: '',
        setError: () => { },
        isLoading: false,
        setIsLoading: () => { },
        setUrl: () => { },
        setMeteoParameters: () => { },
        setSelectedDate: () => { },
        selectedDate: new Date().toISOString().split('T')[0],
        currentPage: 1,
        averagePrecipitation: 0,
        setCurrentPage: () => { },
        itemsPerPage: 8,
        filteredData: [{
            time: '00:00',
            temperature: 0,
            precipitation: 0,
        }],
        currentData: [],
        pageCounter: [],
        onDayPress: ()=>{},
        handleNextPage: () => {},
        handlePreviousPage: () => {},
    };

    // Stati del provider
    const [url, setUrl] = useState<string>(defaultContextValue.url);
    const [meteoParameters, setMeteoParameters] = useState<meteo>({} as meteo);
    const [error, setError] = useState<string>('');
    const [isLoading, setIsLoading] = useState<boolean>(true);


    // // Funzione per verificare se un oggetto è vuoto
    // const isEmptyObject = (obj: object) => {
    //     return Object.keys(obj).length === 0 && obj.constructor === Object;
    // };

    const filteredData = meteoParameters.hourly && meteoParameters.hourly.time
        ? meteoParameters.hourly.time
            .map((time, index) => time.split('T')[0] === selectedDate ? {
                time: time.split('T')[1],
                temperature: meteoParameters.hourly.temperature_2m[index],
                precipitation: meteoParameters.hourly.precipitation[index],
            } : null)
            .filter((item): item is NonNullable<typeof item> => item !== null)
        : [];

    useEffect(() => {
            if (filteredData.length > 0) {
                weatherMedia();
        }
    }, [filteredData]);

    useMemo(() => {
        const newUrl = `https://api.open-meteo.com/v1/forecast?latitude=${latitudeDefault}&longitude=${longitudeDefault}&start_date=${selectedDate}&end_date=${selectedDate}&current_weather=true&hourly=temperature_2m,precipitation&timezone=Europe/Rome`;
        startTransition(() => {
            console.log('parte la fetch', newUrl);
            FetchApi(newUrl).then(data => {
                try {
                    setIsLoading(true);
                    setMeteoParameters(prev => ({ prev, ...data }));
                    console.log('data', data);
                    setIsLoading(false);
                }
                catch {
                    setIsLoading(false);
                    throw new Error('errore nel recupero dati da fetch');
                }
            });
        });
        setPageCounter(Array.from({ length: Math.ceil(filteredData.length / itemsPerPage) }, (_, i) => i + 1));

    }, [selectedDate]);

    const onDayPress = useCallback((day: { dateString: string }) => {
        if (day.dateString === selectedDate) {
            return;
        }
        else{
        setSelectedDate(day.dateString);
        }
    }, [selectedDate]);

    const currentData = filteredData.slice(currentPage * itemsPerPage, (currentPage + 1) * itemsPerPage);
    console.log(currentData);
    // Effetto per eseguire il fetch dei dati quando i parametri cambiano

    const weatherMedia = useCallback(() => {
        const precipitation = filteredData.map(data => data.precipitation);
        setAveragePrecipitation(calculateAverage(precipitation));
    },[filteredData]);

    const calculateAverage = (values: number[]) => {
        if (values.length === 0) { return 0; }
        const sum = values.reduce((acc, val) => acc + val, 0);
        return sum / values.length;
    };
    const handleNextPage = () => {
        if ((currentPage + 1) * itemsPerPage < filteredData.length) {
            setCurrentPage(currentPage + 1);
        }
    };

    const handlePreviousPage = () => {
        if (currentPage > 0) {
            setCurrentPage(currentPage - 1);
        }
    };

    // useEffect(() => {
    //     if (isEmptyObject(meteoParameters) && url) {
    //         const newUrl = `https://api.open-meteo.com/v1/forecast?latitude=${latitudeDefault}&longitude=${longitudeDefault}&start_date=${selectedDate}&end_date=${selectedDate}&current_weather=true&hourly=temperature_2m,precipitation&timezone=Europe/Rome`;
    //         console.log("newUrl", newUrl)
    //         fetchData(newUrl);
    //     }
    // }, [url, meteoParameters, selectedDate]);

    // Restituzione del provider del contesto
    return (
        <AppContext.Provider value={{
            url,
            meteoParameters,
            error,
            setError,
            isLoading,
            setIsLoading,
            setUrl,
            setMeteoParameters,
            selectedDate,
            setSelectedDate,
            currentPage,
            averagePrecipitation,
            setCurrentPage,
            itemsPerPage,
            filteredData,
            currentData,
            pageCounter,
            onDayPress,
            handleNextPage,
            handlePreviousPage,
        }}>
            {children}
        </AppContext.Provider>
    );
};
