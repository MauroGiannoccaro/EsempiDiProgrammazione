export const getWeatherEmoticon = (item : number) => {
        if (item > 50) {
            return '🌧️';
        } else if (item > 20) {
            return '☁️';
        } else if (item > 0) {
            return '🌤️';
        } else {
            return '☀️';
        }
    };

