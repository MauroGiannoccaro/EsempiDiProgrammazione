
export function validateTime (text: string) {
    const regex = /^([01]\d|2[0-3]):([0-5]\d)$/;
    if (regex.test(text)) {
        return true;
    } else {
        return false;
    }
}

export const validateDescription = (text: string ) => {
    const wordCount = text.trim().split(/\s+/).length;
    if (wordCount <= 300) {
        return true;
    } else {
        return false;
    }
};
