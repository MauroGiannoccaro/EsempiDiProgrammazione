
export type Appointment = {
    date: string;
    time: string;
    description: string;
    color: string;
};
