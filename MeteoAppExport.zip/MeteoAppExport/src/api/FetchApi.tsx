

const FetchApi = async (url: string) => {
    try {
        console.log('FetchApi called with URL:', url);

        const response = await fetch(url);
        console.log('Response status:', response.status);

        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }

        const data = await response.json();
        console.log('Parsed data:', data);

        return data;
    } catch (error) {
        console.error('FetchApi error:', error);
        throw error;
    }
};

export default FetchApi;
