(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_(pages)_OrderPage_page_tsx_1fa45077._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_(pages)_OrderPage_page_tsx_1fa45077._.js",
  "chunks": [
    "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_bdf89f86._.js",
    "static/chunks/_3f379afb._.js"
  ],
  "source": "dynamic"
});
