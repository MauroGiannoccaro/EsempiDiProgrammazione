(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_layout_tsx_f0e4c1a2._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_layout_tsx_f0e4c1a2._.js",
  "chunks": [
    "static/chunks/[root of the server]__140ccadf._.css",
    "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_bd8a6fd9._.js",
    "static/chunks/node_modules_next_dist_9a2d5fdb._.js"
  ],
  "source": "dynamic"
});
