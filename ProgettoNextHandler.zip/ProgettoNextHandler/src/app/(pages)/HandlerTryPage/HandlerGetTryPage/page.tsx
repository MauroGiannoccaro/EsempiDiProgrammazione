'use client';

import { use, useEffect, useState } from 'react';

export default function Home() {
    
    const [response, setResponse] = useState<string | null>(null);
    const [user, setUser] = useState<{ name: string; email: string } | null>(null);
    const [error, setError] = useState<string | null>(null);

        const fetchData = async () => {
            try {
                const res = await fetch(`/api/sendData`, {
                    method: 'GET',
                });

                const data = await res.json();

                if (!res.ok) {
                    throw new Error(data.error || 'Errore sconosciuto');
                }

                setResponse(data.message);
                setUser(data.user);
                console.log(data);
            } catch (err: any) {
                setError(err.message);
            }
        };
        useEffect(() => {
            fetchData();
        }, []);

        return (
            <main className="p-6 max-w-md mx-auto">
                <div>
                <h1 className="text-2xl font-bold mb-4">Invia Dati all'API</h1>
                </div>
            
                {response && user && (
                    <div className="mt-6 p-4 border rounded">
                        <p>{response}</p>
                        <p><strong>Nome:</strong> {user.name}</p>
                        <p><strong>Email:</strong> {user.email}</p>
                    </div>
                )}

                {error && (
                    <div className="mt-6 p-4 border rounded bg-red-100 text-red-800">
                        Errore: {error}
                    </div>
                )}
            </main>
        );
    }

