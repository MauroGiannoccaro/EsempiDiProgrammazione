'use client';

import { HandlerSecondPageStyles } from '@/app/styles/Styles';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { useState } from 'react';

export default function Home() {
  const router = useRouter();
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [response, setResponse] = useState<string | null>(null);
  const [user, setUser] = useState<{ name: string; email: string } | null>(null);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    setError(null);
    setResponse(null);
    setUser(null);

    try {
      const res = await fetch('/api/sendData', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, email }),
      });

      const data = await res.json();

      if (!res.ok) {
        throw new Error(data.error || 'Errore sconosciuto');
      }

      setResponse(data.message);
      setUser(data.user);
    } catch (err: any) {
      setError(err.message);
    }
  };

  function recoveryPage(): void {
    router.push('/HandlerTryPage/HandlerGetTryPage');
  }
  function recoveryPageServer(): void {
    router.push('/HandlerTryPage/HandlerServerTry');
  }

  return (
    <main className={HandlerSecondPageStyles.container}>
      <h1 className="text-2xl font-bold mb-4 mt-10">Invia Dati all'API</h1>
      <div className="space-y-4 bg-amber-500 p-4 rounded-3xl shadow-2xl shadow-amber-600">
        <form onSubmit={handleSubmit} className="space-y-4">
          <input
            type="text"
            placeholder="Nome"
            value={name}
            onChange={(e) => setName(e.target.value)}
            className="w-full border p-2 rounded  bg-amber-50"
            required
          />
          <input
            type="email"
            placeholder="Email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            className="w-full border p-2 rounded bg-amber-50"
            required
          />
          <button
            type="submit"
            className="bg-blue-600 text-white py-2 px-4 rounded hover:bg-blue-700"
          >
            Invia
          </button>
        </form>
      </div>
      {response && user && (
        <div className="mt-6 p-4 border rounded bg-green-100">
          <p>{response}</p>
          <p><strong>Nome:</strong> {user.name}</p>
          <p><strong>Email:</strong> {user.email}</p>
        </div>
      )}

      {error && (
        <div className="mt-6 p-4 border rounded bg-red-100 text-red-800">
          Errore: {error}
        </div>
      )}
      <button onClick={recoveryPage} className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded"> vai alla recovery page</button>
      <button onClick={recoveryPageServer} className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded"> vai alla recovery page Server Side</button>
      <div>
        <p className='text-amber-900'>Prova di Passaggio dati tramite metodo GET e POST server/client tramite handler</p>
      </div>
    </main>
  );
}
