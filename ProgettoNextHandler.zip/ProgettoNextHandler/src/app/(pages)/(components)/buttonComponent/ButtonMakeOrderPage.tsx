'use client';

import React, { useState } from 'react';

function ButtonMakeOrderPage() {
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);

  const order = {
    cart: [
      { menuItemId: 4, quantity: 1 },
      { menuItemId: 3, quantity: 1 },
      { menuItemId: 6, quantity: 2 }
    ],
    restaurantId: 1
  };

  const sendOrder = async () => {
    setLoading(true);
    setSuccess(false);
    try {
      const response = await fetch('http://localhost:3000/api/postOrder', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(order),
      });

      if (!response.ok) {
        throw new Error('Impossibile effettuare l\'ordine');
      }

      const data = await response.json();
      console.log(data);
      setSuccess(true);
    } catch (err) {
      console.error('Errore:', err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="p-6">
      <button
        onClick={sendOrder}
        disabled={loading}
        className={`${loading ? 'bg-gray-400' : 'bg-blue-500 hover:bg-blue-700'
          } text-white font-bold py-2 px-4 rounded`}
      >
        {loading ? 'Invio in corso...' : 'Effettua Ordine'}
      </button>

      <div className="mt-4">
        <ul className="list-disc ml-6">
          {success && order.cart.map((item, index) => (
            <li key={index}>
              ID Piatto: {item.menuItemId}, Quantità: {item.quantity}
            </li>
          ))}
        </ul>

        {success && (
          <p className="mt-4 text-green-600 font-semibold">
            Ordine inviato con successo chaimata POST t ok! ✅
          </p>
        )}
      </div>
    </div>
  );
}

export default ButtonMakeOrderPage;
