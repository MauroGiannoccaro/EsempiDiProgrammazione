"use client";

import { useRouter } from 'next/navigation';
import React, { useState } from 'react';

function InputOrdercomponent() {
    const [orderId, setOrderId] = useState(""); 
    const [onChangeStatus, setOnChangeStatus] = useState(true); 
    const router = useRouter();

    interface InputChangeEvent extends React.ChangeEvent<HTMLInputElement> {}

    function handleInputChange(e: InputChangeEvent): void {
        const id = e.target.value;
        setOrderId(id);
        if (id.length > 0) {
            setOnChangeStatus(false);
            console.log(id, onChangeStatus);
        }
        else {
            setOnChangeStatus(true);
        }

    }

    function handleClick() {
            router.push(`/OrderPage?id=${orderId}`);
        
    }
    console.log(onChangeStatus);
    return (
        <div className="flex flex-col items-center gap-3 bg-amber-500 p-4 shadow-2xl shadow-amber-600 rounded-3xl">
            <input 
                type="text" 
                className="border-amber-700 p-2 mb-4 bg-amber-100 rounded" 
                placeholder="scrivi l' id da cercare" 
                onChange={handleInputChange} 
            />
            <button 
                className="bg-blue-500 text-white p-2 rounded" 
                onClick={handleClick}
                disabled={onChangeStatus} 
            >
                Search Order
            </button>
        </div>
    );
}

export default InputOrdercomponent;
