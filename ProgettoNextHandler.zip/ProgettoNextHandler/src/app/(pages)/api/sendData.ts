import { NextApiRequest, NextApiResponse } from 'next';

interface RequestBody {
  name: string;
  email: string;
}

interface ResponseData {
  message: string;
  user: {
    name: string;
    email: string;
  };
}

interface ErrorResponse {
  error: string;
}

export default function handler(
  req: NextApiRequest,
  res: NextApiResponse<ResponseData | ErrorResponse>
) {
  if (req.method === 'POST') {
    const { name, email } = req.body as RequestBody;

    console.log('Ricevuto via POST:', { name, email });

    return res.status(200).json({
      message: 'Ricevuto con successo via POST!',
      user: { name, email },
    });
  }

  if (req.method === 'GET') {
    const { name, email } = req.query;

    console.log('Ricevuto via GET:', { name, email });

    // Check tipo stringa
    if (typeof name !== 'string' || typeof email !== 'string') {
      return res.status(400).json({ error: 'Parametri GET non validi' });
    }

    return res.status(200).json({
      message: 'Ricevuto con successo via GET!',
      user: { name, email },
    });
  }

  // Metodo non consentito
  res.setHeader('Allow', ['POST', 'GET']);
  return res.status(405).json({ error: `Metodo ${req.method} non consentito` });
}
