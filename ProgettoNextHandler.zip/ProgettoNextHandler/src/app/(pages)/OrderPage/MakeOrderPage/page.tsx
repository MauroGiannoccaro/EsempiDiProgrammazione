import { OrderPageStyles } from "@/app/styles/Styles";
import ButtonMakeOrderPage from "../../(components)/buttonComponent/ButtonMakeOrderPage";
import OrderPage from "../page";

async function MakeOrderPage() {
  let loading = false;
  const order = {
    cart: [
      { menuItemId: 4, quantity: 1 },
      { menuItemId: 3, quantity: 1 },
      { menuItemId: 6, quantity: 2 },
    ],
    restaurantId: 1,
  };

  function MakeOrderPage() {
    loading = true;
  }

  return (
    <div className={OrderPageStyles.container}>
      <div className="flex flex-col items-center justify-center bg-amber-500 w-[300px] h-[300px] mt-20 rounded-lg shadow-lg">
        <h1>Ordina</h1>
        <p>Ristorante: {order.restaurantId}</p>
        <p>Carrello:</p>
        <ul>
          {order.cart.map((item, index) => (
            <li key={index}>
              ID Piatto: {item.menuItemId}, Quantità: {item.quantity}
            </li>
          ))}
        </ul>
        <p>Totale: {order.cart.reduce((acc, item) => acc + item.quantity, 0)} piatti</p>
      </div>
      <ButtonMakeOrderPage />  
      <div>
        <p className='text-amber-900'>Chiamata Post all' API oggetto restituito unico</p>
      </div>
    </div>
  );
} export default MakeOrderPage;
