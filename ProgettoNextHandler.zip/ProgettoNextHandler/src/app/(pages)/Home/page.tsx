import Link from 'next/link'
import React from 'react'
import Navbar from '../(components)/navbar/navbar'

function Home() {
    return (
        <div>
            <div className="mt-10 flex flex-col items-center justify-center">
                <p className='text-6xl bg-gradient-to-r from-green-900 to-green-500 shadow-2xl shadow-emerald-950 rounded-2xl text-blue-50'>RESTAURANTS APP</p>
            </div>
            <div className="flex flex-col items-center justify-center h-[500px]">
                <div className="mt-100 shadow-2xs shadow-blue-400">
                    <img src="https://dynamic-media-cdn.tripadvisor.com/media/photo-o/28/ed/35/95/terrazza-da-romano.jpg?w=1000&h=-1&s=1" alt="Immagine di sfondo" className="w-[1000px] h-[800px] object-cover shadow-2xl rounded-2xl shadow-green-900" />
                </div>
            </div>
        </div>
    )
}

export default Home