
import { HandlerPageStyles } from '@/app/styles/Styles';
import HandlerComponent from '../(components)/buttonComponent/HandlerComponent';

import React from 'react'

function HandlerPage() {

  return (
    <div className={HandlerPageStyles.container}>
      <HandlerComponent />
      <div>
        <p className='text-amber-900'>Prova di Passaggio dati tramite metodo GET e POST su un endpoint interno</p>
      </div>
    </div>
  );
}
export default HandlerPage