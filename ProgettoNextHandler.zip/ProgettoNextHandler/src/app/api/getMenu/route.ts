import { Menu, Rest, Restaurants } from "@/app/types/Type";
import { NextRequest, NextResponse } from "next/server";

export async function GET(request: NextRequest) {
    try {
        const id = request.nextUrl.searchParams.get("id") || "1";
        console.log(id);
        if (!id) {
            return NextResponse.json({ error: "ID mancante" }, { status: 400 });
        }
        const response = await fetch(`https://private-anon-2bda3e7dee-pizzaapp.apiary-mock.com/restaurants/${id}/menu`, {
            cache: "no-store",
        });
        if (!response.ok) {
            throw new Error(`Errore nella fetch esterna: ${response.status}`);
        }

        const data : Menu = await response.json();

        console.log(data);

        return NextResponse.json({ Menu: data });
    } catch (error) {
        console.error("Errore nella API route:", error);
        return NextResponse.json({ error: "Errore nell'API" }, { status: 500 });
    }
}
