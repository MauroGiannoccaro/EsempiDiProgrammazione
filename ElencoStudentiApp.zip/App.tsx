

import { NavigationContainer } from '@react-navigation/native';
import React from 'react';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import Elenco from './src/pages/Elenco';

import { Text } from 'react-native';
import Homepage from './src/pages/Homepage';
import Studenti from './src/pages/Studenti';


type TabsParam = {
  Homepage: undefined,
  Studenti: undefined,
}

function App(): React.JSX.Element {

  const Tabs = createBottomTabNavigator<TabsParam>()
  
  return (
   <NavigationContainer>
   <Tabs.Navigator>
     <Tabs.Screen name="Homepage" component={Homepage} options={{tabBarIcon:()=><Text>🦘</Text>}} />
     <Tabs.Screen name="Studenti" component={Studenti}  options={{tabBarIcon:()=><Text>🧑‍🎓​</Text>}}/>
   </Tabs.Navigator>
   </NavigationContainer>
  );
}


export default App;