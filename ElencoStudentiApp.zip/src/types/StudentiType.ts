export type Root = Studenti[]

export interface Studenti {
  cognome: string
  nome: string
  comuneNascita: string
  provNascita: string
  dataNascita: string
  capResidenza: string
  comuneResidenza: string
  provResidenza: string
  indirizzoResidenza: string
  emailPrincipale: string
  cell: string
  codiceFiscale: string
  matricola: string
  emailSecondaria: string
  foto: string
}
