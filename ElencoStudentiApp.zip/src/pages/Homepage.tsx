import React from 'react';
import { GestureResponderEvent, Image, Linking, SafeAreaView, Text, TouchableOpacity } from 'react-native';
import homeStyle from '../Styles/styles';

const Homepage = () => {
  
  
  const openVernazza = (event: GestureResponderEvent): void => {
    const url = 'https://www.palazzovernazza.it/';
    Linking.canOpenURL(url)
      .then((supported) => {
        if (!supported) {
          Linking.openURL(url);
        } else {
          console.error("Impossibile aprire l'URL: " + url);
        }
      })
      .catch((err) => console.error('Errore nell\'apertura del link:', err));
  };

  return (
    <SafeAreaView style={homeStyle.container}>
      <Text style={homeStyle.title}>Palazzo Vernazza</Text>
      <Text>
      Palazzo Vernazza è un gioiello dell’architettura rinascimentale leccese che custodisce nelle sue fondamenta millenni di storia, testimoniati dai ritrovamenti  archeologici presenti a livello sotterraneo che attestano la frequentazione del sito sin dall’Età del Ferro (IX-VII a.C.). Tra i palazzi nobiliari più antichi del capoluogo salentino (la sua torre è datata fine  XV sec. d.C.)  l’edificio è di proprietà della Fondazione Casa Bianca, impegnata nello sviluppo sociale e culturale del territorio. La Fondazione senza scopo di lucro, dal 2011 ha aperto le porte per rivitalizzare il legame di Palazzo Vernazza con la città di Lecce, restituendolo –  al termine di un lungo intervento di recupero – non solo come patrimonio monumentale da tutelare e conservare, ma come spazio d’avanguardia dedicato allo sviluppo di progettualità crossmediali nell’ambito della Cultura 4.0. Infatti, oggi l’edificio è uno spazio culturale polifunzionale che ospita anche  l‘ITS Apulia Digital Maker – operante nella  formazione professionalizzante nel settore ICT –  e realtà imprenditoriali, come la Mediafarm.it,  sintonizzate su un’unica mission: dare un impulso vitale d’innovazione alla valorizzazione del patrimonio storico e culturale.</Text>
      <Image
        style={homeStyle.image}
        source={{
          uri: 'https://upload.wikimedia.org/wikipedia/commons/d/d0/Piazza_Sant%27Oronzo_%28Lecce%29.jpg',
        }}
        resizeMode="cover"
      />
      <TouchableOpacity style={homeStyle.button} onPress={openVernazza}>
        <Text style={homeStyle.buttonText}>Visita il Palazzo Vernazza</Text>
      </TouchableOpacity>
    </SafeAreaView>
  );
};

export default Homepage;
