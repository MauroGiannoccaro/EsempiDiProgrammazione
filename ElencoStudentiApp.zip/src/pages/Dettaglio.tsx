import {NativeStackScreenProps} from '@react-navigation/native-stack';
import React, {useEffect, useState} from 'react';
import {StackParam} from './Studenti';
import CardDettaglio from '../components/CardDettaglio';



type Props = NativeStackScreenProps<StackParam, 'Dettaglio'>;

const Dettaglio = ({route}: Props) => {

  

  return  (
    <CardDettaglio dettaglio={route.params.item} ></CardDettaglio>
  ) 
};

export default Dettaglio;
