import React, {useEffect, useState} from 'react';
import {FlatList, Text, TouchableOpacity, View} from 'react-native';
import PokemonCard from '../components/StudentiCard';
import {NativeStackScreenProps} from '@react-navigation/native-stack';
import {StackParam} from './Studenti';
import { Studenti } from '../types/StudentiType';
import StudentiCard from '../components/StudentiCard';
import Dettaglio from './Dettaglio';
import style from '../components/StudentiCardStyle';
import homeStyle from '../Styles/styles';

type Props = NativeStackScreenProps<StackParam, 'Elenco'>;

const Elenco = (props: Props) => {
  const [url, setUrl] = useState('https://raw.githubusercontent.com/alemarra89/its2325/main/alunni.json');
  const [listaStudenti, setListaStudenti] = useState<Studenti[]>([]);
  
  
  
  const getData = () => {
    fetch(url)
      .then(response => response.json())
      .then((data) => {
        setListaStudenti(prev => [...listaStudenti, ...data]);
      });
  };
  useEffect(() => {
    getData();
  }, []);
  
  useEffect(() => {
    getData();
  }, []);
  return (
    <View style={homeStyle.container}>
      <Text style={homeStyle.title}>STUDENTI</Text>
      <FlatList 
        data={listaStudenti}
        renderItem={({item, index}) => (
          <StudentiCard
            name={item.nome}
            cognome={item.cognome}
            foto={item.foto}
            index={index + 1}
            goToDetails={() =>
              props.navigation.navigate('Dettaglio', {item} )
            }
          />
        )}
        
        ListFooterComponent={
          <TouchableOpacity onPress={getData}>
            <View>
              <Text>Carica altri Studenti</Text>
            </View>
          </TouchableOpacity>
        }
      />
    </View>
  );
};

export default Elenco;
