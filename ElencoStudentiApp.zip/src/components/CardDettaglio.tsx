import React from 'react';
import {View, Text, TouchableOpacity, Image} from 'react-native';
import { Studenti } from '../types/StudentiType';
import style from './StudentiCardStyle';
import DettaglioStyle from './DettaglioCard';

interface Props {
  dettaglio: Studenti
}

const CardDettaglio: React.FC<Props> = dettaglio => {
  const imageUri = dettaglio.dettaglio.foto;
  return (
    <View style={DettaglioStyle.card} >
      <Image 
        source={{ uri: imageUri }} 
        style={{ width: 100, height: 100 }}/>

      <Text >Nome: {dettaglio.dettaglio.nome} Cognome:{dettaglio.dettaglio.cognome}</Text>

      <Text>Matricola: {dettaglio.dettaglio.matricola}</Text>

      <Text>Data di Nascita:{dettaglio.dettaglio.dataNascita}</Text>

      <Text>Indirizzo di Residenza: {dettaglio.dettaglio.indirizzoResidenza}</Text>

      <Text>Codice Fiscale: {dettaglio.dettaglio.codiceFiscale}</Text>

      <Text>Comune di Nascita: {dettaglio.dettaglio.comuneNascita}</Text>
     
    </View>
  );
};

export default CardDettaglio;
