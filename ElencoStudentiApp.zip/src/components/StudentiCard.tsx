import React from 'react';
import {
  View,
  Text,
  Image,
  TouchableOpacity,
  GestureResponderEvent,
} from 'react-native';
import style from './StudentiCardStyle';

interface Props {
  name: string;
  cognome: string;
  foto: string;
  index: number;
  goToDetails: () => void;
}

const StudentiCard: React.FC<Props> = ({name, cognome, index, foto, goToDetails}) => {
  const imageUri = foto;
  return (
    <TouchableOpacity style={style.card} onPress={goToDetails}>
      <Image 
        source={{ uri: imageUri }} 
        style={{ width: 100, height: 100 }}/>
      <Text>{name} {cognome}</Text> 
            
    </TouchableOpacity>
  );
};

export default StudentiCard;
