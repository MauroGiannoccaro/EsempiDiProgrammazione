import { StyleSheet } from "react-native";

const style = StyleSheet.create({
  card: {
    flexDirection: 'row',
    padding: 20,
    margin: 10,
    backgroundColor: "white",
    borderTopRightRadius: 20,
    borderBottomLeftRadius: 20,
  },
  
  title: {
    fontSize: 24,
    fontWeight: 'bold',
  }
});

export default style;