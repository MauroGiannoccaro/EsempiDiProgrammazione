import { StyleSheet } from "react-native";

const DettaglioStyle = StyleSheet.create({
  card: {
    flexDirection: "column",
    padding: 20,
    margin: 10,
    backgroundColor: "white",
    borderTopRightRadius: 20,
    borderBottomLeftRadius: 20,
  },
  
  title: {
    fontSize: 24,
    fontWeight: 'bold',
  }
});

export default DettaglioStyle;