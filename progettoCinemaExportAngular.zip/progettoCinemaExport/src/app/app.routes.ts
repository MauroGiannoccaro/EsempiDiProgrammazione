import { Routes } from '@angular/router';
import { HomePageComponent } from './pages/home-page/home-page.component';
import { PageNotFoundComponent } from './pages/page-not-found/page-not-found.component';
import { InProgrammazioneComponent } from './pages/in-programmazione/in-programmazione.component';
import { ContattiComponent } from './pages/contatti/contatti.component';
import { PrezziComponent } from './pages/prezzi/prezzi.component';
import { ContattiStep1Component } from './pages/contatti/contatti-step1/contatti-step1.component';
import { ContattiStep2Component } from './pages/contatti/contatti-step2/contatti-step2.component';
import { ContattiConfermaComponent } from './pages/contatti/contatti-conferma/contatti-conferma.component';
import { DettaglioPrezziComponent } from './pages/prezzi/dettaglio-prezzi/dettaglio-prezzi.component';
import { ObservableTestComponent } from './pages/observable-test/observable-test.component';
import { authGuard } from './auth/auth.guard';

export const routes: Routes = [
  { path: "observableTest", component: ObservableTestComponent },
  { path: "", redirectTo: "/homePage", pathMatch: "full" },
  { path: "homePage", component: HomePageComponent },
  { path: "inProgrammazione", component: InProgrammazioneComponent },
  {
    path: "prezzi", component: PrezziComponent, canActivate: [authGuard], children: [
      { path: "dettaglioPrezzi", component: DettaglioPrezziComponent },
    ]
  },
  { path: "contatti", component: ContattiComponent },
  { path: "contatti/contattistep1", component: ContattiStep1Component },
  { path: "contatti/contattistep2", component: ContattiStep2Component },
  { path: "contatti/contatticonferma", component: ContattiConfermaComponent },
  { path: "**", redirectTo: "page404" },
  { path: "page404", component: PageNotFoundComponent },
];
