import { AfterViewInit, Component, ElementRef, OnDestroy, OnInit, Renderer2, ViewChild } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { Modules } from './modules';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-root',
  imports: [RouterOutlet, Modules],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})

export class AppComponent {
  title = 'progetto-cinema';
  @ViewChild('mainContainer') mainContainer!: ElementRef;
  theme = 'light-theme';

  private _theme = Subscription;

  constructor(private renderer: Renderer2) { }

  toggleTheme(): void {
    this.theme = this.theme === 'light-theme' ? 'dark-theme' : 'light-theme';
    this.renderer.setAttribute(this.mainContainer.nativeElement, 'data-theme', this.theme);
    console.log('Tema cambiato a:', this.theme);
  }

}
