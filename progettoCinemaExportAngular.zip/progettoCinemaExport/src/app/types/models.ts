export interface Root {
  Search: FilmSearch[]
  totalResults: string
  Response: string
}

export interface FilmSearch {
  Title: string
  Year: string
  imdbID: string
  Type: string
  Poster: string
}

export interface Prezzi {
  categoria: string
  prezzo: number
}
