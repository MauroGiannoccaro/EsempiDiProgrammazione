import { CommonModule, NgClass } from "@angular/common";
import { HttpClientModule, HTTP_INTERCEPTORS } from "@angular/common/http";
import { NgModule, importProvidersFrom, CUSTOM_ELEMENTS_SCHEMA } from "@angular/core";
import { RouterModule } from "@angular/router";
import { HomePageComponent } from "./pages/home-page/home-page.component";
import { PageNotFoundComponent } from "./pages/page-not-found/page-not-found.component";
import { ReactiveFormsModule } from '@angular/forms';
import { MatSelectModule } from '@angular/material/select';
import { MatInputModule } from '@angular/material/input';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatButtonModule } from '@angular/material/button';
import { AuthInterceptor } from "./services/auth-Interceptor/auth.interceptor";
import { InProgrammazioneComponent } from "./pages/in-programmazione/in-programmazione.component";
import { MatMenuModule } from '@angular/material/menu';
import { HeaderComponent } from "./pages/components/header/header.component";
import { FooterComponent } from "./pages/components/footer/footer.component";
import { PrezziComponent } from "./pages/prezzi/prezzi.component";
import { ContattiComponent } from "./pages/contatti/contatti.component";
import { TemplateComponent } from "./pages/components/template/template.component";
import { SidebarComponent } from "./pages/components/sidebar/sidebar.component";
import { CaruselComponent } from "./pages/components/carusel/carusel.component";
import { ContattiStep1Component } from "./pages/contatti/contatti-step1/contatti-step1.component";
import { ContattiStep2Component } from "./pages/contatti/contatti-step2/contatti-step2.component";
import { ContattiConfermaComponent } from "./pages/contatti/contatti-conferma/contatti-conferma.component";
import { Page404Component } from "./pages/page404/page404.component";
import { ContattiService } from "./services/contatti.service.service";
import { AppComponent } from "./app.component";
import { DettaglioPrezziComponent } from "./pages/prezzi/dettaglio-prezzi/dettaglio-prezzi.component";
import { ObservableTestComponent } from "./pages/observable-test/observable-test.component";

@NgModule({
  declarations: [
    HomePageComponent,
    PageNotFoundComponent,
    InProgrammazioneComponent,
    HeaderComponent,
    FooterComponent,
    PrezziComponent,
    ContattiComponent,
    SidebarComponent,
    CaruselComponent,
    ContattiStep1Component,
    ContattiStep2Component,
    ContattiConfermaComponent,
    Page404Component,
    DettaglioPrezziComponent,
    ObservableTestComponent,
  ],
  imports: [
    CommonModule,
    RouterModule,
    ReactiveFormsModule,
    MatSelectModule,
    MatInputModule,
    MatFormFieldModule,
    MatButtonModule,
    MatMenuModule,
    TemplateComponent,
    NgClass,
  ],
  exports: [
    HomePageComponent,
    PageNotFoundComponent,
    InProgrammazioneComponent,
    HeaderComponent,
    FooterComponent,
    PrezziComponent,
    ContattiComponent,
    SidebarComponent,
    CaruselComponent,
    ContattiStep1Component,
    ContattiStep2Component,
    ContattiConfermaComponent,
    Page404Component,
    DettaglioPrezziComponent,
    ObservableTestComponent,
  ],
  providers: [
    importProvidersFrom(HttpClientModule),
    {
      provide: [HTTP_INTERCEPTORS, ContattiService],
      useClass: AuthInterceptor,
      multi: true
    },
  ],
  schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class Modules { }
