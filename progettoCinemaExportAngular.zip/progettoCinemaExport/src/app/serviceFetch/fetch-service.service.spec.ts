import { TestBed } from '@angular/core/testing';

import { fetchServiceService } from './fetch-service.service';

describe('FetchServiceService', () => {
  let service: fetchServiceService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(fetchServiceService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
