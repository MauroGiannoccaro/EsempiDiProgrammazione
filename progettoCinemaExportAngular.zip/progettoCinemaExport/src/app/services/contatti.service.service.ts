import { Injectable } from '@angular/core';

@Injectable({ providedIn: 'root' })
export class ContattiService {
  dati = {
    nome: '',
    email: '',
    messaggio: ''
  };

  reset() {
    this.dati = { nome: '', email: '', messaggio: '' };
  }
}
