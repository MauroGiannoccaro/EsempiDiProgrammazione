import { TestBed } from '@angular/core/testing';

import { ContattiServiceService } from './contatti.service.service';

describe('ContattiServiceService', () => {
  let service: ContattiServiceService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ContattiServiceService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
