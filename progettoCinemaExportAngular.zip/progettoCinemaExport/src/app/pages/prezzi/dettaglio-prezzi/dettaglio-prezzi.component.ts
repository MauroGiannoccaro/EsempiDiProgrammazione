import { Component, Input } from '@angular/core';
import { Prezzi } from '../../../types/models';

@Component({
  selector: 'app-dettaglio-prezzi',
  standalone: false,
  templateUrl: './dettaglio-prezzi.component.html',
  styleUrl: './dettaglio-prezzi.component.css'
})
export class DettaglioPrezziComponent {
 @Input() prezzoBiglietti: Prezzi []= [];

 constructor(){}

 ngOnInit(): void {
  console.log("detaglio", this.prezzoBiglietti);
 }
}
