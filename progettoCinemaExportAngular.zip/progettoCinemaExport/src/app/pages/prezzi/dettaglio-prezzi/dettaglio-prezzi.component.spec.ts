import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DettaglioPrezziComponent } from './dettaglio-prezzi.component';

describe('DettaglioPrezziComponent', () => {
  let component: DettaglioPrezziComponent;
  let fixture: ComponentFixture<DettaglioPrezziComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [DettaglioPrezziComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(DettaglioPrezziComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
