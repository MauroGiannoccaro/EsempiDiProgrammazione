import { Component, ElementRef, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { Subscription, fromEvent } from 'rxjs';

@Component({
  selector: 'app-observable-test',
  standalone: false,
  templateUrl: './observable-test.component.html',
  styleUrl: './observable-test.component.css'
})
export class ObservableTestComponent implements OnInit, OnDestroy {
  @ViewChild('box') boxRef!: ElementRef;
  mouseX = 0;
  mouseY = 0;

  private mouseMoveSub!: Subscription;

  ngOnInit() { }

  ngAfterViewInit() {
    this.mouseMoveSub = fromEvent<MouseEvent>(this.boxRef.nativeElement, 'mousemove')
      .subscribe(event => {
        this.mouseX = event.offsetX;
        this.mouseY = event.offsetY;
      });
  }
  ngOnDestroy() {
    // buona pratica: disiscriversi
    if (this.mouseMoveSub) {
      this.mouseMoveSub.unsubscribe();
    }
  }
}
