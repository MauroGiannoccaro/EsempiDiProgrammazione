import { Component } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';

@Component({
  selector: 'app-contatti',
  standalone: false,
  templateUrl: './contatti.component.html',
  styleUrl: './contatti.component.css'
})
export class ContattiComponent {
  formContatti: FormGroup;
  messaggioInviato = false;
  datiInviati: { nome: string; email: string; messaggio: string } = {
    nome: '',
    email: '',
    messaggio: ''
  };

  constructor(private fb: FormBuilder) {
    this.formContatti = this.fb.group({
      nome: ['', Validators.required],
      email: ['', [Validators.required, Validators.email]],
      messaggio: ['', Validators.required]
    });
  }

  invia() {
    if (this.formContatti.valid) {
      console.log(this.formContatti.value);
      this.messaggioInviato = true;
      this.datiInviati = this.formContatti.value;
      this.formContatti.reset();
    }
  }
}
