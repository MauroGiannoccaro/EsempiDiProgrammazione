import { Component } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ContattiService } from '../../../services/contatti.service.service';

@Component({
  selector: 'app-contatti-step1',
  standalone: false,
  templateUrl: './contatti-step1.component.html',
  styleUrls: ['./contatti-step1.component.css']
})
export class ContattiStep1Component {
  form: any;
  constructor(private fb: FormBuilder, private router: Router, public contattiService: ContattiService) {
    this.form = this.fb.group({
    nome: [this.contattiService.dati.nome, Validators.required],
    email: [this.contattiService.dati.email, [Validators.required, Validators.email]]
  });
  }


  avanti() {
    if (this.form.valid) {
      this.contattiService.dati.nome = this.form.value.nome!;
      this.contattiService.dati.email = this.form.value.email!;
      this.router.navigate(['/contatti/contattistep2']);
    }
  }
}
