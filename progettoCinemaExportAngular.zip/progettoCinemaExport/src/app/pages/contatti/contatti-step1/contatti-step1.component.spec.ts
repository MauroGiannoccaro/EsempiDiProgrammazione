import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ContattiStep1Component } from './contatti-step1.component';

describe('ContattiStep1Component', () => {
  let component: ContattiStep1Component;
  let fixture: ComponentFixture<ContattiStep1Component>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ContattiStep1Component]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ContattiStep1Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
