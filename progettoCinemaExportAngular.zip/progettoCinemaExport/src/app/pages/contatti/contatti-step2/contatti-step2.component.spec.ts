import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ContattiStep2Component } from './contatti-step2.component';

describe('ContattiStep2Component', () => {
  let component: ContattiStep2Component;
  let fixture: ComponentFixture<ContattiStep2Component>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ContattiStep2Component]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ContattiStep2Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
