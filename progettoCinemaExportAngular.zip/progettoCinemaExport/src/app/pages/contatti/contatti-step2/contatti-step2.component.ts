import { Component } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ContattiService } from '../../../services/contatti.service.service';


@Component({
  selector: 'app-contatti-step2',
  standalone: false,
  templateUrl: './contatti-step2.component.html',
  styleUrls: ['./contatti-step2.component.css'],
})
export class ContattiStep2Component {
  form: any;
  constructor(private fb: FormBuilder, private router: Router, public contattiService: ContattiService) {
  this.form = this.fb.group({
    messaggio: [this.contattiService.dati.messaggio, Validators.required]
  });
  }


  indietro() {
    this.router.navigate(['/contatti/contattistep1']);
  }

  invia() {
    if (this.form.valid) {
      this.contattiService.dati.messaggio = this.form.value.messaggio!;
      console.log('Dati inviati:', this.contattiService.dati);
      this.router.navigate(['/contatti/contatticonferma']);
    }
  }
}
