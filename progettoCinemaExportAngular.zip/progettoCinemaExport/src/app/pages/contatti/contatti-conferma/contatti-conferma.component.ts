import { Component } from '@angular/core';
import { ContattiService } from '../../../services/contatti.service.service';


@Component({
  selector: 'app-contatti-conferma',
  standalone: false,
  templateUrl: './contatti-conferma.component.html',
  styleUrls: ['./contatti-conferma.component.css']
})
export class ContattiConfermaComponent {
  constructor(public contattiService: ContattiService) {}
}
