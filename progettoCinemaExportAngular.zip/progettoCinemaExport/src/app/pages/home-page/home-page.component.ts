import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-home-page',
  standalone: false,
  templateUrl: './home-page.component.html',
  styleUrl: './home-page.component.css'
})
export class HomePageComponent implements OnInit {

  page: string = 'Programmazione';

  apiKey = '76ad0e02';
  url = `http://www.omdbapi.com/?apikey=${this.apiKey}&s=star+wars`;

  constructor(private http: HttpClient) { }

  ngOnInit(): void {
    this.getData(this.url);
  }

  getData(url: string) {
    this.http.get(url).subscribe({
      next: data => {
        console.log(data);
      },
      error: error => {
        console.error('Error:', error);
      }
    });
  }

  setContent(page: string) {
    this.page = page;
  }
}
