import { Component } from '@angular/core';

@Component({
  selector: 'app-carusel',
  standalone: false,
  templateUrl: './carusel.component.html',
  styleUrl: './carusel.component.css'
})
export class CaruselComponent {
  slideIndex = 0;
  slides: string[] = [
    'https://via.placeholder.com/800x300?text=Slide+1',
    'https://via.placeholder.com/800x300?text=Slide+2',
    'https://via.placeholder.com/800x300?text=Slide+3'
  ];
  intervalId: any;

  ngOnInit() {
    this.startSlideshow();
  }

  ngOnDestroy() {
    clearInterval(this.intervalId);
  }

  startSlideshow() {
    this.intervalId = setInterval(() => {
      this.slideIndex = (this.slideIndex + 1) % this.slides.length;
    }, 2000);
  }
}
