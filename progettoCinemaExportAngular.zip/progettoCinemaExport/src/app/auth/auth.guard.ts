import { inject } from '@angular/core';
import { CanActivateFn } from '@angular/router';
import { GuardService } from './guard.service';

export const authGuard: CanActivateFn = (route, state): boolean => {
  const authService = inject(GuardService);
  const isLoggedIn = GuardService.isLoggedIn();
  console.log('isLoggedIn:', isLoggedIn);
  return isLoggedIn;
};
