import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class GuardService {
  static isLoggedIn () : boolean {
    return true;
  }

  constructor() { }
}
