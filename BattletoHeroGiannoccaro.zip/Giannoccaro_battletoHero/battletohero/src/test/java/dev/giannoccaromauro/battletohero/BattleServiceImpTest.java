package dev.giannoccaromauro.battletohero;

import dev.giannoccaromauro.battletohero.models.Battle;
import dev.giannoccaromauro.battletohero.models.Hero;
import dev.giannoccaromauro.battletohero.repository.BattleRepository;
import dev.giannoccaromauro.battletohero.services.HeroService;
import dev.giannoccaromauro.battletohero.services.servicesImp.BattleServiceImp;
import dev.giannoccaromauro.enumModels.Level;
import dev.giannoccaromauro.enumModels.Race;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;

public class BattleServiceImpTest {

    @Mock
    private BattleRepository battleRepository;

    @Mock
    private HeroService heroService;

    @InjectMocks
    private BattleServiceImp battleServiceImp;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testCreateBattleWhenFirstHeroWins() {
        Hero hero1 = new Hero("Artu", Race.WARRIOR, 100, 100, 100, Level.ADVANCED);
        Hero hero2 = new Hero("Lancilotto", Race.WARRIOR, 100, 100, 100, Level.BEGINNER);

        when(heroService.findHeroesDetails(1L)).thenReturn(Optional.of(hero1));
        when(heroService.findHeroesDetails(2L)).thenReturn(Optional.of(hero2));
        when(battleRepository.save(any(Battle.class))).thenReturn(new Battle());

        String result = battleServiceImp.createBattle(1L, 2L);

        assertEquals("Lancilotto ha subito 20 punti di dannoSalute:80", result);
        verify(heroService, times(1)).updateHero(eq(2L), any(Hero.class));
        verify(battleRepository, times(1)).save(any(Battle.class));
    }

    @Test
    void testCreateBattleWhenSecondHeroWins() {
        Hero hero1 = new Hero("Artu", Race.WARRIOR, 100, 100, 100, Level.ADVANCED);
        Hero hero2 = new Hero("Lancilotto", Race.WARRIOR, 100, 100, 100, Level.BEGINNER);

        when(heroService.findHeroesDetails(1L)).thenReturn(Optional.of(hero1));
        when(heroService.findHeroesDetails(2L)).thenReturn(Optional.of(hero2));
        when(battleRepository.save(any(Battle.class))).thenReturn(new Battle());

        String result = battleServiceImp.createBattle(1L, 2L);

        assertEquals("Lancilotto ha subito 20 punti di dannoSalute:80", result);
        verify(heroService, times(1)).updateHero(eq(2L), any(Hero.class));
        verify(battleRepository, times(1)).save(any(Battle.class));
    }

    @Test
    void testFindBattles() {
        Hero hero1 = new Hero("Artu", Race.WARRIOR, 100, 100, 100, Level.ADVANCED);
        Hero hero2 = new Hero("Lancilotto", Race.WARRIOR, 100, 100, 100, Level.BEGINNER);
        String message="battlaglia creata";
        Battle battle1 = new Battle(hero1, hero2, message);
        Battle battle2 = new Battle(hero1, hero2, message);
        List<Battle> battles = Arrays.asList(battle1, battle2);

        when(battleRepository.findAll()).thenReturn(battles);

        List<Battle> result = battleServiceImp.findBattles();

        assertEquals(2, result.size());
        verify(battleRepository, times(1)).findAll();
    }

    @Test
    void testUpdateBattle() {
        Hero hero1 = new Hero("Artu", Race.WARRIOR, 100, 100, 100, Level.ADVANCED);
        Hero hero2 = new Hero("Lancilotto", Race.WARRIOR, 100, 100, 100, Level.BEGINNER);
        String message="battlaglia creata";
        Battle existingBattle = new Battle(hero1, hero2, message);
        Battle updatedBattle = new Battle(hero1, hero2, message);
        

        when(battleRepository.findById(1L)).thenReturn(Optional.of(existingBattle));
        when(battleRepository.save(any(Battle.class))).thenReturn(existingBattle);

        boolean result = battleServiceImp.updateBattle(1L, updatedBattle);

        assertTrue(result);
        verify(battleRepository, times(1)).findById(1L);
        verify(battleRepository, times(1)).save(any(Battle.class));
    }

  /*   @Test
    void testUpdateBattleWhenBattleNotFound() {
        Hero hero1 = new Hero("Artu", Race.WARRIOR, 100, 100, 100, Level.ADVANCED);
        Hero hero2 = new Hero("Lancilotto", Race.WARRIOR, 100, 100, 100, Level.BEGINNER);
        String message="battlaglia creata";
        Battle updatedBattle = new Battle(hero1, hero2, message);;

        when(battleRepository.findById(1L)).thenReturn(Optional.empty());

        boolean result = battleServiceImp.updateBattle(1L, updatedBattle);

        assertFalse(result);
        verify(battleRepository, times(1)).findById(1L);
        verify(battleRepository, never()).save(any(Battle.class));
    }
*/
    @Test
    void testRemoveBattle() {
        when(battleRepository.findById(1L)).thenReturn(Optional.of(new Battle()));

        boolean result = battleServiceImp.removeBattle(1L);

        assertTrue(!result);
        verify(battleRepository, times(1)).findById(1L);
        verify(battleRepository, times(1)).deleteById(1L);
    }

    @Test
    void testRemoveBattleWhenBattleNotFound() {
        when(battleRepository.findById(1L)).thenReturn(Optional.empty());

        boolean result = battleServiceImp.removeBattle(1L);

        assertFalse(result);
        verify(battleRepository, times(1)).findById(1L);
        verify(battleRepository, never()).deleteById(1L);
    }

    @Test
    void testFindBattleDetails() {
        Battle battle = new Battle();
        when(battleRepository.findById(1L)).thenReturn(Optional.of(battle));

        Optional<Battle> result = battleServiceImp.findBattleDetails(1L);

        assertTrue(result.isPresent());
        assertEquals(battle, result.get());
        verify(battleRepository, times(1)).findById(1L);
    }

    @Test
    void testFindBattleDetailsWhenBattleNotFound() {
        when(battleRepository.findById(1L)).thenReturn(Optional.empty());

        Optional<Battle> result = battleServiceImp.findBattleDetails(1L);

        assertFalse(result.isPresent());
        verify(battleRepository, times(1)).findById(1L);
    }
}
