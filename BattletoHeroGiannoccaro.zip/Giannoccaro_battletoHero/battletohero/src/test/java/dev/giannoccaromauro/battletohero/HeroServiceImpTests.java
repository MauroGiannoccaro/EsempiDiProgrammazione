package dev.giannoccaromauro.battletohero;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import dev.giannoccaromauro.battletohero.models.Hero;
import dev.giannoccaromauro.battletohero.repository.HeroRepository;
import dev.giannoccaromauro.battletohero.services.HeroService;
import dev.giannoccaromauro.enumModels.Level;
import dev.giannoccaromauro.enumModels.Race;

@SpringBootTest
class HeroServiceImpTests {

    @Autowired
    private HeroService service;

    @MockBean
    private HeroRepository repository;

    private List<Hero> heroes;

    @Test
    @Order(1)
    void testcreateHero() {

        Hero hero = new Hero("Artu", Race.WARRIOR, 100, 100, 100, Level.BEGINNER);

        Mockito.when(repository.save(hero)).thenReturn(hero);

        Hero CreatedHero = service.createHero(hero);
        assertEquals(hero, CreatedHero);

    }

    @Test
    @Order(2)
    void testHeroesDetails() {

        Hero hero = new Hero("Artu", Race.WARRIOR, 100, 100, 100, Level.BEGINNER);

        Mockito.when(repository.findById(1L))
                .thenReturn(Optional.of((hero)));

        Optional<Hero> findedHero = service.findHeroesDetails(1L);
        assertTrue(!findedHero.isEmpty());

    }

    @BeforeEach
    
    void setUp() {   
        heroes = Arrays.asList(
            new Hero("Artu", Race.WARRIOR, 100, 100, 100, Level.BEGINNER));           
    }

    @Order(3)
    void testfindHeroes() {

        
         Mockito.when(repository.findAll()).thenReturn(heroes);
         

        List<Hero> findedHero = service.findHeroes();
        assertTrue(!findedHero.isEmpty());

    }

    @Test
    @Order(4)
    void testupdateHero() {

        Hero hero = new Hero("Artu", Race.WARRIOR, 100, 100, 100, Level.BEGINNER);

        Mockito.when(repository.findById(1L)).thenReturn(Optional.of(hero));

        Hero HeroToSave = new Hero() {
            {
                setRace(Race.MAGE);
            }
        };
        var esito = service.updateHero(1L, HeroToSave);

        assertTrue(esito);

    }

    @Test
    @Order(5)
    void testremoveHero() {

        Hero hero = new Hero("Artu", Race.WARRIOR, 100, 100, 100, Level.BEGINNER);

        Mockito.when(repository.findById(1L)).thenReturn(Optional.of(hero));

        var esito = service.removeHero(1L);

        assertTrue(esito);

    }


}
