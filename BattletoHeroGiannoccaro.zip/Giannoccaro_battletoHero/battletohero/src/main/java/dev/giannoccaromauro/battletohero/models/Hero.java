package dev.giannoccaromauro.battletohero.models;

import java.util.Objects;

import dev.giannoccaromauro.enumModels.Level;
import dev.giannoccaromauro.enumModels.Race;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Hero {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;
    private String name;
    private Race race;
    private int health;
    private int defence;
    private int strenght;
    private Level level;

    public Hero() {

    }

    public Hero(String name, Race race, int strenght, int defence, int health, Level level) {
        this.name = name;
        this.race = race;
        this.health = health;
        this.level = level;
        this.strenght = strenght;
        this.defence = defence;
    }

    public Long getId() {
        return this.id;
    }

    public String getName() {
        return this.name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Race getRace() {
        return race;
    }

    public void setRace(Race race) {
        this.race = race;
    }

    public int getStrenght() {
        return this.strenght;
    }

    public void setStrenght(int strenght) {
        this.strenght = strenght;
    }

    public int getDefence() {
        return this.defence;
    }

    public void setDefence(int defence) {
        this.defence = defence;
    }

    public int getHealth() {
        return this.health;
    }

    public void setHealth(int health) {
        this.health = health;
    }

    public Level getLevel() {
        return this.level;
    }

    public void setLevel(Level level) {
        this.level = level;
    }

    @Override
    public boolean equals(Object o) {
        if (o == this)
            return true;
        if (!(o instanceof Hero)) {
            return false;
        }
        Hero hero = (Hero) o;
        return Objects.equals(level, hero.level) && Objects.equals(race, hero.race) && id == hero.id
                && Objects.equals(name, hero.name) && health == hero.health && strenght == hero.strenght
                && defence == hero.defence;
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, name, race, health, strenght, defence, level);
    }

    @Override
    public String toString() {
        return "{" +
                " id='" + getId() + "'" +
                ", name='" + getName() + "'" +
                ", race='" + getRace() + "'" +
                ", race='" + getStrenght() + "'" +
                ", race='" + getDefence() + "'" +
                ", health='" + getHealth() + "'" +
                ", level='" + getLevel() + "'" +
                "}";
    }

}
