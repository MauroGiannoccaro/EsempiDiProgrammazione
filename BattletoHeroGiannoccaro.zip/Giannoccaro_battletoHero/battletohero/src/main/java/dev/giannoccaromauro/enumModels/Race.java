package dev.giannoccaromauro.enumModels;

public enum Race {
    MAGE,
    WARRIOR,
    ROUGUE
}
