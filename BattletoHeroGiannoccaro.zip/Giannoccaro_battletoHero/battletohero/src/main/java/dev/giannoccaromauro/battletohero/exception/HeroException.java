package dev.giannoccaromauro.battletohero.exception;

public class HeroException extends RuntimeException {

    public HeroException(String message) {
        super(message);
    }

}
