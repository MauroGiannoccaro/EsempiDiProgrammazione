package dev.giannoccaromauro.battletohero.services;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;
import dev.giannoccaromauro.battletohero.models.Hero;

@Service
public interface HeroService {

    // crea l'eroe
    public Hero createHero(Hero hero);

    // trova gli eroi
    public List<Hero> findHeroes();

    // aggiorna gli eroi
    public boolean updateHero(Long id, Hero hero);

    // rimuovi gli eroi
    public boolean removeHero(Long id);

    // trova l' eroe by id
    public Optional<Hero> findHeroesDetails(Long id);

    //public String createBattle(Long heroe1, Long heroe2);
}
