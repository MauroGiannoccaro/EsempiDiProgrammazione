package dev.giannoccaromauro.battletohero.services;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import dev.giannoccaromauro.battletohero.models.Battle;

@Service
public interface BattleService {


    // crea l'eroe
    public String createBattle(Long hero1, Long hero2);

    // trova gli eroi
    public List<Battle> findBattles();

    // aggiorna gli eroi
    public boolean updateBattle(Long id, Battle battle);

    // rimuovi gli eroi
    public boolean removeBattle(Long id);

    // trova l' eroe by id
    public Optional<Battle> findBattleDetails(Long id);

}  

