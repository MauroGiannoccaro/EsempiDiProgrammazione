package dev.giannoccaromauro.battletohero.services.servicesImp;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.util.Streamable;
import org.springframework.stereotype.Service;
import dev.giannoccaromauro.battletohero.models.Hero;
import dev.giannoccaromauro.battletohero.repository.HeroRepository;
import dev.giannoccaromauro.battletohero.services.HeroService;
import dev.giannoccaromauro.enumModels.Race;

@Service
public class HeroServiceImp implements HeroService {
    @Autowired
    private HeroRepository repository;
    /*@Autowired
    private BattleService battleService;*/
    // crea un nuovo eroe
    public Hero createHero(Hero hero) {

        if (hero.getRace() == Race.WARRIOR || hero.getRace() == Race.MAGE || hero.getRace() == Race.ROUGUE) {
            // se eroe è uneroe valido, lo crea
            if (hero.getHealth() > 0 && hero.getHealth() <= 100) {
                if (hero.getStrenght() > 0 && hero.getStrenght() <= 100) {
                    if (hero.getDefence() > 0 && hero.getDefence() <= 100) {
                        // crea nuovo eroe
                        Hero newHero = new Hero(hero.getName(), hero.getRace(), hero.getHealth(), hero.getStrenght(),
                                hero.getDefence(), hero.getLevel());
                        repository.save(newHero);
                        // salva su db
                        return hero;
                    }
                }
            }
        } else {
            return null;
        }
        // informa sui valori accettati
        return null;
    }

    // Aggiorna eroe
    @SuppressWarnings("unused")
    public boolean updateHero(Long id, Hero heroToUpdate) {
        Optional<Hero> hero = repository.findById(id);
        if (hero != null) {
            hero.get().setName(heroToUpdate.getName());
            hero.get().setRace(heroToUpdate.getRace());
            hero.get().setHealth(heroToUpdate.getHealth());
            hero.get().setLevel(heroToUpdate.getLevel());
            repository.save(hero.get());
            return true;
            // Salva su db
        } else {
            return false;
        }
    }

    // rimuovi eroe by id
    @Override
    public boolean removeHero(Long id) {

        var findedHero = repository.findById(id);
        if (findedHero.isEmpty())
            return false;

        repository.deleteById(id);
        // cancella su db
        return true;

    }

    // trova eroe by id
    @Override
    public Optional<Hero> findHeroesDetails(Long id) {
        // trova su db
        return repository.findById(id);

    }

    // trova eroi
    @Override
    public List<Hero> findHeroes() {
        // ritorna lista d adb
        return Streamable.of(repository.findAll()).toList();
    }

    // crea la battaglia
   /*  @Override
    public String createBattle(Long heroe1, Long heroe2) {
       return  battleService.createBattle(heroe1, heroe2);     
    }*/

}
