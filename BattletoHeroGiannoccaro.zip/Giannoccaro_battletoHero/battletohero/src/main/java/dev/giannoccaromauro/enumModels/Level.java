package dev.giannoccaromauro.enumModels;

public enum Level {
    BEGINNER,
    ADVANCED
}
