package dev.giannoccaromauro.battletohero.models;

import java.util.Objects;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;

@Entity
public class Battle {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;
    @ManyToOne
    @JoinColumn(name = "hero1_id")
    private Hero hero1;
    @ManyToOne
    @JoinColumn(name = "hero2_id")
    private Hero hero2;
    private String message;

    public Battle(Hero hero1, Hero hero2, String message) {
        this.hero1 = hero1;
        this.hero2 = hero2;
        this.message = message;
    }

    public Battle() {

    }

    public Long getId() {
        return this.id;
    }
    public Hero getHero1() {
        return this.hero1;
    }

    public void setHero1(Hero hero1) {
        this.hero1 = hero1;
    }

    public Hero getHero2() {
        return this.hero2;
    }

    public void setHero2(Hero hero2) {
        this.hero2 = hero2;
    }

    public String getMessage() {
        return this.message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public Battle hero1(Hero hero1) {
        setHero1(hero1);
        return this;
    }

    public Battle hero2(Hero hero2) {
        setHero2(hero2);
        return this;
    }

    public Battle message(String message) {
        setMessage(message);
        return this;
    }

    @Override
    public boolean equals(Object o) {
        Battle battle = (Battle) o;
        return Objects.equals(hero1, battle.hero1) && Objects.equals(hero2, battle.hero2) && id == battle.id
                && Objects.equals(message, battle.message);
    }

    @Override
    public int hashCode() {
        return Objects.hash(hero1, hero2, message);
    }

    @Override
    public String toString() {
        return "{" +
                " id='" + getId() + "'" +
                " hero1='" + getHero1() + "'" +
                ", hero2='" + getHero2() + "'" +
                ", message='" + getMessage() + "'" +
                "}";
    }

}
