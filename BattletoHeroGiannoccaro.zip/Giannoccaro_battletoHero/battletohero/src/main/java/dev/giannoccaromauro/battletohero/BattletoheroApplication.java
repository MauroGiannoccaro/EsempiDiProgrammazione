package dev.giannoccaromauro.battletohero;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
public class BattletoheroApplication {

	public static void main(String[] args) {
		SpringApplication.run(BattletoheroApplication.class, args);
	}

}
