package dev.giannoccaromauro.battletohero.controllers;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import dev.giannoccaromauro.battletohero.exception.ErrorResponse;
import dev.giannoccaromauro.battletohero.models.Hero;
import dev.giannoccaromauro.battletohero.services.HeroService;

@RestController
@RequestMapping("/rest")
public class HeroController {

    @Autowired
    private HeroService service;

    @PostMapping("/heroes")
    public String creahero(@RequestBody Hero hero) {
        var esito = service.createHero(hero);
        if (esito!=null){
        return "Eroe aggiunto Correttamente";
        }
        else{
            return "Eroe non aggiunto: (i valori ammessi sono (Race: Mage, Warrior, Archer, Healt: 0-100, Strenght: 0-100, defence: 0-100))";
        }
    }

    @GetMapping("/heroes")
    public List<Hero> findHeroes() {
        return service.findHeroes();
    }

    @GetMapping("/heroes/{id}")
    public Optional<Hero> findHeroesDetails(@PathVariable Long id) {
        return service.findHeroesDetails(id);
    }

    /*@GetMapping("/heroes/battle")
    public String createBattle(@RequestParam Long heroe1, @RequestParam Long heroe2) {
        return  service.createBattle(heroe1, heroe2);
    }*/

    @PutMapping("/heroes/{id}")
    public boolean updateHero(@PathVariable Long id, @RequestBody Hero hero) {
        return service.updateHero(id, hero);
    }

    @DeleteMapping("/heroes/{id}")
    public boolean removeHeroe(@PathVariable Long id) {
        return service.removeHero(id);
    }

    @ControllerAdvice
    public class GlobalExceptionHandler {
        // IllegalArgumentException
        @ExceptionHandler(value = IllegalArgumentException.class)
        @ResponseStatus(HttpStatus.NOT_FOUND)
        public @ResponseBody ErrorResponse handleException(IllegalArgumentException ex) {
            return new ErrorResponse(HttpStatus.NOT_FOUND.value(), ex.getMessage());
        }
    }
}
