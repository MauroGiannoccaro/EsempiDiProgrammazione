package dev.giannoccaromauro.battletohero.controllers;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import dev.giannoccaromauro.battletohero.dto.HeroDto;
import dev.giannoccaromauro.battletohero.exception.ErrorResponse;
import dev.giannoccaromauro.battletohero.models.Battle;
import dev.giannoccaromauro.battletohero.services.BattleService;

@RestController
@RequestMapping("/rest")
public class BattleController {

    @Autowired
    private BattleService service;

    @PostMapping("/battle")
    public String createBattle(@RequestBody HeroDto heroes) {
        var esito = service.createBattle(heroes.getId(), heroes.getId2());
        if (esito!=null){
        return "Battaglia aggiunta Correttamente";
        }
        else{
            return "Battaglia non aggiunta";
        }
    }

    @GetMapping("/battle")
    public List<Battle> findBattles() {
        return service.findBattles();
    }

    @GetMapping("/battle/{id}")
    public Optional<Battle> findBattleDetails(@PathVariable Long id) {
        return service.findBattleDetails(id);
    }

    @PutMapping("/battle/{id}")
    public boolean updateBattle(@PathVariable Long id, @RequestBody Battle battle) {
        return service.updateBattle(id, battle);
    }

    @DeleteMapping("/battle/{id}")
    public boolean removeBattle(@PathVariable Long id) {
        return service.removeBattle(id);
    }

    @ControllerAdvice
    public class GlobalExceptionHandler {
        // IllegalArgumentException
        @ExceptionHandler(value = IllegalArgumentException.class)
        @ResponseStatus(HttpStatus.NOT_FOUND)
        public @ResponseBody ErrorResponse handleException(IllegalArgumentException ex) {
            return new ErrorResponse(HttpStatus.NOT_FOUND.value(), ex.getMessage());
        }
    }
}