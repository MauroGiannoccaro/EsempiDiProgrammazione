package dev.giannoccaromauro.battletohero.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import dev.giannoccaromauro.battletohero.models.Battle;

@Repository
public interface BattleRepository extends CrudRepository<Battle, Long> {

}
