package dev.giannoccaromauro.battletohero.services.servicesImp;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.util.Streamable;
import org.springframework.stereotype.Service;

import dev.giannoccaromauro.battletohero.models.Battle;
import dev.giannoccaromauro.battletohero.models.Hero;
import dev.giannoccaromauro.battletohero.repository.BattleRepository;
import dev.giannoccaromauro.battletohero.services.BattleService;
import dev.giannoccaromauro.battletohero.services.HeroService;
import dev.giannoccaromauro.enumModels.Level;

@Service
public class BattleServiceImp implements BattleService {

    @Autowired
    private BattleRepository battleRepository;
    @Autowired
    private HeroService heroService;
    

    // crea l'eroe
    public String createBattle(Long heroe1, Long heroe2) {
        // implementa la logica di combattimento
        Optional<Hero> firstHeroe = heroService.findHeroesDetails(heroe1);
        Optional<Hero> secondHeroe = heroService.findHeroesDetails(heroe2);
        if (firstHeroe.get().getLevel()==Level.ADVANCED) {
            firstHeroe.get().setHealth(firstHeroe.get().getHealth() + 20);
        }
        if (secondHeroe.get().getLevel() == Level.ADVANCED) {
            secondHeroe.get().setHealth(firstHeroe.get().getHealth() + 20);
        }
        int battleResult = 0;
        int mageBonus = 20;
        int archerBonus = 10;
        if (!firstHeroe.isEmpty() && !secondHeroe.isEmpty() && firstHeroe.get().getHealth() > 0
                && secondHeroe.get().getHealth() > 0) {
            switch (firstHeroe.get().getRace()) {
                case WARRIOR:
                    switch (secondHeroe.get().getRace()) {
                        case MAGE:
                            battleResult = firstHeroe.get().getStrenght()
                                    - (secondHeroe.get().getDefence() + mageBonus);
                        case ROUGUE:
                            battleResult = firstHeroe.get().getStrenght() - secondHeroe.get().getDefence();
                            break;
                        case WARRIOR:
                            battleResult = firstHeroe.get().getStrenght()
                                    - (secondHeroe.get().getDefence() + mageBonus);
                    }
                case MAGE:
                    switch (secondHeroe.get().getRace()) {
                        case WARRIOR:
                            battleResult = (firstHeroe.get().getStrenght() + mageBonus)
                                    - secondHeroe.get().getDefence();
                        case ROUGUE:
                            battleResult = (firstHeroe.get().getStrenght() + mageBonus)
                                    - secondHeroe.get().getDefence();
                            break;
                        case MAGE:
                            battleResult = firstHeroe.get().getStrenght()
                                    - (secondHeroe.get().getDefence() + mageBonus);
                    }
                case ROUGUE:
                    switch (secondHeroe.get().getRace()) {
                        case MAGE:
                            battleResult = (firstHeroe.get().getStrenght() + archerBonus)
                                    - secondHeroe.get().getDefence();
                        case ROUGUE:
                            battleResult = (firstHeroe.get().getStrenght() + archerBonus)
                                    - secondHeroe.get().getDefence();
                            break;
                        case WARRIOR:
                            battleResult = (firstHeroe.get().getStrenght() + mageBonus)
                                    - secondHeroe.get().getDefence();
                    }
            }

        }
        if (battleResult > 0) {
            secondHeroe.get().setHealth(secondHeroe.get().getHealth() - battleResult);
            if (secondHeroe.get().getHealth() <= 0) {
                heroService.updateHero(heroe2, secondHeroe.get());
                String message=firstHeroe.get().getName() + " ha vinto!";
                Battle battle= new Battle(firstHeroe.get(), secondHeroe.get(), message );
                battleRepository.save(battle);
                return message;
            } else {
                heroService.updateHero(heroe2, secondHeroe.get());
                String message=secondHeroe.get().getName() + " ha subito " + battleResult + " punti di danno" + "Salute:"            
                + secondHeroe.get().getHealth();
                Battle battle= new Battle(firstHeroe.get(), secondHeroe.get(), message );
                battleRepository.save(battle);
                return message;

            }
        } else if (battleResult < 0) {
            firstHeroe.get().setHealth(firstHeroe.get().getHealth() - battleResult);
            if (firstHeroe.get().getHealth() <= 0) {
                heroService.updateHero(heroe1, firstHeroe.get());
                String message=(secondHeroe.get().getName() + " ha vinto!");
                Battle battle= new Battle(firstHeroe.get(), secondHeroe.get(), message );
                battleRepository.save(battle);
                return message;
            } else {
                heroService.updateHero(heroe1, firstHeroe.get());
                String message=(firstHeroe.get().getName() + " ha subito " + battleResult + " punti di danno!" + "Salute:"
                + firstHeroe.get().getHealth());
                Battle battle= new Battle(firstHeroe.get(), secondHeroe.get(), message );
                battleRepository.save(battle);
                return message;
            }
        } else {
            return "Nessuno dei due ha subito danni!";
        }
    }

    // trova gli eroi
    public List<Battle> findBattles() {
        return Streamable.of(battleRepository.findAll()).toList();
    }

    // aggiorna gli eroi
    @SuppressWarnings("unused")
    public boolean updateBattle(Long id, Battle battleToUpdate) {
        Optional<Battle> battle = battleRepository.findById(id);
        if (battle != null) {
            battle.get().setHero1(battleToUpdate.getHero1());
            battle.get().setHero2(battleToUpdate.getHero2());
            battle.get().setMessage(battleToUpdate.getMessage());
            battleRepository.save(battle.get());
            return true;
            // Salva su db
        } else {
            return false;
        }
    }

    // rimuovi gli eroi
    public boolean removeBattle(Long id) {

        var findedBattle = battleRepository.findById(id);
        if (findedBattle.isEmpty())
            return false;
        battleRepository.deleteById(id);
        // cancella su db
        return false;
    }

    // trova l' eroe by id
    public Optional<Battle> findBattleDetails(Long id) {
        return battleRepository.findById(id);
    }
}
