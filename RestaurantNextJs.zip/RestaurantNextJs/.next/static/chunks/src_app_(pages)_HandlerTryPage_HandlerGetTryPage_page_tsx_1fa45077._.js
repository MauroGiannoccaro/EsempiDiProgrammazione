(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_(pages)_HandlerTryPage_HandlerGetTryPage_page_tsx_1fa45077._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_(pages)_HandlerTryPage_HandlerGetTryPage_page_tsx_1fa45077._.js",
  "chunks": [
    "static/chunks/_7d0170ba._.js"
  ],
  "source": "dynamic"
});
