(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_(pages)_HandlerTryPage_page_tsx_d527e06b._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_(pages)_HandlerTryPage_page_tsx_d527e06b._.js",
  "chunks": [
    "static/chunks/_687e132d._.js"
  ],
  "source": "dynamic"
});
