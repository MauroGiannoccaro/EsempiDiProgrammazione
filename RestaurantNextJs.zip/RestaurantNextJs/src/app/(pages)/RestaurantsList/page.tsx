

import { RestaurantsPageStyles } from '@/app/styles/Styles';
import { Rest, Restaurants } from '@/app/types/Type';
import React from 'react';

async function RestaurantsList() {
  const response = await fetch(`http://localhost:3000/api/getRestaurants`, {
    cache: "no-store",
  });

  if (!response.ok) {
    throw new Error("Errore nel recupero dei ristoranti");
  }

  const data = await response.json();
  const restaurants: Restaurants[] = data.Restaurants;
  console.log(restaurants);


  return (
    <div className={RestaurantsPageStyles.container}>
      <div className={RestaurantsPageStyles.box}>
      <h1 className="text-xl font-bold text-amber-800">Ristoranti</h1>
      </div>
      <div className={RestaurantsPageStyles.section}>
        {restaurants.map((restaurant : Restaurants) => (
          <div key={restaurant.id} className="p-4 rounded-3xl shadow bg-amber-100 shadow-amber-500 mb-4">
            <p><strong>Title:</strong> {restaurant.name}</p>
            <p><strong>Title:</strong> {restaurant.id}</p>
            <p><strong>ID:</strong> {restaurant.address1}</p>
            <p><strong>User ID:</strong> {restaurant.address2}</p>
            <p><strong>Completed:</strong> {restaurant.latitude}</p>
            <p><strong>Completed:</strong> {restaurant.longitude}</p>
            <p><strong>Completed:</strong> {restaurant.name}</p>
          </div>
        ))}
      </div>
      <div>
      <p className='text-amber-900'>Chiamata GET all' API</p>
      </div>
    </div>
  );
}
export default RestaurantsList;
