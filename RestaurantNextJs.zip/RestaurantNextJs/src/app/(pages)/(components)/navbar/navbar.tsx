import Link from 'next/link'
import React from 'react'

function Navbar() {

    const navMenuItems = [
        {
            label: 'Home',
            href: '/',
            description: 'Home page',
        },
        {
            label: 'Menu',
            href: '/MenuListPage',
            description: 'Menu List Page',
        },
        {
            label: 'Ordine',
            href: '/OrderPage',
            description: 'Order Page',
        },
        {
            label: 'Ristoranti',
            href: '/RestaurantsList',
            description: 'Restaurants List Page',
        },
        {
            label: 'Handler',
            href: '/HandlerPage',
            description: 'Send Data by GET and POST',
        },
        {
            label: 'Handler',
            href: '/HandlerTryPage',
            description: 'Handler Page',
        },
    ];

    return (
        <div className="flex flex-row items-start justify-between bg-green-800 p-4 gap-5 rounded-2xl shadow-green-700 shadow-2xl">
            {
                navMenuItems.map((item, index) => (
                    <div key={index} className="flex flex-col items-center justify-center hover:bg-green-900 p-2 rounded-lg shadow-2xs">
                        <Link href={item.href} className="text-white hover:text-green-300 hover:underline">
                            {item.description}
                        </Link>                        
                    </div>
                ))
            }           
        </div>
    )
}

export default Navbar
