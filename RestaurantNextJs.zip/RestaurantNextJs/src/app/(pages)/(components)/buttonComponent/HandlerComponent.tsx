'use client';

import { useRouter } from 'next/navigation';
import { useEffect, useState } from 'react';
import RecoverDataServer from '../../HandlerPage/RecoverDataServer/page';

function HandlerPage() {
    const router = useRouter();
    const [name, setName] = useState('');
    const [email, setEmail] = useState('');
    const [response, setResponse] = useState(null);

    const sendData = async () => {

        const res = await fetch('/api/sendData', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ name, email }),
        });

        const data = await res.json();
        setResponse(data);
        console.log('POST → Risposta server:', data);
        router.push('/HandlerPage/RecoverDataServer');
    };

    // useEffect(() => {
    //     const fetchData = async () => {
    //         const res = await fetch('/api/sendData');
    //         const data = await res.json();
    //         setResponseGet(data);
    //         console.log('GET → Risposta server:', data);
    //     };

    //     fetchData();
    // }, []);

    return (
        <div className="p-4 mt-10 rounded-3xl shadow-2xl shadow-amber-600 bg-amber-200">
            <h1 className="text-2xl font-bold mb-4">Invia dati al server</h1>

            <input
                className="border p-2 mb-2 block bg-amber-50"
                placeholder="Nome"
                value={name}
                onChange={(e) => setName(e.target.value)}
            />

            <input
                className="border p-2 mb-2 block bg-amber-50"
                placeholder="Email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
            />

            <button
                className="bg-blue-500 text-white p-2 rounded"
                onClick={sendData}
            >
                Invia
            </button>

            {response && (
                <div className="mt-4 p-4 bg-green-100 rounded">
                    <h2 className="font-bold">Risposta POST:</h2>
                    <pre>{JSON.stringify(response, null, 2)}</pre>
                </div>
            )}
        </div>

    );
}
export default HandlerPage;