import { HandlerSecondPageStyles } from '@/app/styles/Styles';
import React from 'react'

async function RecoverDataServer() {

    const res = await fetch('http://localhost:3000/api/sendData', {
        cache: 'no-store',
    });
    const data = await res.json();
    console.log(data);

    return (
        <div className={HandlerSecondPageStyles.container}>
            <div className="mt-10 p-4 bg-yellow-100 rounded">
                <h2 className="font-bold">Dati ricevuti dal server (SSR):</h2>
                <p className='bg-amber-50'><strong>Nome:</strong> {data.user.name}</p>
                <p><strong>Email:</strong> {data.user.email}</p>
            </div>
        </div>
    )
}

export default RecoverDataServer
