import React from 'react'

async function HandlerServerTry() {

    const res = await fetch('http://localhost:3000/api/sendData', {
        cache: 'no-store',
    });
    const data = await res.json();

  return (
    <div>
      {
        data.message && data.user && (
          <div className="mt-6 p-4 border rounded bg-green-100">
            <p>{data.message}</p>
            <p><strong>Nome:</strong> {data.user.name}</p>
            <p><strong>Email:</strong> {data.user.email}</p>
          </div>
        )
      }
    </div>
  )
}

export default HandlerServerTry
