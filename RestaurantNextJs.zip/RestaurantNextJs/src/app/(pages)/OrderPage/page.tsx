import { Order } from '@/app/types/Type';
import React from 'react'
import InputOrdercomponent from '../(components)/buttonComponent/InputOrdercomponent';
import Link from 'next/link';
import { OrderPageStyles } from '@/app/styles/Styles';

type PageProps = {
    searchParams: Promise<{ id?: string[] }>
}

async function OrderPage({ searchParams }: PageProps) {
    const id = (await searchParams)?.id?.[0] || "0";
    console.log("slug", (await searchParams).id);

    let orders: Order | null = null;

    if (id && id !== "0") {
        const response = await fetch(`http://localhost:3000/api/getOrder?id=${id}`, {
            cache: "no-store",
        });

        if (!response.ok) {
            throw new Error("Errore nel recupero dei ristoranti");
        }

        const data = await response.json();
        orders = data.order;
        console.log(orders);
    }

    return (
        <div className={OrderPageStyles.container}>
            <div className={OrderPageStyles.box}>
                <h1 className="text-xl font-bold text-amber-900">Order</h1>
            </div>
            <p className="mb-4 text-amber-800">Scrivi l'ordine da cercare</p>
            <InputOrdercomponent />
            <div className="space-y-2">
                {(orders !== null) ? (
                    <div key={orders.orderId} className="p-4 rounded-3xl shadow-2xl shadow-amber-600 bg-amber-200">
                        <p><strong>ID:</strong> {orders.orderId}</p>
                        <p><strong>Title:</strong> {orders.totalPrice}</p>
                        <p><strong>Data:</strong> {orders.orderedAt.split('T')[0]} ora: {orders.orderedAt.split('T')[1]}</p>
                        <p><strong>Estimated Delivery:</strong> {orders.esitmatedDelivery}</p>
                        <p><strong>Completed:</strong> {orders.status}</p>
                    </div>
                ) : (
                    <p>No orders found.</p>
                )}
            </div>
            <div className="mt-4">
                <div className="bg-amber-500 p-2 rounded-4xl shadow-2xl shadow-amber-600">
                <Link href="/OrderPage/MakeOrderPage" className="text-blue-500 hover:underline">
                    Effettua un Nuovo Ordine
                </Link>
                </div>
            </div>
            <div>
                <p className='text-amber-900'>Chiamata GET by Id oggetto restituito unico</p>
            </div>
        </div>
    );
}
export default OrderPage;