

import React from 'react'
import { MenuList } from '@/app/types/Type';
import { menuPageStylesSection } from '@/app/styles/Styles';


type PageProps = {
  params: Promise<{ slug: string[] }>
}

async function MenuListPage({ params }: PageProps) {
  const { slug } = await params;
  console.log(slug);
  const response = await fetch(`http://localhost:3000/api/getMenu?id=${slug}`, {
    cache: "no-store",
  });
  if (!response.ok) {
    throw new Error("Errore nel recupero dei Menu");
  }

  const data = await response.json();
  const menu: MenuList[] = data.Menu;
  console.log(menu);

  return (
    <div className={menuPageStylesSection.container}>
      <div className={menuPageStylesSection.menuBox}>
      <h1 className={menuPageStylesSection.menuTitle}>Menu</h1>
      </div>
      <div className={menuPageStylesSection.menuContainer}>
        {menu.map((elem: MenuList) => (
          <div key={elem.id} className={menuPageStylesSection.section}>
            <p><strong>Name:</strong> {elem.name}</p>
            <p><strong>ID:</strong> {elem.id}</p>
            <p><strong>Category:</strong> {elem.category}</p>
            <p><strong>User ID:</strong> {elem.topping}</p>
            <p><strong>Completed:</strong> {elem.price}</p>
            <p><strong>Completed:</strong> {elem.rank}</p>
          </div>
        ))}
      </div>
    </div>
  )
}

export default MenuListPage
