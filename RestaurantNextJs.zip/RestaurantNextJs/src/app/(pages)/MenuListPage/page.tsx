import React from 'react';
import Link from 'next/link';
import { menuPageStyles } from '../../styles/Styles';

function MenuListPage() {
  const idRestaurant = [1, 2];

  return (
    <div className={menuPageStyles.container}>
      <div className={menuPageStyles.box}>
        <h1 className={menuPageStyles.title}>Menu</h1>
      </div>
      <div className="space-y-2 flex flex-col">
        {idRestaurant.map((id) => (
          <div key={id} className={menuPageStyles.section}>
            <Link href={`/MenuListPage/${id}`}>
              <span className={menuPageStyles.options}>Vai al menu del ristorante {id}</span>
            </Link>
          </div>
        ))}
      </div>
      <div>
        <p className='text-amber-900'>Chiamata GET all' API in base al ID Restaurant</p>
      </div>
    </div>
  );
}

export default MenuListPage;
