import { NextRequest, NextResponse } from "next/server";

export async function POST(request: NextRequest) {
    try {
        const body = await request.json(); // i dati dell'ordine dal client

        const response = await fetch("https://private-anon-52a8b882bd-pizzaapp.apiary-mock.com/orders/", {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
            },
            body: JSON.stringify(body),
        });

        if (!response.ok) {
            throw new Error(`Errore nella fetch esterna: ${response.status}`);
        }

        const data = await response.json();

        return NextResponse.json({ success: true, order: data });
    } catch (error) {
        console.error("Errore nella API route:", error);
        return NextResponse.json({ error: "Errore nell'API" }, { status: 500 });
    }
}
