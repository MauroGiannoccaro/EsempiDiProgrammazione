// /app/api/sendData/route.ts

let user: { name: string; email: string } = {
  name: 'defaultName',
  email: 'defaultEmail',
};

export async function POST(request: Request) {
  const body = await request.json();
  const { name, email } = body;

  user = { name, email }; // aggiorna la variabile globale
  console.log('Ricevuto dal client (POST):', user);

  return new Response(JSON.stringify({
    message: 'Dati ricevuti!',
    user,
  }), {
    status: 200,
    headers: {
      'Content-Type': 'application/json',
    }
  });
}

export async function GET() {
  console.log('Richiesta GET: restituisco user');

  return new Response(JSON.stringify({
    message: 'Dati recuperati!',
    user,
  }), {
    status: 200,
    headers: {
      'Content-Type': 'application/json',
    }
  });
}
