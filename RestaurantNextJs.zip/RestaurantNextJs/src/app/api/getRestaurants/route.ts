import { Rest, Restaurants } from "@/app/types/Type";
import { NextRequest, NextResponse } from "next/server";

export async function GET(request: NextRequest) {
    try {
        const response = await fetch("https://private-anon-52a8b882bd-pizzaapp.apiary-mock.com/restaurants/", {
            cache: "no-store",
        });

        if (!response.ok) {
            throw new Error(`Errore nella fetch esterna: ${response.status}`);
        }

        const data : Rest = await response.json();

        console.log(data);

        return NextResponse.json({ Restaurants: data });
    } catch (error) {
        console.error("Errore nella API route:", error);
        return NextResponse.json({ error: "Errore nell'API" }, { status: 500 });
    }
}
