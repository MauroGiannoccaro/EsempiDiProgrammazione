export type Rest = Restaurants[]

export interface Restaurants {
  id: number
  name: string
  address1: string
  address2: string
  latitude: number
  longitude: number
}

export type Menu = MenuList[]

export interface MenuList {
  id: number
  category: string
  name: string
  topping?: string[]
  price: number
  rank?: number
}

export interface Order {
  orderId: number
  totalPrice: number
  orderedAt: string
  esitmatedDelivery: string
  status: string
  cart: Cart[]
  restuarantId: number
}

export interface Cart {
  menuItemId: number
  quantity: number
}
