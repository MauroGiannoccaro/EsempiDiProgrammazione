import Home from "./(pages)/Home/page";

export default function app() {
  return (
  <div>
    {/* <OrderPage searchParams={Promise.resolve({ id: [""] })} /> */}
    <Home />
  </div>
  );
}
