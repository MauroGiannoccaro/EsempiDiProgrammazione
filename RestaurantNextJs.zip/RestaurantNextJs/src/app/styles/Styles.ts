export const menuPageStyles = {
    container: "flex flex-col items-center justify-items-start rounded-3xl border-orange-400 shadow-orange-900 shadow-2xl mt-10 h-[400px] bg-orange-400 w-[600px]",
    title: "text-3xl font-bold text-white  border-orange-400",
    box: "mb-4 p-4 bg-green-600 rounded-4xl w-30 shadow-lg mt-5 flex align-middle justify-center mt-10",
    section: "p-4  bg-amber-50 shadow-2xl rounded-4xl  border-orange-400 hover:bg-amber-500",
    options: "text-blue-500 hover:underline text-2xl",
  };

  export const menuPageStylesSection = {
    menuBox: menuPageStyles.box,
    menuTitle: menuPageStyles.title,
    container: "p-4 flex flex-col items-center justify-center bg-yellow-200 mt-10 rounded-lg shadow-md ",
    section: "p-4 rounded-3xl shadow-amber-700 shadow-2xl bg-amber-400 ml-5 mr-5 items-center justify-center flex flex-col gap-2 text-amber-900",
    menuContainer: "flex gap-4 flex-col justify-stretch items-stretch rounded-3xl h-[800px] w-[800px] overflow-auto",
  };

  export const OrderPageStyles ={
   container: 'flex flex-col items-center justify-start h-[800px] w-[800px] bg-amber-400 rounded-3xl shadow-2xl shadow-amber-700 gap-10',
   box: 'mt-10 p-4 bg-yellow-100 rounded-4xl w-30 h-15 flex justify-center items-center shadow-2xs shadow-amber-300',
   section: 'mt-10 p-4 bg-yellow-100 rounded-4xl w-30 h-15 flex justify-center items-center shadow-2xs shadow-amber-300',
  }

  
  export const RestaurantsPageStyles ={
    container: OrderPageStyles.container,
    box: OrderPageStyles.box,
    section: 'p-4 bg-amber-50 shadow-2xl rounded-4xl border-orange-400 hover:bg-amber-500',
   }

   export const HandlerPageStyles ={
    container: OrderPageStyles.container,
   }

   export const HandlerSecondPageStyles ={
    container: OrderPageStyles.container,
   }