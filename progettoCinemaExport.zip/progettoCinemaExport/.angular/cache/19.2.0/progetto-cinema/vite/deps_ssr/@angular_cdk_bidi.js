import { createRequire } from 'module';const require = createRequire(import.meta.url);
import {
  BidiModule,
  DIR_DOCUMENT,
  Dir,
  Directionality
} from "./chunk-TPJZ2MUF.js";
import "./chunk-VV6JI5M5.js";
import "./chunk-6R2DQ5NE.js";
import "./chunk-ZUJ64LXG.js";
import "./chunk-XCIYP5SE.js";
import "./chunk-OYTRG5F6.js";
import "./chunk-YHCV7DAQ.js";
export {
  BidiModule,
  DIR_DOCUMENT,
  Dir,
  Directionality
};
