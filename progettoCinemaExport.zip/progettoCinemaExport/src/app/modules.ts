import { CommonModule } from "@angular/common";
import { HttpClientModule, HTTP_INTERCEPTORS } from "@angular/common/http";
import { NgModule, importProvidersFrom, CUSTOM_ELEMENTS_SCHEMA } from "@angular/core";
import { RouterModule } from "@angular/router";
import { HomePageComponent } from "./pages/home-page/home-page.component";
import { PageNotFoundComponent } from "./pages/page-not-found/page-not-found.component";
import { ReactiveFormsModule } from '@angular/forms';
import { MatSelectModule } from '@angular/material/select';
import { MatInputModule } from '@angular/material/input';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatButtonModule } from '@angular/material/button';
import { AuthInterceptor } from "./services/auth-Interceptor/auth.interceptor";
import { InProgrammazioneComponent } from "./pages/in-programmazione/in-programmazione.component";
import { MatMenuModule } from '@angular/material/menu';
import { HeaderComponent } from "./pages/components/header/header.component";
import { FooterComponent } from "./pages/components/footer/footer.component";
import { PrezziComponent } from "./pages/prezzi/prezzi.component";
import { ContattiComponent } from "./pages/contatti/contatti.component";
import { TemplateComponent } from "./pages/components/template/template.component";
import { SidebarComponent } from "./pages/components/sidebar/sidebar.component";
import { CaruselComponent } from "./pages/components/carusel/carusel.component";

@NgModule({
  declarations: [
  HomePageComponent,
  PageNotFoundComponent,
  InProgrammazioneComponent,
  HeaderComponent,
  FooterComponent,
  PrezziComponent,
  ContattiComponent,
  SidebarComponent,
  CaruselComponent,
  ],
  imports: [
    CommonModule,
    RouterModule,
    ReactiveFormsModule,
    MatSelectModule,
    MatInputModule,
    MatFormFieldModule,
    MatButtonModule,
    MatMenuModule,
    TemplateComponent,
],
  exports:[
    HomePageComponent,
    PageNotFoundComponent,
    InProgrammazioneComponent,
    HeaderComponent,
    FooterComponent,
    PrezziComponent,
    ContattiComponent,
    SidebarComponent,
    CaruselComponent,
  ],
  providers: [
    importProvidersFrom (HttpClientModule),
    {
      provide: HTTP_INTERCEPTORS,
      useClass: AuthInterceptor,
      multi: true
    },
  ],
  schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class Modules { }
