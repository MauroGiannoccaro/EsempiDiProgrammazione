import { Component } from '@angular/core';

@Component({
  selector: 'app-prezzi',
  standalone: false,
  templateUrl: './prezzi.component.html',
  styleUrl: './prezzi.component.css'
})
export class PrezziComponent {
  prezziBiglietti = [
    { categoria: 'Intero', prezzo: 8.00 },
    { categoria: 'Ridotto (Under 18)', prezzo: 5.00 },
    { categoria: 'Studenti Universitari', prezzo: 6.50 },
    { categoria: 'Over 65', prezzo: 5.50 },
    { categoria: 'Promozione Lunedì', prezzo: 4.00 }
  ];
}
