import { Component, OnInit } from '@angular/core';
import { fetchServiceService } from '../../service/fetch-service.service';
import { FilmSearch } from '../../types/models';


@Component({
  selector: 'app-in-programmazione',
  standalone: false,
  templateUrl: './in-programmazione.component.html',
  styleUrls: ['./in-programmazione.component.css']
})
export class InProgrammazioneComponent implements OnInit {
  films: any;
  errorMessage: string = '';
  showFilms: boolean = true;
  selectedFilm?: FilmSearch;
  orari = {
    primaFascia: "dalle 16:00 alle 18:00",
    secondaFascia: "dalle 18:00 alle 20:00",
    terzaFascia: "dalle 20:00 alle 22:00",
    quartaFascia: "dalle 22:00 alle 24:00"
  }

  // Inietta il servizio tramite il costruttore
  constructor(private fetchService: fetchServiceService) { }

  ngOnInit(): void {
    // Usa this.fetchService per accedere al metodo getFilms()
    this.fetchService.getFilms().subscribe({
      next: (data) => {
        this.films = data;
        console.log('Risultati della fetch:', data);
      },
      error: (err) => {
        console.error('Errore nella fetch:', err);
        this.errorMessage = 'Si è verificato un errore.';
      }
    });

  }
  onFilmClick(film: FilmSearch): void {
    this.selectedFilm = film;
    this.showFilms = false;
  }
  backToFilms(): void {
    this.showFilms = true;
  }
}
