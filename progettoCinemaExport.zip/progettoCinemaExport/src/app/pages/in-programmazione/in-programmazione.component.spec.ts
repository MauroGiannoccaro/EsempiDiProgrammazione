import { ComponentFixture, TestBed } from '@angular/core/testing';

import { InProgrammazioneComponent } from './in-programmazione.component';

describe('InProgrammazioneComponent', () => {
  let component: InProgrammazioneComponent;
  let fixture: ComponentFixture<InProgrammazioneComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [InProgrammazioneComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(InProgrammazioneComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
