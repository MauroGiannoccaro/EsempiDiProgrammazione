import { TestBed } from '@angular/core/testing';

import { CinemaAuthServiceService } from './cinema-auth-service.service';

describe('CinemaAuthServiceService', () => {
  let service: CinemaAuthServiceService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(CinemaAuthServiceService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
