
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { FilmSearch } from '../types/models';

@Injectable({
  providedIn: 'root'
})

export class fetchServiceService{
  apiKey = '76ad0e02';
  private apiUrl = `http://www.omdbapi.com/?apikey=${this.apiKey}&s=star+wars`;

  constructor(private http: HttpClient) {}

  getFilms(): Observable<FilmSearch[]> {
    return this.http.get<FilmSearch[]>(this.apiUrl);
  }}

