import { Routes } from '@angular/router';
import { HomePageComponent } from './pages/home-page/home-page.component';
import { PageNotFoundComponent } from './pages/page-not-found/page-not-found.component';
import { InProgrammazioneComponent } from './pages/in-programmazione/in-programmazione.component';
import { ContattiComponent } from './pages/contatti/contatti.component';
import { PrezziComponent } from './pages/prezzi/prezzi.component';

export const routes: Routes = [
  { path: "", redirectTo: "/homePage", pathMatch: "full" },
  { path: "homePage", component: HomePageComponent },
  { path: "inProgrammazione", component: InProgrammazioneComponent },
  { path: "prezzi", component: PrezziComponent },
  { path: "contatti", component: ContattiComponent },
  { path: "**", redirectTo: "/404"},
  { path: "404", component: PageNotFoundComponent},
];
