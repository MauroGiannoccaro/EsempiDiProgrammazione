﻿using System.Collections.Generic;
using System;
using System.Linq;
using System.Text;
using static System.Net.Mime.MediaTypeNames;


namespace banca
{
    internal class Program
    {
        static void Main(string[] args)
        {
            List<ContoCorrente> Conti = new List<ContoCorrente>();



            menu(Conti);
        }
        static void menu(List<ContoCorrente> Conti)
        {

            string scelta = "";
            do
            {
                Console.WriteLine(@$"-----------------BANCA------------------------");
                Console.WriteLine(@$"----------------------ATM---------------------");
                Console.WriteLine("Scegli l'operazione da eseguire tra le seguenti:");
                Console.WriteLine("1. Aggiungi C/C ");
                Console.WriteLine("2. Rimuovi C/C");
                Console.WriteLine("3. Operazioni in C/C");
                Console.WriteLine("4. Uscita");
                Console.WriteLine("5. Visualizza Giacenza ATM");
                Console.WriteLine(@$"----------------------------------------------");
                Console.WriteLine(@$"----------------------------------------------");
                scelta = Console.ReadLine()?.ToUpper() ?? "";
                switch (scelta)
                {
                    case "1":
                        CreaConto(Conti);
                        break;
                    case "2":
                        RimuoviConto(Conti);
                        break;
                    case "3":
                        SottoMenu(Conti);
                        break;
                    case "5":
                        VisualizzaGiacenzaAtm(Conti);
                        break;

                }
            }
            while (scelta != "4");

        }
        static void SottoMenu(List<ContoCorrente> Conti)
        {

            string scelta = "";
            do
            {
                Console.WriteLine(@$"------------------ATM------------------------");
                Console.WriteLine(@$"----------------------------------------------");
                Console.WriteLine("Scegli l'operazione da eseguire tra le seguenti:");
                Console.WriteLine("1. Preleva Denaro ");
                Console.WriteLine("2. Versa Denaro");
                Console.WriteLine("3. Visualizza Saldo");
                Console.WriteLine("4. Uscita");
                Console.WriteLine("5. Visualizza operazioni per Data");
                Console.WriteLine(@$"----------------------------------------------");
                Console.WriteLine(@$"----------------------------------------------");

                scelta = Console.ReadLine()?.ToUpper() ?? "";


                switch (scelta)
                {
                    case "1":
                    case "2":
                        Operazioni(Conti, scelta);
                        break;

                    case "3":
                        VisualizzaConto(Conti);
                        break;
                    case "5":
                        VisualizzaStoricoPerData(Conti);
                        break;

                }
            }
            while (scelta != "4");
        }
        static void CreaConto(List<ContoCorrente> Conti)
        {
            ContoCorrente contoCorrente;

            string nome, cognome, codiceFiscale;
            do
            {

                Console.WriteLine(@$"----------------------------------------------");
                Console.WriteLine("Inserisci Nome ");
                Console.WriteLine(@$"----------------------------------------------");

                nome = Console.ReadLine()?.ToUpper() ?? "";
            } while (!ControlloStringa(nome));
            do
            {

                Console.WriteLine(@$"----------------------------------------------");
                Console.WriteLine("Inserisci Cognome ");
                Console.WriteLine(@$"----------------------------------------------");

                cognome = Console.ReadLine()?.ToUpper() ?? "";
            } while (!ControlloStringa(cognome));

            do
            {

                Console.WriteLine(@$"----------------------------------------------");
                Console.WriteLine("Inserisci Codice Fiscale ");
                Console.WriteLine(@$"----------------------------------------------");

                codiceFiscale = Console.ReadLine()?.ToUpper() ?? "";
                if (codiceFiscale.Length != 11)
                {
                    Console.WriteLine("Inserisci un codice fiscale Valido. il CF dev' essere di 11 carateri");

                }
            } while (codiceFiscale != "" && codiceFiscale.Length != 11);
            contoCorrente = new ContoCorrente(nome, cognome, codiceFiscale, CreaRandom(), CreaRandom());
            Console.WriteLine("Conto Creato Con Successo ");

            Console.WriteLine(@$"----------------------------------------------");
            Console.WriteLine(@$"Il tuo Conto è: {contoCorrente.NumeroCc} e la tua password è:{contoCorrente.Password}");
            Console.WriteLine(@$"----------------------------------------------");

            Conti.Add(contoCorrente);


        }
        static void VisualizzaConto(List<ContoCorrente> Conti)
        {
            string numeroConto, password;
            do
            {

                Console.WriteLine(@$"----------------------------------------------");
                Console.WriteLine("Inserisci Numero Conto ");
                Console.WriteLine(@$"----------------------------------------------");

                numeroConto = Console.ReadLine()?.ToUpper() ?? "";
            } while (!ControlloNumero(numeroConto));
            int.TryParse(numeroConto, out int numeroContoParsato);
            do
            {

                Console.WriteLine(@$"----------------------------------------------");
                Console.WriteLine("Inserisci Password: ");
                Console.WriteLine(@$"----------------------------------------------");

                password = Console.ReadLine()?.ToUpper() ?? "";
            } while (!ControlloNumero(password));
            int.TryParse(password, out int passwordParsata);
            if (Conti != null)
            {
                ContoCorrente? contoSelezionato = Conti.FirstOrDefault(x => x.NumeroCc == numeroContoParsato);

                if (contoSelezionato != null && contoSelezionato.Password == passwordParsata)
                {
                    int i = 1;
                    foreach (var item in contoSelezionato.Movimenti)
                    {
                        Console.WriteLine(@$"----------------------------------------------");
                        Console.WriteLine($"{i}. Operazione: {item.TipoOperazione} importo:{item.Importo}  Data: {item.Data}");
                        Console.WriteLine(@$"----------------------------------------------");
                        i++;
                    }
                    double saldo = contoSelezionato.Saldo;
                    Console.WriteLine(@$"Il tuo Saldo è: {saldo}");
                }
                else
                {
                    Console.WriteLine("Conto o Password errati ");
                }
            }
        }
        public static int CreaRandom()
        {
            Random random = new Random();
            int[] Grandom = new int[5];
            for (int i = 0; i < 5; i++)
            {
                Grandom[i] = random.Next(1, 9);
            }
            string Nrandom = string.Join("", Grandom);
            return int.Parse(Nrandom);

        }
        public static string CreaPassword()
        {

            StringBuilder password = new StringBuilder();
            Random random = new Random();
            string caratteri = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
            string specialChar = "/-%&()&#*";

            for (int i = 0; i < 10; i++)
            {
                password.Append(caratteri[random.Next(caratteri.Length)]);
            }
            password.Insert(random.Next(password.Length), specialChar[random.Next(specialChar.Length)]);
            return password.ToString();
        }

        static void Operazioni(List<ContoCorrente> Conti, string scelta)
        {

            Movimento movimento;
            string numeroConto, password;
            int sconfino = 1000;
            do
            {

                Console.WriteLine(@$"----------------------------------------------");
                Console.WriteLine("Inserisci Numero Conto ");
                Console.WriteLine(@$"----------------------------------------------");

                numeroConto = Console.ReadLine()?.ToUpper() ?? "";
            } while (!ControlloNumero(numeroConto));
            int.TryParse(numeroConto, out int numeroContoParsato);
            do
            {

                Console.WriteLine(@$"----------------------------------------------");
                Console.WriteLine("Inserisci Password: ");
                Console.WriteLine(@$"----------------------------------------------");

                password = Console.ReadLine()?.ToUpper() ?? "";
            } while (!ControlloNumero(password));

            if (Conti.Count != 0)
            {
                ContoCorrente? contoSelezionato = Conti.FirstOrDefault(x => x.NumeroCc == numeroContoParsato);
                if (contoSelezionato != null)
                {

                    Console.WriteLine(@$"----------------------------------------------");
                    Console.WriteLine("Inserisci Importo ");
                    Console.WriteLine(@$"----------------------------------------------");

                    string importo = Console.ReadLine()?.ToUpper() ?? "";
                    double.TryParse(importo, out double importoParsato);

                    Console.WriteLine(@$"----------------------------------------------");
                    Console.WriteLine("Inserisci Tipo Operazione ");
                    Console.WriteLine(@$"----------------------------------------------");

                    string TipoOperazione = (scelta == "1") ? TipoOperazione = "Prelievo" : TipoOperazione = "Versamento";
                    if ((TipoOperazione == "Prelievo" && (contoSelezionato.Saldo + sconfino) >= importoParsato) || (TipoOperazione == "Versamento"))
                    {
                        movimento = new Movimento(importoParsato, TipoOperazione);
                        contoSelezionato.Movimenti.Add(movimento);

                        Console.WriteLine(@$"----------------------------------------------");
                        Console.WriteLine($"Operazione: {movimento.TipoOperazione} Importo: {movimento.Importo} Data: {movimento.Data}");
                        Console.WriteLine(@$"----------------------------------------------");
                        Console.WriteLine(@$"Il tuo Saldo è:{contoSelezionato.Saldo}");
                    }

                    else
                    {
                        Console.WriteLine("L' importo Supera I limiti consentiti Rivolgersi all' Istituto");
                    }
                }
            }
            else
            {
                Console.WriteLine("Conto non trovato ");
            }


        }
        static bool ControlloStringa(string nome)
        {

            bool controllo = true;

            foreach (char a in nome)
            {

                if (!char.IsLetter(a))
                {
                    Console.WriteLine("Nome non Corretto deve contenere caratteri alfanumerici");
                    controllo = false;
                    break;
                }

            }
            return controllo;

        }
        static bool ControlloNumero(string numero)
        {

            bool controllo = true;

            try
            {
                double.Parse(numero);
            }

            catch (Exception)
            {
                Console.WriteLine("Inserire numero valido non inserire stringhe o spazi vuoti");
                controllo = false;
            }

            return controllo;
        }
        static void RimuoviConto(List<ContoCorrente> Conti)
        {

            Movimento movimento;
            string numeroConto, password;
            do
            {
                Console.WriteLine("Inserisci Numero Conto ");
                numeroConto = Console.ReadLine()?.ToUpper() ?? "";
            } while (ControlloNumero(numeroConto));
            int.TryParse(numeroConto, out int numeroContoParsato);
            do
            {
                Console.WriteLine("Inserisci Password: ");
                password = Console.ReadLine()?.ToUpper() ?? "";
            } while (ControlloNumero(password));
            int.TryParse(password, out int passwordParsata);

            if (Conti.Count != 0)
            {
                ContoCorrente? contoSelezionato = Conti.FirstOrDefault(x => x.NumeroCc == numeroContoParsato && x.Password == passwordParsata);
                if (contoSelezionato != null)
                {
                    Conti.Remove(contoSelezionato);
                }
            }
        }
        static void VisualizzaGiacenzaAtm(List<ContoCorrente> Conti)
        {
            double giacenza;
            foreach (var item in Conti)
            {

                giacenza = +item.Saldo;

            }
        }
        static void VisualizzaStoricoPerData(List<ContoCorrente> Conti)
        {
            Movimento movimento;
            string numeroConto, password;
            do
            {

                Console.WriteLine(@$"----------------------------------------------");
                Console.WriteLine("Inserisci Numero Conto ");
                Console.WriteLine(@$"----------------------------------------------");

                numeroConto = Console.ReadLine()?.ToUpper() ?? "";
            } while (!ControlloNumero(numeroConto));
            int.TryParse(numeroConto, out int numeroContoParsato);
            do
            {

                Console.WriteLine(@$"----------------------------------------------");
                Console.WriteLine("Inserisci Password: ");
                Console.WriteLine(@$"----------------------------------------------");

                password = Console.ReadLine()?.ToUpper() ?? "";
            } while (!ControlloNumero(password));
            int.TryParse(password, out int passwordParsata);

            string data;
            do
            {
                Console.WriteLine("Inserisci Data: dd-MM-yyyy");
                data = Console.ReadLine()?.ToUpper() ?? "";
            } while (ControlloData(data));
            Console.WriteLine(data.ToString());



            if (Conti.Count != 0)
            {
                ContoCorrente? contoSelezionato = Conti.FirstOrDefault(x => x.NumeroCc == numeroContoParsato && x.Password == passwordParsata);
                foreach (var item in contoSelezionato.Movimenti)
                {
                    if (item.Data.Date.ToString() == data)
                    {
                        Console.WriteLine($"Operazione: {item.TipoOperazione} Importo: {item.Importo} Data: {item.Data}");
                    }
                   
                }
            }
            static bool ControlloData(string data)
            {

                string format = "dd-MM-yyyy";

                DateTime date;
                if (DateTime.TryParseExact(data, format, System.Globalization.CultureInfo.InvariantCulture, System.Globalization.DateTimeStyles.None, out date))
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
        }
    }
}
