﻿using System;
using System.Collections.Generic;


namespace banca
{
    internal class ContoCorrente
    {

        internal ContoCorrente(string nome, string cognome, string codiceFiscale, int numeroCc, int password)
        {
            this.Nome = nome;
            this.Cognome = cognome;
            this.CodiceFiscale = codiceFiscale;
            this.NumeroCc = numeroCc;
            this.Password = password;
            
        }
        internal string Nome { get; set; }
        internal string Cognome { get; set; }
        internal string CodiceFiscale { get; }
        internal int NumeroCc { get; }
        internal int Password { get; }
        
      

        internal List<Movimento> Movimenti = new List<Movimento>();
        

        internal double Saldo 
        {
            
                get{
                    double saldo = 0;
                    foreach (var movimento in Movimenti) {
                        if (movimento.TipoOperazione == "Versamento")
                        {
                            saldo += movimento.Importo;
                        }
                        else
                        {
                            saldo -= movimento.Importo;
                        }
                    }
                    return saldo;
                }
        }
    }
    
}
