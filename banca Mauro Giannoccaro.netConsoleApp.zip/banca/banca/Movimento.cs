﻿using System;


namespace banca
{
    internal class Movimento
    { 
        internal Movimento(double importo, string tipoOperazione)
        {
            this.Importo = importo;
            this.TipoOperazione = tipoOperazione; 
            Data = DateTime.Now;
        }
        internal double Importo { get; }   
        internal string TipoOperazione { get;}
        internal DateTime Data { get; }

       

    }
}
