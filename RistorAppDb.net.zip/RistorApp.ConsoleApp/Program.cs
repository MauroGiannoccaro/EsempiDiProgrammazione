﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using RistorApp.ConsoleApp.Controllers;
using RistorApp.DataLayer.Services;
using RistorApp.DataLayer.Stores;
using System;

namespace RistorApp.ConsoleApp
{
    internal class Program
    {
        static void Main(string[] args)
        {
            var sc = new ServiceCollection();            
            sc.AddScoped<MenuController>();
            sc.AddScoped<ClienteService>();
            sc.AddSingleton<ClienteStore>();
            sc.AddScoped<TavoloService>();
            sc.AddSingleton<TavoloStore>();
            sc.AddScoped<PrenotazioneService>();
            sc.AddSingleton<PrenotazioneStore>();
            sc.AddScoped<TavoloController>();
            sc.AddScoped<ClienteController>();
            sc.AddScoped<PrenotazioneController>();
            sc.AddScoped<RistoratoreController>();

           

            var sp = sc.BuildServiceProvider();

            var menuController = sp.GetService<MenuController>();
            menuController?.MenuIniziale();
        }
    }
}
