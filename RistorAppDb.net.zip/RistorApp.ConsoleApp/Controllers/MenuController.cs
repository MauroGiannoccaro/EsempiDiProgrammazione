﻿using RistorApp.DataLayer.Services;
using System; 

namespace RistorApp.ConsoleApp.Controllers
{
    public class MenuController
    {
        private ClienteController _clienteController;
        private PrenotazioneController _prenotazioneController;
        private RistoratoreController _ristoratoreController;
        private TavoloController _tavoloController;
        public MenuController(ClienteController clienteController, PrenotazioneController prenotazioneController, RistoratoreController ristoratore, TavoloController tavolo) 
        {
            _ristoratoreController = ristoratore;
            _clienteController = clienteController;
            _prenotazioneController = prenotazioneController;
            _tavoloController = tavolo;
        }

        public void MenuIniziale()
        {
            
                _clienteController.CreaClientePerTesting();
                _tavoloController.CreaTavoloPerTesting();
                _prenotazioneController.CreaPrenotazionePerTesting();
            
            string scelta = "";

            //bool adminValidation = false;

            do
            {
                Console.WriteLine($"--------------Gestionale Ristorante-------------------");
                Console.WriteLine($"---------------------------------------------------");
                Console.WriteLine("Esegui l' accesso:");
                Console.WriteLine("1. Cliente");
                Console.WriteLine("2. Ristoratore");
                Console.WriteLine("3. Esci");
                Console.WriteLine($"---------------------------------------------------");
                Console.WriteLine($"---------------------------------------------------");
                scelta = Console.ReadLine()?.ToUpper() ?? "";
                switch (scelta)
                {

                    case "1":
                        _clienteController.SottoMenu();

                        break;
                    case "2":
                        _ristoratoreController.SottoMenu();

                        break;
                    case "3":
                        break;
                        //esci

                }
            }
            while (scelta != "3");

        }
    }
}
