﻿using RistorApp.DataLayer.Models;
using RistorApp.DataLayer.Services;
using RistorApp.DataLayer.Stores;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RistorApp.ConsoleApp.Controllers
{
    public class TavoloController
    {
        private TavoloService _tavoloService;

        public TavoloController(TavoloService tavoloService)
        {
            _tavoloService = tavoloService;
        }

        public void SottoMenu()
        {
            string scelta = "";
            do
            {
                Console.WriteLine($"--------------Gestionale Ristorante-------------------");
                Console.WriteLine($"---------------------------------------------------");
                Console.WriteLine(" ----Sotto Menu Tavoli:");
                Console.WriteLine("1. Inserisci Tavolo ");
                Console.WriteLine("2. Rimuovi Tavolo ");
                Console.WriteLine("3. Visualizza Tavolo");
                Console.WriteLine("4. Modifica Tavolo");
                Console.WriteLine("5. Esci");
                Console.WriteLine($"---------------------------------------------------");
                Console.WriteLine($"---------------------------------------------------");
                scelta = Console.ReadLine()?.ToUpper() ?? "";
                switch (scelta)
                {
                    case "1":
                        Crea();
                        Console.WriteLine("Tavolo Aggiunto");
                        break;
                    case "2":
                        Rimuovi();
                        break;
                    case "3":
                        Visualizza();
                        break;
                    case "4":
                        Modifica();
                        break;
                    case "5":
                        break;
                        //esci
                }
            }
            while (scelta != "5");
        }
        public Tavolo? Crea()
        {
            string posizione, posti;
            int nPosti;

            do
            {

                Console.WriteLine(@$"----------------------------------------------");
                Console.WriteLine("Inserisci Il numero dei letti della Tavolo");
                Console.WriteLine(@$"----------------------------------------------");

                posti = Console.ReadLine()?.ToUpper() ?? "";
            } while (!int.TryParse(posti, out nPosti));
            do
            {

                Console.WriteLine(@$"----------------------------------------------");
                Console.WriteLine("Inserisci la descrizione della Tavolo");
                Console.WriteLine(@$"----------------------------------------------");

                posizione = Console.ReadLine()?.ToUpper() ?? "";
            } while (!ValidationUtility.ControlloStringa(posizione));


            var tavolo=_tavoloService.Create(nPosti, posizione);
            return tavolo;

        }
        public bool Rimuovi()
        {
            Tavolo tavoloSelezionato = Cerca();
            if (tavoloSelezionato != null)
            {
                _tavoloService.Delete(tavoloSelezionato);
                Console.WriteLine("Tavolo Rimossa");
                return true;
            }
            Console.WriteLine("Tavolo non trovata");
            return false;
        }
        public void Visualizza()
        {
            var tavoli = _tavoloService.GetList();
            int i = 1;
            if (tavoli != null)
            {
                foreach (var item in tavoli)
                {
                    Console.WriteLine(@$"{i})id: {item.Id}) Numero Tavolo {item.Posizione}
                                              Numero Persone  {item.NumeroPersone}
                                             ");
                    i++;
                }
            }
            else
            {
                Console.WriteLine(@$"Lista Vuota");
            }
        }
        public bool Modifica()
        {
            Tavolo tavolo = Crea();
            Tavolo tavoloSelezionato = Cerca();
            if (tavoloSelezionato != null && tavolo != null)
            {
                _tavoloService.Modifica(tavolo, tavoloSelezionato);
                return true;
            }
            Console.WriteLine("Tavolo non trovata");
            return false;
        }
        public Tavolo? Cerca()
        {
            string id;
            int idParsato;
            do
            {

                Console.WriteLine(@$"----------------------------------------------");
                Console.WriteLine("Inserisci l'id del tavolo da Riuovere");
                Console.WriteLine(@$"----------------------------------------------");

                id = Console.ReadLine()?.ToUpper() ?? "";
            } while (!int.TryParse(id, out idParsato));
            Tavolo tavolo = _tavoloService.Get(idParsato);
            return tavolo;
        }
        public void CreaTavoloPerTesting()
        {
            
            _tavoloService.Create(5, "38");
            Console.WriteLine(@$"----------------------------------------------");
            Console.WriteLine("Tavolo Random creato ");
            Console.WriteLine(@$"----------------------------------------------");
            
        }
    }
}
