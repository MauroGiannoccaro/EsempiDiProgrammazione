﻿using System;
using RistorApp.DataLayer.Models;
using RistorApp.DataLayer.Services;
using System.Text;
using System.Threading.Tasks;

using RistorApp.DataLayer.Stores;

namespace RistorApp.ConsoleApp.Controllers
{
    public class PrenotazioneController : IController<Prenotazione>
    {
        PrenotazioneService _prenotazioneService;
        public PrenotazioneController(PrenotazioneService prenotazioneService) 
        {
            _prenotazioneService = prenotazioneService; 
        }
        public void SottoMenu()
        {
            string scelta = "";
            do
            {
                Console.WriteLine($"--------------Gestionale Ristorante-------------------");
                Console.WriteLine($"---------------------------------------------------");
                Console.WriteLine(" ----Sotto Menu Prenotazioni:");
                Console.WriteLine("1. Visualizza Prenotazioni ");
                Console.WriteLine("2. Inserisci Prenotazioni");
                Console.WriteLine("3. Modifica Prenotazione");
                Console.WriteLine("4. Esci");
                Console.WriteLine($"---------------------------------------------------");
                Console.WriteLine($"---------------------------------------------------");
                scelta = Console.ReadLine()?.ToUpper() ?? "";
                switch (scelta)
                {
                    case "1":
                        Visualizza();

                        break;
                    case "2":
                        Crea();
                        break;
                    case "3":
                        Modifica();

                        break;
                    case "4":
                        break;
                        //esci

                }
            }
            while (scelta != "4");
        }
        public Prenotazione? Crea()
        {

            string dataoraArrivo, oraLibero, idTavoloFK, idClienteFK, persone;
            int tavoloParsato, idClienteFKParsato,  personeParsate;
            DateTime? arrivo, libero;

            do
            {

                Console.WriteLine(@$"----------------------------------------------");
                Console.WriteLine("Inserisci L' Id Cliente ");
                Console.WriteLine(@$"----------------------------------------------");

                idClienteFK = Console.ReadLine()?.ToUpper() ?? "";
            } while (!int.TryParse(idClienteFK, out idClienteFKParsato));
            do
            {

                Console.WriteLine(@$"----------------------------------------------");
                Console.WriteLine("Inserisci L' Id del Tavolo che Vuoi prenotare ");
                Console.WriteLine(@$"----------------------------------------------");

                idTavoloFK = Console.ReadLine()?.ToUpper() ?? "";
            } while (!int.TryParse(idTavoloFK, out tavoloParsato));
            do
            {

                Console.WriteLine(@$"----------------------------------------------");
                Console.WriteLine("Inserisci il numero del numero di persone ");
                Console.WriteLine(@$"----------------------------------------------");

                persone = Console.ReadLine()?.ToUpper() ?? "";
            } while (!int.TryParse(persone, out personeParsate));

            do
            {

                Console.WriteLine(@$"----------------------------------------------");
                Console.WriteLine("Inserisci Data e ora di Arrivo ");
                Console.WriteLine(@$"----------------------------------------------");

                dataoraArrivo = Console.ReadLine()?.ToUpper() ?? "";
                arrivo = ValidationUtility.ReturnDateTime(dataoraArrivo);
            } while (arrivo == null);
            
                libero = arrivo.Value.AddHours(2);

            var prenotazione=_prenotazioneService.Create(idClienteFKParsato, tavoloParsato, arrivo, libero, personeParsate);
            return prenotazione;
        }
        public bool Modifica()
        {
            Prenotazione prenotazone = Crea();
            Prenotazione prenotazoneSelezionata = Cerca();
            if (prenotazoneSelezionata != null && prenotazone != null)
            {
                _prenotazioneService.Modifica(prenotazone, prenotazoneSelezionata);
                return true;
            }
            Console.WriteLine("Camera non trovata");
            return false;
        }
        public Prenotazione? Cerca()
        {
            string id;
            int idParsato;
            do
            {

                Console.WriteLine(@$"----------------------------------------------");
                Console.WriteLine("Inserisci l'id della Penotazione da Cercare");
                Console.WriteLine(@$"----------------------------------------------");

                id = Console.ReadLine()?.ToUpper() ?? "";
            } while (!int.TryParse(id, out idParsato));
            Prenotazione prenotazione = _prenotazioneService.Get(idParsato);
            return prenotazione;
        }
        public void Visualizza()
        {
            var prenotazione = _prenotazioneService.GetList();
            int i = 1;
            if (prenotazione != null)
            {
                foreach (var item in prenotazione)
                {
                    Console.WriteLine(@$"{i}) Numero Prenotazione {item.Id}
                                          Cliente  {item.IdCliente}
                                          Tavolo   {item.IdTavolo}
                                          Data   {item.OraArrivo}
                                          Data   {item.OraLibero}
                                          Descrizione   {item.Note}");
                    i++;
                }
            }
            else
            {
                Console.WriteLine(@$"Lista Vuota");
            }
        }
        public Prenotazione CreaPrenotazionePerTesting()
        {
            Prenotazione prenotazione = _prenotazioneService.Create(1, 1, ValidationUtility.ReturnDateTime("11-11-2001"), ValidationUtility.ReturnDateTime("11-11-2001"), 4);
            Console.WriteLine(@$"----------------------------------------------");
            Console.WriteLine("Prenotazione Random creata ");
            Console.WriteLine(@$"----------------------------------------------");
            return prenotazione;
        }
    }



}
