﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RistorApp.ConsoleApp.Controllers
{
    internal interface IController <T>
    {
         
        public T? Crea();
        public T? Cerca();
        public void Visualizza();
        public bool Modifica();
        public void SottoMenu();
    
    }
}
