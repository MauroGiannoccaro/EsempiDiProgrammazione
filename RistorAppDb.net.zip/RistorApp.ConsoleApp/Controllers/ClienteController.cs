﻿using RistorApp.DataLayer.Models;
using RistorApp.DataLayer.Services;
using RistorApp.DataLayer.Stores;
using System; 

namespace RistorApp.ConsoleApp.Controllers
{
    public class ClienteController : IController<Cliente>
    {
        private ClienteService _clienteService;

        public ClienteController(ClienteService clienteService) 
        {
            _clienteService = clienteService;
        }

        public void SottoMenu()
        {
            string scelta = "";
            do
            {
                Console.WriteLine($"--------------Gestionale Ristorante-------------------");
                Console.WriteLine($"---------------------------------------------------");
                Console.WriteLine("Menu Cliente:");
                Console.WriteLine("1. Inserisci i tuoi dati, REGISTRATI ");
                Console.WriteLine("2. Modifica i tuoi dati");
                Console.WriteLine("3. Visualizza i tuoi dati");
                Console.WriteLine("4. Cancellati /cancella cliente");
                Console.WriteLine("5. Esci");
                Console.WriteLine($"---------------------------------------------------");
                Console.WriteLine($"---------------------------------------------------");
                scelta = Console.ReadLine()?.ToUpper() ?? "";
                switch (scelta)
                {
                    case "1":
                        Crea();
                        break;
                    case "2":
                        Modifica();
                        break;
                    case "3":
                        VisualizzaCliente();
                        break;
                    case "4":
                        break;
                    //esci
                    case "5":
                        break;
                        //esci

                }
            }
            while (scelta != "5");
        }
        public Cliente Crea()
        {

            string nome, cognome, dataDiNascita;
            DateOnly? nascita;


            do
            {

                Console.WriteLine(@$"----------------------------------------------");
                Console.WriteLine("Inserisci Nome ");
                Console.WriteLine(@$"----------------------------------------------");

                nome = Console.ReadLine()?.ToUpper() ?? "";
            } while (!ValidationUtility.ControlloStringa(nome));
            do
            {

                Console.WriteLine(@$"----------------------------------------------");
                Console.WriteLine("Inserisci Cognome ");
                Console.WriteLine(@$"----------------------------------------------");

                cognome = Console.ReadLine()?.ToUpper() ?? "";
            } while (!ValidationUtility.ControlloStringa(cognome));
           
          
            do
            {

                Console.WriteLine(@$"----------------------------------------------");
                Console.WriteLine("Inserisci Data di Nascita ");
                Console.WriteLine(@$"----------------------------------------------");

                dataDiNascita = Console.ReadLine()?.ToUpper() ?? "";
                nascita = ValidationUtility.ReturnDate(dataDiNascita);
            } while (nascita == null);

            var cliente = _clienteService.Create(nome, cognome, nascita);

            if (cliente !=null)
            {
                Console.WriteLine("Cliente Aggiunto");
                
            }
            else
            {
               throw new Exception ("Cliente Non Aggiunto ERRORE Riprova");
              
            }
            return cliente;
        }
        public void CreaClientePerTesting()
        {
            _clienteService.Create("random", "random", new DateOnly(2001, 11, 1));
            Console.WriteLine(@$"----------------------------------------------");
            Console.WriteLine("Cliente Random creato ");
            Console.WriteLine(@$"----------------------------------------------");
           
        }
        public bool Modifica()
        {
            Cliente cliente = Crea();
            Cliente clienteSelezionato = Cerca();
            if (clienteSelezionato != null && cliente != null)
            {
                _clienteService.Modifica(cliente, clienteSelezionato);
                return true;
            }
            Console.WriteLine("Camera non trovata");
            return false;
        }
        public Cliente? Cerca()
        {
            string id;
            int idParsato;
            do
            {

                Console.WriteLine(@$"----------------------------------------------");
                Console.WriteLine("Inserisci l'Id del Cliente da Cercare");
                Console.WriteLine(@$"----------------------------------------------");

                id = Console.ReadLine()?.ToUpper() ?? "";
            } while (!int.TryParse(id, out idParsato));
            Cliente cliente = _clienteService.Get(idParsato);
            return cliente;
        }
        public void Visualizza()
        {
            var clienti = _clienteService.GetList();
            int i = 1;
            if (clienti != null)
            {
                foreach (var item in clienti)
                {
                    Console.WriteLine(@$"{i}) Id Cliente {item.Id}
                                              Nome {item.Nome}
                                              Cognome  {item.Cognome}                                                                              
                                              Data di Nascita {item.DataNascita}");
                    i++;
                }
            }
            else
            {
                Console.WriteLine(@$"Lista Vuota");
            }
        }
        public void VisualizzaCliente()
        {
            string id;
            int idParsato;
            do
            {

                Console.WriteLine(@$"----------------------------------------------");
                Console.WriteLine("Inserisci l'Id del Cliente da Cercare");
                Console.WriteLine(@$"----------------------------------------------");

                id = Console.ReadLine()?.ToUpper() ?? "";
            } while (!int.TryParse(id, out idParsato));
            var item = _clienteService.Get(idParsato);
            if (item != null) 
            { 

                    Console.WriteLine(@$"     Id Cliente {item.Id}
                                              Nome {item.Nome}
                                              Cognome  {item.Cognome}                                                                              
                                              Data di Nascita {item.DataNascita}");
             
            }
            else
            {
                Console.WriteLine(@$"Cliente non trovato");
            }
        }
    }
}
