﻿using RistorApp.DataLayer.Services;
using System;
using RistorApp.DataLayer.Models;

namespace RistorApp.ConsoleApp.Controllers
{

    public class RistoratoreController : IController<Ristoratore>
    {
        public Ristoratore Ristoratore { get; set; }
        public ClienteController _clienteController { get; set; }
        public TavoloController _tavoloController { get; set; }
        public PrenotazioneController _prenotazioneController{ get; set; }

        public RistoratoreController(ClienteController clienteController, TavoloController tavoloController, PrenotazioneController prenotazione)
        {
            _clienteController=clienteController;
            Ristoratore = Crea();
            _tavoloController = tavoloController;
            _prenotazioneController = prenotazione;

        }
        public Ristoratore Crea()
        {

            string nome, cognome, email;

            nome = "admin";
            cognome = "admin";
            int id = 1;
            email = "admin";

            Ristoratore admin = new Ristoratore(id, email, nome, cognome);

            return admin;

        }
        public void SottoMenu()
        {
            string scelta = "";
            do
            {
                Console.WriteLine($"--------------Gestionale Ristorante-------------------");
                Console.WriteLine($"---------------------------------------------------");
                Console.WriteLine(" ----Sotto Menu Ristoratore:");
                Console.WriteLine("1. Gestione Prenotazioni ");
                Console.WriteLine("2. Gestione Tavolo ");
                Console.WriteLine("3. Gestione Cliente");
                Console.WriteLine("4. Visualizza Prenotazioni");
                Console.WriteLine("5. Esci");
                Console.WriteLine($"---------------------------------------------------");
                Console.WriteLine($"---------------------------------------------------");
                scelta = Console.ReadLine()?.ToUpper() ?? "";
                switch (scelta)
                {
                    case "1":
                        _prenotazioneController.SottoMenu();

                        break;
                    case "2":
                        _tavoloController.SottoMenu();

                        break;
                    case "3":
                        _clienteController.SottoMenu();
                        break;
                    case "4":
                        _prenotazioneController.Visualizza();
                        break;
                    //esci
                    case "5":
                        break;
                        //esci
                }
            }
            while (scelta != "5");
        }
        public bool Modifica() //non implementato
        {
            return true;
        }
        public bool Rimuovi() //non implementato
        {
            return true;
        }
        public Ristoratore? Cerca() //non implementato
        {
            return null;
        }
        public void Visualizza() //non implementato
        {

        }

    }
}
