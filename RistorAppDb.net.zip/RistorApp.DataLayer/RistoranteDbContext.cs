﻿using Microsoft.EntityFrameworkCore;
using RistorApp.DataLayer.Models;
using System;

namespace RistorApp.DataLayer
{
    public class RistoranteDbContext : DbContext
    {
        public RistoranteDbContext(DbContextOptions options) : base(options)
        {

        }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {

        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {

        }

        public DbSet<Cliente> Clienti => Set<Cliente>();
        public DbSet<Tavolo> Tavoli => Set<Tavolo>();
        public DbSet<Prenotazione> Prenotazioni => Set<Prenotazione>();
    }
}
