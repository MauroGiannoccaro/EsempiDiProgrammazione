﻿using RistorApp.DataLayer.Models;
using RistorApp.DataLayer.Stores;
using System;
using System.Collections.Generic;
using System.Linq;

namespace RistorApp.DataLayer.Services
{
    public class PrenotazioneService : IService <Prenotazione>
    {
        
        private PrenotazioneStore _store;
        private TavoloService _tavoloService;
        private ClienteService _clienteService;

        public PrenotazioneService(PrenotazioneStore prenotazioneStore, TavoloService tavoloService, ClienteService clienteService)
        {
            _store = prenotazioneStore;
            _tavoloService = tavoloService;
            _clienteService = clienteService;
        }

        public List<Prenotazione>? GetList()
        {
            return _store.GetList();
        }

        public Prenotazione Get(int id)
        {
            var PrenotazioneTrovato = _store.Get(id);
            if (PrenotazioneTrovato == null)
            {
                throw new Exception($"Prenotazione con id {id} non trovato");
            }
            return PrenotazioneTrovato;
        }

        public Prenotazione Create(int IdClienteFK, int IdTavoloFK, DateTime? dataOraArrivo, DateTime? oraLibero, int persone)
        {
            if (_clienteService.Get(IdClienteFK) != null && _tavoloService.Get(IdTavoloFK) != null)
            {
                var disponibilita = VerificaDisponibilita(dataOraArrivo, persone);
                if (disponibilita.Count() > 0)
                {
                    var PrenotazioneDaAggiungere = new Prenotazione(IdClienteFK, IdTavoloFK, dataOraArrivo, oraLibero, persone);
                    _store.Add(PrenotazioneDaAggiungere);
                    return PrenotazioneDaAggiungere;
                }
                else
                {
                    throw new Exception("Nessun Posto Disponibile");
                }
            }
            else 
            { 
                throw new Exception("Cliente o tavolo non esistenti");
            }
         
        }

        public bool Delete(Prenotazione Prenotazione)
        {
            return _store.Remove(Prenotazione);
        }
        public bool Modifica(Prenotazione Prenotazione, Prenotazione PrenotazioneSelezionato)
        {
            if (_store.Modify(Prenotazione, PrenotazioneSelezionato))
            {
                return true;
            }
            else
            {
                return false;
            }
        }
       
        public List<Tavolo>? VerificaDisponibilita(DateTime? data, int numeroPersone)
        {
            {
                if (data == null)
                {
                    throw new ArgumentNullException(nameof(data));
                }

                var disponibilitaData = _store.GetList().FindAll(item => item.OraArrivo == data);
                var tavoliDisponibili = _tavoloService.GetList().Where(t => t.NumeroPersone >= numeroPersone &&!disponibilitaData.Any(d => d.IdTavolo == t.Id)) .ToList();

                return tavoliDisponibili;
            }
        }
        public Prenotazione PrenotazioneCreateModel(PrenotazioneCreateModel prenotazioneCreateModel)
        {
            
            var Prenotazione = Create(prenotazioneCreateModel.IdCliente, prenotazioneCreateModel.IdTavolo, prenotazioneCreateModel.OraArrivo, prenotazioneCreateModel.OraLibero, prenotazioneCreateModel.NumeroPersone);
            
            return Prenotazione;

        }
    }
}


