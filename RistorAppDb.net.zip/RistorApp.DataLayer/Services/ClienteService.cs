﻿using RistorApp.DataLayer.Models;
using RistorApp.DataLayer.Stores;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RistorApp.DataLayer.Services
{
    public class ClienteService : IService<Cliente>
    {
        private ClienteStore _store;

        public ClienteService(ClienteStore clienteStore) 
        {
            _store = clienteStore;
        }

        public List<Cliente>? GetList()
        {
            return _store.GetList();
        }

        public Cliente Get(int id)
        {
            var clienteTrovato = _store.Get(id);
            if (clienteTrovato == null)
            {
                throw new Exception($"Cliente con id {id} non trovato");
            }
            return clienteTrovato;
        }

        public Cliente Create(string nome, string cognome, DateOnly? dataNascita)
        {
            var clienteDaAggiungere = new Cliente(nome, cognome, dataNascita);
            _store.Add(clienteDaAggiungere);
            return clienteDaAggiungere;
        }

        public bool Delete(Cliente cliente)
        { 
            return _store.Remove(cliente);
        }
        public bool Modifica(Cliente cliente, Cliente clienteSelezionato)
        {
            if(_store.Modify(cliente, clienteSelezionato))
            {
                return true;
            }
            else
            {              
                return false;
            }
        }
        public Cliente ClienteCreateModel(ClienteCreateModel clienteCreateModel)
        {
           
            var Cliente = Create(clienteCreateModel.Nome, clienteCreateModel.Cognome, DateOnly.FromDateTime(clienteCreateModel.DataNascita));
            return Cliente;

        }
    }
}
