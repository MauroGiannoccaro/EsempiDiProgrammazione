﻿using RistorApp.DataLayer.Models;
using RistorApp.DataLayer.Stores;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RistorApp.DataLayer.Services
{
    public class TavoloService : IService<Tavolo>
    {
        private TavoloStore _store;

        public TavoloService(TavoloStore tavoloStore)
        {
            _store = tavoloStore;
        }

 

            public List<Tavolo>? GetList()
            {
                return _store.GetList();
            }

            public Tavolo Get(int id)
            {
                var tavoloTrovato = _store.Get(id);
                if (tavoloTrovato == null)
                {
                    throw new Exception($"Tavolo con id {id} non trovato");
                }
                return tavoloTrovato;
            }

            public Tavolo Create(int numero, string posizione)
            {
          
                var tavoloDaAggiungere = new Tavolo(numero, posizione);
                _store.Add(tavoloDaAggiungere);
                return tavoloDaAggiungere;
            
            }

            public bool Delete(Tavolo tavolo)
            {
                return _store.Remove(tavolo);
            }
            public bool Modifica(Tavolo tavolo, Tavolo tavoloSelezionato)
            {
                if (_store.Modify(tavolo, tavoloSelezionato))
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            public Tavolo TavoloCreateModel (TavoloCreateModel tavoloCreateModel)
            {
            var tavoloDaAggiungere = Create(tavoloCreateModel.NumeroPersone, tavoloCreateModel.Posizione);
            return tavoloDaAggiungere;

            }

    }
}
