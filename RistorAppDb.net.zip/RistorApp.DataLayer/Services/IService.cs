﻿using RistorApp.DataLayer.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RistorApp.DataLayer.Services
{
    internal interface IService<T> where T : class 
    {
   
        public List<T>? GetList();
        public bool Delete(T t);
        public bool Modifica(T t, T r);
    }
}
