﻿
using System;
using System.Globalization;

namespace RistorApp.DataLayer.Stores
{
    public static class ValidationUtility
    {


        public static bool ControlloStringa(string nome)
        {

            bool controllo = true;

            foreach (char a in nome)
            {

                if (!char.IsLetter(a))
                {
                    Console.WriteLine("Nome non Corretto deve contenere caratteri alfanumerici");
                    controllo = false;
                    break;
                }

            }
            return controllo;

        }
        public static bool ControlloNumero(string num)
        {

            bool controllo = true;

            try
            {
                double.Parse(num);
            }

            catch (Exception)
            {
                Console.WriteLine("Inserire numero valido non inserire stringhe o spazi vuoti");
                controllo = false;
            }

            return controllo;
        }
        public static int CreaRandom()
        {
            Random random = new Random();
            int Grandom = random.Next(10000, 99999);
            return Grandom;

        }

        public static DateOnly? ReturnDate(string data)
        {
            string pattern = "dd-mm-yyyy";
            if (DateOnly.TryParseExact(data, pattern, null, DateTimeStyles.None, out DateOnly dataParsata))
            {
                return dataParsata;
            }
            else
            {
                return null;
            }
        }
        public static DateTime? ReturnDateTime(string data)
        {
            string pattern = "dd-mm-yyyy";
            if (DateTime.TryParseExact(data, pattern, null, DateTimeStyles.None, out DateTime dataParsata))
            {
                return dataParsata;
            }
            else
            {
                return null;
            }
        }
        public static bool CeckEmail(string email)
        {
            try
            {
                new System.Net.Mail.MailAddress(email.Trim());
                return true;
            }
            catch (Exception ex)
            {
                Console.WriteLine("L'email inserita non è valida");
                return false;
            }
        }
        public static bool ControlloGenere(string genere)
        {
            if (genere.ToUpper() == "M" || genere.ToUpper() == "F")
            {
                return true;
            }
            else { return false; }

        }
    }
}
