﻿using System;
using System.Globalization;


namespace RistorApp.DataLayer.Utils
{
    internal class ValidationUtilityApi
    {
        public static int CreaRandom()
        {
            Random random = new Random();
            int Grandom = random.Next(10000, 99999);
            return Grandom;

        }

        public static DateOnly? ReturnDate(string data)
        {
            string pattern = "dd-mm-yyyy";
            if (DateOnly.TryParseExact(data, pattern, null, DateTimeStyles.None, out DateOnly dataParsata))
            {
                return dataParsata;
            }
            else
            {
                return null;
            }
        }
        public static DateTime? ReturnDateTime(string data)
        {
            string pattern = "dd-mm-yyyy";
            if (DateTime.TryParseExact(data, pattern, null, DateTimeStyles.None, out DateTime dataParsata))
            {
                return dataParsata;
            }
            else
            {
                return null;
            }
        }
        public static bool CeckEmail(string email)
        {
            try
            {
                new System.Net.Mail.MailAddress(email.Trim());
                return true;
            }
            catch (Exception ex)
            {
                throw new Exception ("email non Valida");
                
            }
        }
        public static bool ControlloGenere(string genere)
        {
            if (genere.ToUpper() == "M" || genere.ToUpper() == "F")
            {
                return true;
            }
            else { return false; }

        }
    }
}
}
