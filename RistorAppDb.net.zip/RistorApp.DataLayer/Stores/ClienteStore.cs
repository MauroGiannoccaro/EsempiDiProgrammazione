﻿using RistorApp.DataLayer.Models;
using System;
using System.Collections.Generic;
using System.Linq; 

namespace RistorApp.DataLayer.Stores
{

    public class ClienteStore : IClienteStore<Cliente>
    {

        private List<Cliente> clienti ;

        public ClienteStore() 
        {

            clienti = new List<Cliente>();
        }
        int idCounter=1;
        public List<Cliente>? GetList()
        {
            return clienti;
        }
        public Cliente? Get(int id)
        {
            return clienti.Where(item => item.Id == id).FirstOrDefault();
        }
        public bool Add(Cliente cliente)
        {
            try
            {
                cliente.Id = idCounter++;
                clienti.Add(cliente);
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }
        public bool Remove(Cliente cliente)
        {
            try
            {
                clienti.Remove(cliente);
                return true;
            }
            catch (Exception ex)
            {              
                return false;
            }
        }
        public bool Modify(Cliente cliente, Cliente clienteSelezionato)
        {
            if (cliente.Cognome != "")
            {
                clienteSelezionato.Cognome = cliente.Cognome;
            }
            if (cliente.Nome != clienteSelezionato.Nome)
            {
                clienteSelezionato.Nome = cliente.Nome;
            }
            if (cliente.DataNascita != clienteSelezionato.DataNascita)
            {
                clienteSelezionato.DataNascita = cliente.DataNascita;
            }
           

            return true;
        }

    }
}
