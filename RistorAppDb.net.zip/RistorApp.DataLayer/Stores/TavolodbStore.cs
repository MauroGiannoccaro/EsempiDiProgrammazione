﻿using RistorApp.DataLayer.Models;
using System;
using System.Collections.Generic;
using System.Diagnostics.Metrics;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace RistorApp.DataLayer.Stores
{
    public class TavoloDbStore : ITavoloStore <Tavolo>
    {
        RistoranteDbContext _db;
        
        public TavoloDbStore(RistoranteDbContext ristoranteDbContext)
        {
           _db =ristoranteDbContext;
        }

        public List<Tavolo>? GetList()
        {
            return _db.Tavoli.ToList();
            ;
        }

        public Tavolo? Get(int id)
        {
           
            return _db.Tavoli.Where(item => item.Id == id).FirstOrDefault();
        }
        public bool Add(Tavolo tavolo)
        {          
            _db.Tavoli.Add(tavolo);
            _db.SaveChanges();
            return true;
        }
        public bool Remove(Tavolo tavolo)
        {
            _db.Tavoli.Remove(tavolo);
            _db.SaveChanges();
            return true;
        }
        public bool Modify(Tavolo tavolo, Tavolo tavoloSelezionato)
        {

            tavoloSelezionato = _db.Tavoli.Where(item=>item.Id == tavolo.Id).FirstOrDefault();
            if (tavoloSelezionato!=null)
            {
                if (tavolo.Posizione != tavoloSelezionato.Posizione)
                {
                    tavoloSelezionato.Posizione = tavolo.Posizione;
                }
                if (tavolo.NumeroPersone != tavoloSelezionato.NumeroPersone)
                {
                    tavoloSelezionato.NumeroPersone = tavolo.NumeroPersone;
                }
                _db.SaveChanges();
                return true;
            }
            else
            {
                return false;
            }
        }
    }
}
