﻿using RistorApp.DataLayer.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RistorApp.DataLayer.Stores
{
    public class PrenotazioneStore : IPrenotazioneStore<Prenotazione>
    {
      
        private List<Prenotazione> prenotazioni;
        public PrenotazioneStore()
        {
            prenotazioni=new List<Prenotazione>();
        }
        
        public List<Prenotazione>? GetList()
        {
            return prenotazioni;
        }
        public Prenotazione? Get(int id)
        {
            return prenotazioni.Where(item => item.Id == id).FirstOrDefault();
        }
        public bool Add(Prenotazione prenotazione)
        {
            prenotazioni.Add(prenotazione);
            return true;
        }
        public bool Remove(Prenotazione prenotazione)
        {
            prenotazioni.Remove(prenotazione);
            return true;
        }
        public bool Modify(Prenotazione prenotazione, Prenotazione prenotazioneSelezionata)
        {
            if (prenotazione.IdTavolo != prenotazioneSelezionata.IdTavolo)
            {
                prenotazioneSelezionata.IdTavolo = prenotazione.IdTavolo;
            }
            if (prenotazione.OraArrivo != prenotazioneSelezionata.OraArrivo)
            {
                prenotazioneSelezionata.OraArrivo = prenotazione.OraArrivo;
            }
            if (prenotazione.OraLibero != prenotazioneSelezionata.OraLibero)
            {
                prenotazioneSelezionata.OraLibero = prenotazione.OraLibero;
            }
            if (prenotazione.Note != prenotazione.Note )
            {
                prenotazioneSelezionata.Note = prenotazione.Note;
            }
            return true;
        }
    }
}
