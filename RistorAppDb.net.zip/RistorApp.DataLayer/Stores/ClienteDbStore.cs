﻿using Microsoft.EntityFrameworkCore;
using RistorApp.DataLayer.Models;
using System;
using System.Collections.Generic;
using System.Linq;

namespace RistorApp.DataLayer.Stores
{

    public class ClienteDbStore : IClienteStore<Cliente>
    {

        RistoranteDbContext _ristoranteDbContext;

        public ClienteDbStore(RistoranteDbContext ristoranteDbContext)
        {

            _ristoranteDbContext = ristoranteDbContext;
        }
        
        public List<Cliente>? GetList()
        {
            return _ristoranteDbContext.Clienti.ToList();
        }
        public Cliente? Get(int id)
        {
            return _ristoranteDbContext.Clienti.Where(item => item.Id == id).FirstOrDefault();
        }
        public bool Add(Cliente cliente)
        {
            try
            {

                _ristoranteDbContext.Add(cliente);
                _ristoranteDbContext.SaveChanges();
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }
        public bool Remove(Cliente cliente)
        {
            try
            {
                _ristoranteDbContext.Remove(cliente);
                _ristoranteDbContext.SaveChanges();
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
            ;
        }
        public bool Modify(Cliente cliente, Cliente clienteSelezionato)
        {
            clienteSelezionato= _ristoranteDbContext.Clienti.Where(item => item.Id == cliente.Id).FirstOrDefault();
            if (clienteSelezionato != null)
            {
                if (cliente.Cognome != clienteSelezionato.Cognome)
                {
                    clienteSelezionato.Cognome = cliente.Cognome;
                }
                if (cliente.Nome != clienteSelezionato.Nome)
                {
                    clienteSelezionato.Nome = cliente.Nome;
                }
                if (cliente.DataNascita != clienteSelezionato.DataNascita)
                {
                    clienteSelezionato.DataNascita = cliente.DataNascita;
                }
                _ristoranteDbContext.SaveChanges();
                return true;
            }
            else
            {
                return false;
            }
  
        }

    }
}
