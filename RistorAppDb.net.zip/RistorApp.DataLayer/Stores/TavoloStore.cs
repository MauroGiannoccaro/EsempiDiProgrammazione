﻿using RistorApp.DataLayer.Models;
using System;
using System.Collections.Generic;
using System.Diagnostics.Metrics;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace RistorApp.DataLayer.Stores
{
    public class TavoloStore : ITavoloStore<Tavolo>
    {
        private List<Tavolo> _Tavoli;
        int idCounter = 1;
        public TavoloStore()
        {
            _Tavoli = new List<Tavolo>();
        }

        public List<Tavolo>? GetList()
        {
            return _Tavoli;
        }
       
        public Tavolo? Get(int id)
        {
            return _Tavoli.Where(item => item.Id == id).FirstOrDefault();
        }
        public bool Add(Tavolo tavolo)
        {
            tavolo.Id = idCounter++;
            _Tavoli.Add(tavolo);
            return true;
        }
        public bool Remove(Tavolo tavolo)
        {
            _Tavoli.Remove(tavolo);
            return true;
        }
        public bool Modify(Tavolo tavolo, Tavolo tavoloSelezionato)
        {
           
            if (tavolo.Posizione != tavoloSelezionato.Posizione)
            {
                tavoloSelezionato.Posizione = tavolo.Posizione;
            }
            if (tavolo.NumeroPersone != tavoloSelezionato.NumeroPersone)
            {
                tavoloSelezionato.NumeroPersone = tavolo.NumeroPersone;
            }
           
            return true;
        }
    }
}
