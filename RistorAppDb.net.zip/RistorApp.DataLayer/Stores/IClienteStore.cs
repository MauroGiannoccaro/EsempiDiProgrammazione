﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RistorApp.DataLayer.Stores
{
    public interface IClienteStore<T> where T : class
    {
        public List<T>? GetList();
        public T? Get(int Id);
        public bool Add(T t);
        public bool Remove(T t);
    }
}
