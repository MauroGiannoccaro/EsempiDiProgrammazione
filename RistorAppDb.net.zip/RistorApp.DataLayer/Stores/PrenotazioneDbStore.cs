﻿using RistorApp.DataLayer.Models;

using System.Collections.Generic;
using System.Linq;


namespace RistorApp.DataLayer.Stores
{
    public class PrenotazioneDbStore : IPrenotazioneStore<Prenotazione>
    {

        RistoranteDbContext _ristoranteDbContext;
        public PrenotazioneDbStore(RistoranteDbContext ristoranteDbContext)
        {
            _ristoranteDbContext = ristoranteDbContext;
        }

        public List<Prenotazione>? GetList()
        {
            return _ristoranteDbContext.Prenotazioni.ToList();
        }
        public Prenotazione? Get(int id)
        {
            return _ristoranteDbContext.Prenotazioni.Where(item => item.Id == id).FirstOrDefault();
        }
        public bool Add(Prenotazione prenotazione)
        {
            _ristoranteDbContext.Prenotazioni.Add(prenotazione);
            _ristoranteDbContext.SaveChanges();
            return true;
        }
        public bool Remove(Prenotazione prenotazione)
        {
            _ristoranteDbContext.Prenotazioni.Remove(prenotazione);
            _ristoranteDbContext.SaveChanges();
            return true;
        }
        public bool Modify(Prenotazione prenotazione, Prenotazione prenotazioneSelezionata)
        {
            prenotazioneSelezionata = _ristoranteDbContext.Prenotazioni.Where(item=>item.Id == prenotazione.Id).
            if (prenotazione.IdTavolo != prenotazioneSelezionata.IdTavolo)
            {
                prenotazioneSelezionata.IdTavolo = prenotazione.IdTavolo;
            }
            if (prenotazione.OraArrivo != prenotazioneSelezionata.OraArrivo)
            {
                prenotazioneSelezionata.OraArrivo = prenotazione.OraArrivo;
            }
            if (prenotazione.OraLibero != prenotazioneSelezionata.OraLibero)
            {
                prenotazioneSelezionata.OraLibero = prenotazione.OraLibero;
            }
            if (prenotazione.Note != prenotazione.Note)
            {
                prenotazioneSelezionata.Note = prenotazione.Note;
            }
            _ristoranteDbContext.SaveChanges();
            return true;
        }
    }
}
