﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace RistorApp.DataLayer.Models
{
    public class TavoloCreateModel
    {

       
        [JsonIgnore]
        public int Id { get; set; }
        [Required]
        public int NumeroPersone { get; set; }
        [Required]
        public string Posizione { get; set; }
    }
}
