﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using RistorApp.DataLayer.Stores;



namespace RistorApp.DataLayer.Models
{
    [Table("Prenotazione")]
    public class Prenotazione
    {

    public Prenotazione(int idClienteFK, int idTavolo, DateTime? oraArrivo, DateTime? oraLibero, int numeroPersone, string note = "")
    {
        Id = ValidationUtility.CreaRandom();
        this.Note = note;
        this.IdCliente = idClienteFK;
        this.IdTavolo = idTavolo;
        this.OraLibero = oraLibero;
        this.OraArrivo = oraArrivo; 
        this.NumeroPersone=numeroPersone;
    }
        [Key]
        [Column ("Id")]
        public int Id { get; set; }
        [Column ("FK_Cliente")]
        [Required]
        public int IdCliente { get; set; }
        [ForeignKey(nameof(IdCliente))]
        public virtual Cliente FkClienteNavigation { get; set; }
        [Required]
        [Column("Fk_Tavolo")]
        public int IdTavolo { get; set; }
        [ForeignKey(nameof(IdTavolo))]
        public virtual Tavolo FKTavoloNavigazion { get; set; }
        [Required]
        [Column("NumeroPersone")]
        [MaxLength(20)]
        public int NumeroPersone{ get; set; }
        [Required]
        [Column("OraArrivo")]
        public DateTime? OraArrivo { get; set; }
        [Column("OraLibero")]
        public DateTime? OraLibero { get; set; }
        [Column("Note")]
        [MaxLength(100)]
        public string Note { get; set; }
    }
}
