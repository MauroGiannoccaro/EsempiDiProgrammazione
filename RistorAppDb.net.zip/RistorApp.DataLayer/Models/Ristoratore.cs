﻿using System.Text;
using System;


namespace RistorApp.DataLayer.Models
{
    public class Ristoratore
    {
            public Ristoratore(int id, string email, string nome, string cognome)
            {
                this.Email = email;
                this.Password = CreaPassword(nome);
                this.Nome = nome;
                this.Cognome = cognome;
                this.Id = id;
                if (nome == "admin")
                {
                    Console.WriteLine(@$"----------------------------------------------");
                    Console.WriteLine($"Admin creato Nome: admin ");
                    Console.WriteLine(@$"----------------------------------------------");
                    Console.WriteLine(@$"----------------------------------------------");
                    Console.WriteLine($"La tua Password è:admin ");
                    Console.WriteLine(@$"----------------------------------------------");
                }
            }
            public string Email { get; set; }
            private string Password { get; }
            public string Nome { get; set; }
            public string Cognome { get; set; }
            public int Id { get; set; }

            private string CreaPassword(string nome)
            {

                if (nome != "admin")
                {
                    Random random = new Random();
                    StringBuilder password = new StringBuilder();
                    string caratteri = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
                    string caratteriSpeciali = "!@#$%^&*()-_=+<>?";
                    for (int i = 0; i < 7; i++)
                    {
                        password.Append(caratteri[random.Next(caratteri.Length)]);

                    }
                    for (int j = 0; j < 3; j++)
                    {
                        password.Insert(random.Next(password.Length), caratteriSpeciali[random.Next(caratteriSpeciali.Length)]);
                    }
                    return password.ToString();
                }
                else
                {

                    return "admin";
                }
              ;

            }
            internal bool CeckPassword(string password)
            {
                return this.Password == password;
            }
        
    }
}
