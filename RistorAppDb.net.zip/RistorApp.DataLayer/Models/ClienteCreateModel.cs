﻿using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Text.Json.Serialization;

namespace RistorApp.DataLayer.Models
{
    
    public class ClienteCreateModel
    {

        [Key ]
        [JsonIgnore]
        public int Id { get; set; }
        [Required]
        [StringLength(15, ErrorMessage = "Il nome non può avere più di 15 caratteri.")]
        public string Nome { get; set; }
        [Required]
        [StringLength(15, ErrorMessage = "Il Cognome non può avere più di 15 caratteri.")]
        public string Cognome { get; set; }
        [DefaultValue(1999-01-01)]
        public DateTime DataNascita { get; set; }
    }
}