﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace RistorApp.DataLayer.Models
{
    [Table("cliente")]
    public class Cliente 
    {
        
        public Cliente(string nome, string cognome, DateOnly? dataNascita)
        {
            Nome = nome;
            Cognome = cognome;
            DataNascita = dataNascita;
        
        }
        [Key]
        [Column ("id")]      
        public int Id { get; set; }
        [Column("Nome")]
        [MaxLength(50)]
        public string Nome { get; set; }
        [Column("Cognome")]
        [MaxLength(50)]
        public string Cognome { get; set; }
        [Column("DataNascita")]
        public DateOnly? DataNascita { get; set; }
    }
}
