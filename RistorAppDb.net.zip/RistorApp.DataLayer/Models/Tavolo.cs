﻿
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace RistorApp.DataLayer.Models
{
    [Table("Tavolo")]
    public class Tavolo
    {
        
        public Tavolo(int numeroPersone, string posizione) 
        {
            NumeroPersone = numeroPersone;
            Posizione = posizione;
          
        }
        [Key]
        [Column("Id")]
        public int Id { get; set; }
        [Column("NumeroPersone")]
        [MaxLength(20)]
        public int NumeroPersone { get; set; }
        [Column ("Posizione")]
        [MaxLength(20)]
        public string Posizione { get; set; }
    }
}
