﻿using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Text.Json.Serialization;



namespace RistorApp.DataLayer.Models
{
    
    public class PrenotazioneCreateModel
    {

       
        [JsonIgnore]
        public int Id { get; set; }
        [Required]
        public int IdCliente { get; set; }
        [Required]
        public int IdTavolo { get; set; }
        [Required]
        public int NumeroPersone { get; set; }
        [Required]
        public DateTime OraArrivo { get; set; }
        
        public DateTime OraLibero { get; set; }
        [DefaultValue("")]
        public string Note { get; set; }
    }
}