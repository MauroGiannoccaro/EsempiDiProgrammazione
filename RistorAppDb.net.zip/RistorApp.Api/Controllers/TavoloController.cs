﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using RistorApp.DataLayer.Models;
using RistorApp.DataLayer.Services;
using System;
using System.Collections.Generic;

namespace RistorApp.Api.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class TavoloController : ControllerBase
    {
        private TavoloService _tavoloService;
        public TavoloController(TavoloService tavoloService)
        {
            _tavoloService = tavoloService;
        }
        /// <summary>
        /// Permette la visualizzazione dei clienti
        /// </summary>
        /// <returns>Un messaggio di conferma dell'operazione</returns>
        /// <response code="200">Ritorna un messaggio di conferma</response>
        /// <response code="500">Se si è verificato un errore non previsto</response>
        [HttpGet]
        [ProducesResponseType(typeof(List<Cliente>), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(string), StatusCodes.Status500InternalServerError)]
        public IActionResult Get()
        {
            try
            {
                return StatusCode(StatusCodes.Status200OK, _tavoloService.GetList());
            }

            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, "Errore Generico");
            }
        }
        /// <summary>
        /// Permette la visualizzazione del tavolo
        /// </summary>
        /// <returns>Un messaggio di conferma dell'operazione</returns>
        /// <response code="200">Ritorna un messaggio di conferma</response>
        /// <response code="500">Se si è verificato un errore non previsto</response>
        [HttpGet("Cerca Tavolo")]
        [ProducesResponseType(typeof(Cliente), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(string), StatusCodes.Status500InternalServerError)]
        public IActionResult Get(int id)
        {
            try
            {
                return StatusCode(StatusCodes.Status200OK, _tavoloService.Get(id));
            }

            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, "Errore Generico");
            }

        }
        /// <summary>
        /// Permette l'inserimento di un nuovo cliente
        /// </summary>
        /// <param numeroTavolo="clienteDaInserire">I dati del cliente da inserire</param>
        /// <param posizione="TavolodaInserire">Posizione Tavolo Inserire numero</param>
        /// <returns>Un messaggio di conferma dell'operazione</returns>
        /// <response code="200">Ritorna un messaggio di conferma</response>
        /// <response code="500">Se si è verificato un errore non previsto</response>
        [HttpPost]
        [ProducesResponseType (typeof(string), StatusCodes.Status200OK )]
        [ProducesResponseType (typeof(string), StatusCodes.Status500InternalServerError)]
        public IActionResult Insert(TavoloCreateModel tavoloCreateModel)
        {
            var esito = _tavoloService.TavoloCreateModel(tavoloCreateModel);
            try
            {
                if (esito != null)
                {
                    return StatusCode(StatusCodes.Status200OK, "Cliente Inserito");
                }
                else
                {
                    throw new Exception("Si è verificato un errore");
                }
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, "Errore Generico");
            }
        }
        /// <summary>
        /// Permette l'inserimento di un nuovo cliente
        /// </summary>
        /// <param IdnumeroTavolo="numeroTavolo">I dati del cliente da inserire</param>
        /// <returns>Un messaggio di conferma dell'operazione</returns>
        /// <response code="200">Ritorna un messaggio di conferma</response>
        /// <response code="500">Se si è verificato un errore non previsto</response>
        [HttpDelete ("{numeroTavolo}")]
        [ProducesResponseType(typeof(string), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(string), StatusCodes.Status500InternalServerError)]
        public IActionResult Delete([FromRoute]int numeroTavolo)
        {         
            var esito = _tavoloService.Delete(_tavoloService.Get(numeroTavolo));
            try
            {
                if (esito != null)
                {
                    return StatusCode(StatusCodes.Status200OK, "Inserito Correttamente");
                }
                else
                {
                    throw new Exception("Si è verificato un errore");
                }
            }
            catch (Exception ex) 
            {
                return StatusCode(StatusCodes.Status500InternalServerError, "Errore Generico");
            }
        }
    }
}
