﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using RistorApp.DataLayer.Models;
using RistorApp.DataLayer.Services;
using System;
using System.Collections.Generic;

namespace RistorApp.Api.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class PrenotazioneController : ControllerBase
    {
        private PrenotazioneService _prenotazioneService;
        public PrenotazioneController(PrenotazioneService prenotazioneService)
        {
            _prenotazioneService = prenotazioneService;
        }
        /// <summary>
        /// Permette la visualizzazione dei clienti
        /// </summary>
        /// <returns>Un messaggio di conferma dell'operazione</returns>
        /// <response code="200">Ritorna un messaggio di conferma</response>
        /// <response code="500">Se si è verificato un errore non previsto</response>
        [HttpGet]
        [ProducesResponseType(typeof(List<Cliente>), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(string), StatusCodes.Status500InternalServerError)]
        public IActionResult Get()
        {
            try
            {
                return StatusCode(StatusCodes.Status200OK, _prenotazioneService.GetList());
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, "Errore Generico");
            }
        }
        /// <summary>
        /// Permette l'inserimento di un nuovo cliente
        /// </summary>
        /// <param IdCliente="clienteDaInserire">I dati del cliente da inserire</param>
        /// <param idTavolo="TavolodaInserire">I dati del tavolo da inserire</param>
        /// <param dataOraArrivo="arrivoCliente">Data e ora arrivo da inserire</param>
        /// <param libero="TavoloLibero">Data e ora Tavolo libero da inserire</param>
        /// <returns>Un messaggio di conferma dell'operazione</returns>
        /// <response code="200">Ritorna un messaggio di conferma</response>
        /// <response code="500">Se si è verificato un errore non previsto</response>
        [HttpPost]
        [ProducesResponseType(typeof(Cliente), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(string), StatusCodes.Status500InternalServerError)]
        public IActionResult Insert(PrenotazioneCreateModel prenotazioneCreateModel)
        {
           
            try
            {
                //prenotazioneCreateModel.OraLibero =prenotazioneCreateModel.Value.AddHours(2);
                var esito = _prenotazioneService.PrenotazioneCreateModel(prenotazioneCreateModel);
                if (esito != null)
                {
                    return StatusCode(StatusCodes.Status200OK, "Inserimento ok");
                }
                else
                {
                    throw new Exception("Si è verificato un errore");
                }
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, "Errore Generico");
            }
        }
        /// <summary>
        /// Permette l'inserimento di un nuovo cliente
        /// </summary>
        /// <param IdCliente="clienteDaInserire">I dati del cliente da inserire</param>       
        /// <returns>Un messaggio di conferma dell'operazione</returns>
        /// <response code="200">Ritorna un messaggio di conferma</response>
        /// <response code="500">Se si è verificato un errore non previsto</response>
        [HttpDelete ("{idCliente}")]
        [ProducesResponseType(typeof(string), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(string), StatusCodes.Status500InternalServerError)]
        public IActionResult Delete([FromRoute]int IdCliente)
        {
       
            
            try
            {
                var esito = _prenotazioneService.Delete(_prenotazioneService.Get(IdCliente));
                if (esito != null)
                {
                    return StatusCode(StatusCodes.Status200OK, "Cliente inserito") ;
                }
                else
                {
                    throw new Exception("Si è verificato un errore");
                }
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, "Errore Generico");
            }
        }
        /// <summary>
        /// Permette l'inserimento di un nuovo cliente
        /// </summary>
        /// <param IdPrenotazione="IdPrenotazione">I dati della Prenotazione da inserire</param>
        /// <param IdCliente="clienteDaInserire">I dati del cliente da inserire</param>
        /// <param idTavolo="TavolodaInserire">I dati del tavolo da inserire</param>
        /// <param dataOraArrivo="arrivoCliente">Data e ora arrivo da inserire</param>
        /// <param libero="TavoloLibero">Data e ora Tavolo libero da inserire</param>
        /// <returns>Un messaggio di conferma dell'operazione</returns>
        /// <response code="200">Ritorna un messaggio di conferma</response>
        /// <response code="500">Se si è verificato un errore non previsto</response>
        [HttpPut]
        [ProducesResponseType(typeof(string), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(string), StatusCodes.Status500InternalServerError)]
        public IActionResult Update(int idPrenotazione,int IdCliente, int idTavolo, DateTime? dataOraArrivo, int numeroPersone)
        {
            try
            {
                DateTime? libero = dataOraArrivo.Value.AddHours(2);
                Prenotazione prenotazioneDaModificare= new Prenotazione(IdCliente, idTavolo, dataOraArrivo, libero, numeroPersone);
                var esito = _prenotazioneService.Modifica(prenotazioneDaModificare, _prenotazioneService.Get(idPrenotazione));
                if (esito != null)
                {
                    return StatusCode(StatusCodes.Status200OK, "Inserimento ok");
                }
                else
                {
                    throw new Exception("Si è verificato un errore");
                }
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, "Errore Generico");
            }
        }
    }
}
