﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using RistorApp.DataLayer.Models;
using RistorApp.DataLayer.Services;
using System;
using System.Collections.Generic;

namespace RistorApp.Api.Controllers
{
    [ApiController]
    [Route("[controller]")]
 
    public class ClienteController : ControllerBase
    {
        private ClienteService _clienteService;
        public ClienteController(ClienteService clienteService) 
        {
            _clienteService = clienteService;
        }
        /// <summary>
        /// Permette la visualizzazione dei clienti
        /// </summary>
        /// <returns>Un messaggio di conferma dell'operazione</returns>
        /// <response code="201">Ritorna un messaggio di conferma</response>
        /// <response code="500">Se si è verificato un errore non previsto</response>
        [HttpGet]
        [ProducesResponseType(typeof(List<Cliente>), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(string), StatusCodes.Status500InternalServerError)]
        public IActionResult Get()
        {
            try
            {
                return StatusCode(StatusCodes.Status200OK, _clienteService.GetList());
            }

            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, "Errore Generico");
            }

        }
        /// <summary>
        /// Permette la visualizzazione del cliente
        /// </summary>
        /// <returns>Un messaggio di conferma dell'operazione</returns>
        /// <response code="200">Ritorna un messaggio di conferma</response>
        /// <response code="500">Se si è verificato un errore non previsto</response>
        [HttpGet ("Cerca Cliente")]
        [ProducesResponseType(typeof(Cliente), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(string), StatusCodes.Status500InternalServerError)]
        public IActionResult GetCliente(int id)
        {
            try
            {
                return StatusCode(StatusCodes.Status200OK, _clienteService.Get(id));
            }

            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, "Errore Generico");
            }

        }
        /// <summary>
        /// Permette l'inserimento di un nuovo cliente
        /// </summary>
        /// <param nome="clienteDaInserire">I dati del cliente da inserire</param>
        /// <returns>Un messaggio di conferma dell'operazione</returns>
        /// <response code="201">Ritorna un messaggio di conferma</response>
        /// <response code="500">Se si è verificato un errore non previsto</response>
        [HttpPost]
        [ProducesResponseType(typeof(string), StatusCodes.Status201Created)]
        [ProducesResponseType(typeof(string), StatusCodes.Status500InternalServerError)]
        public IActionResult Insert(ClienteCreateModel cliente)
        {
            
            try
            {
                var esito = _clienteService.ClienteCreateModel(cliente);
                if (esito != null)
                {
                    return StatusCode(StatusCodes.Status201Created, "Cliente inserito");
                }
                else
                {
                    throw new Exception("Si è verificato un errore");
                }
            }
            catch (Exception ex){
                return StatusCode(StatusCodes.Status500InternalServerError, "Errore Generico");
            }
        }
        /// <summary>
        /// Permette l'inserimento di un nuovo cliente
        /// </summary>
        /// <param id="Id Cliente">Id Cliente</param>
        /// <returns>Un messaggio di conferma dell'operazione</returns>
        /// <response code="201">Ritorna un messaggio di conferma</response>
        /// <response code="500">Se si è verificato un errore non previsto</response>
        [HttpDelete ("{id}")]
        [ProducesResponseType(typeof(string), StatusCodes.Status201Created)]
        [ProducesResponseType(typeof(string), StatusCodes.Status500InternalServerError)]
        public IActionResult Delete([FromRoute]int id)
        {        
            
            try
            {
                var esito = _clienteService.Delete(_clienteService.Get(id));
                if (esito != null)
                {
                    return StatusCode(StatusCodes.Status201Created, "Cliente inserito");
                }
                else
                {
                    throw new Exception("Si è verificato un errore");
                }
            }
            catch(Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, "Errore Generico");
            }
        }
    }
}
