
using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using RistorApp.DataLayer.Services;
using RistorApp.DataLayer.Stores;
using System.IO;
using System.Reflection;
using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using RistorApp.DataLayer.Models;

namespace RistorApp.Api
{
    public class Program
    {
        public static void Main(string[] args)
        {
            var builder = WebApplication.CreateBuilder(args);

            // Add services to the container.

            builder.Services.AddControllers();
            // Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
            builder.Services.AddEndpointsApiExplorer();
            builder.Services.AddSwaggerGen(options =>
            {
                var xmlFilename = $"{Assembly.GetExecutingAssembly().GetName().Name}.xml";
                options.IncludeXmlComments(Path.Combine(AppContext.BaseDirectory, xmlFilename));
            });

            builder.Services.AddScoped<ClienteService>();
            builder.Services.AddSingleton<ClienteStore>();
            builder.Services.AddScoped<TavoloService>();
            builder.Services.AddSingleton<TavoloStore>();
            builder.Services.AddScoped<PrenotazioneService>();
            builder.Services.AddSingleton<PrenotazioneStore>();


            bool useDb = builder.Configuration.GetValue<bool>("UseDb");
            if (useDb)
            {
                builder.Services.AddScoped<IClienteStore<Cliente>, ClienteDbStore>();
                builder.Services.AddScoped<ITavoloStore<Tavolo>, TavoloDbStore>();
                builder.Services.AddScoped<IPrenotazioneStore<Prenotazione>, PrenotazioneDbStore>();
            }
            else
            {
                builder.Services.AddSingleton<IClienteStore<Cliente>, ClienteStore>();
                builder.Services.AddSingleton<ITavoloStore<Tavolo>, TavoloStore>();
                builder.Services.AddSingleton<IPrenotazioneStore<Prenotazione>, PrenotazioneStore>();
            }

            builder.Services.AddDbContext<DataLayer.RistoranteDbContext>(
               dbContextOptions => dbContextOptions
                   .UseMySql("server=localhost;port=3306;user=root;password=admin;database=ristorapp",
                       new MySqlServerVersion(new Version(8, 0, 37)))
           );
            var app = builder.Build();

            // Configure the HTTP request pipeline.
            if (app.Environment.IsDevelopment())
            {
                app.UseSwagger();
                app.UseSwaggerUI();
            }

            app.UseHttpsRedirection();

            app.UseAuthorization();


            app.MapControllers();

            app.Run();
        }
    }
}
