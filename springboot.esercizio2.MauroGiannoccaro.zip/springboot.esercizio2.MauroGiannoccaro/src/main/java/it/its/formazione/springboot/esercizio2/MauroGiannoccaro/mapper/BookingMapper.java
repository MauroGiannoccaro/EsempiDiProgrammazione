package it.its.formazione.springboot.esercizio2.MauroGiannoccaro.mapper;




import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import it.its.formazione.springboot.esercizio2.MauroGiannoccaro.entity.BookingEntity;
import it.its.formazione.springboot.esercizio2.MauroGiannoccaro.model.BookingDTO;



@Mapper (componentModel = "spring")
public interface BookingMapper {
    BookingMapper INSTANCE = Mappers.getMapper(BookingMapper.class);

    
    @Mapping(source = "guest", target = "guestName")
    @Mapping(source = "roomNumber", target = "roomNumber")
    @Mapping(source = "checkInDate", target = "checkInDate")
    @Mapping(source = "checkOutDate", target = "checkOutDate")
    @Mapping(source = "totalPrice", target = "totalPrice")
    BookingDTO toDTO(BookingEntity bookingEntity);


    @Mapping(source = "guestName", target = "guest")
    @Mapping(source = "roomNumber", target = "roomNumber")
    @Mapping(source = "checkInDate", target = "checkInDate")
    @Mapping(source = "checkOutDate", target = "checkOutDate")
    @Mapping(source = "totalPrice", target = "totalPrice")
    BookingEntity toEntity(BookingDTO bookingDTO);
}