package it.its.formazione.springboot.esercizio2.MauroGiannoccaro.controller;




import java.util.List;

import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import org.springframework.web.bind.annotation.RestController;
import org.slf4j.Logger;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.parameters.RequestBody;
import it.its.formazione.springboot.esercizio2.MauroGiannoccaro.api.BookingsApi;
import it.its.formazione.springboot.esercizio2.MauroGiannoccaro.entity.BookingEntity;
import it.its.formazione.springboot.esercizio2.MauroGiannoccaro.mapper.BookingMapper;
import it.its.formazione.springboot.esercizio2.MauroGiannoccaro.model.BookingDTO;
import it.its.formazione.springboot.esercizio2.MauroGiannoccaro.service.BookingService;
import jakarta.validation.Valid;

@RestController
public class BookingController implements BookingsApi {
    Logger logger = LoggerFactory.getLogger(BookingController.class);

    @Autowired
    private BookingService bookingService;

    @Autowired
    private BookingMapper bookingMapper;

    @GetMapping("/test")
    public ResponseEntity<String> test() {
        return ResponseEntity.ok("Test endpoint");
    }

    @Override
    public ResponseEntity<BookingDTO> createBooking(
            @Parameter(name = "BookingDTO", description = "", required = true) @Valid @RequestBody BookingDTO bookingDTO) {
        logger.info("Creazione Appuntamenti");
        BookingEntity bookingEntity = bookingMapper.toEntity(bookingDTO);
        BookingEntity createdBooking = bookingService.createBooking(bookingEntity);
        BookingDTO createdBookingDTO = bookingMapper.toDTO(createdBooking);
        logger.info("Appuntamento creato con successo");
        return new ResponseEntity<>(createdBookingDTO, HttpStatus.CREATED);
    }

    @Override
    public ResponseEntity<List<BookingDTO>> getAllBookings(

    ) {
        List<BookingDTO> bookingDto = bookingService.getAllBookings();
        
        return new ResponseEntity<>(bookingDto, HttpStatus.OK);
    }

    @Override
    public ResponseEntity<BookingDTO> getBookingById(
            @Parameter(name = "id", description = "", required = true, in = ParameterIn.PATH) @PathVariable("id") Integer id) {
        logger.info("recupero appuntamento con successo");
        BookingEntity booking = bookingService.getBookingById(id);
        if (booking != null) {
            return new ResponseEntity<>(bookingMapper.toDTO(booking), HttpStatus.OK);
        }
        logger.info("Appuntamento recuperato con successo");
        return new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }

    @Override
    public ResponseEntity<BookingDTO> updateBooking(
            @Parameter(name = "id", description = "", required = true, in = ParameterIn.PATH) @PathVariable("id") Integer id,
            @Parameter(name = "BookingDTO", description = "", required = true) @Valid @RequestBody BookingDTO bookingDTO) {
        logger.info("Appuntamento in aggiornamento");
        BookingEntity bookingEntity = bookingMapper.toEntity(bookingDTO);
        BookingEntity updatedBooking = bookingService.updateBooking(id, bookingEntity);
        if (updatedBooking != null) {
            return new ResponseEntity<>(bookingMapper.toDTO(updatedBooking), HttpStatus.OK);
        }
        logger.info("Appuntamento aggiornato con successo");
        return new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }

    @Override
    public ResponseEntity<Void> deleteBooking(
            @Parameter(name = "id", description = "", required = true, in = ParameterIn.PATH) @PathVariable("id") Integer id) {
        logger.info("Appuntamento in cancellazione");
        bookingService.deleteBooking(id);
        logger.info("Appuntamento cancellato con successo");
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);

    }

}
