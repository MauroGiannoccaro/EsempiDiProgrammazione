package it.its.formazione.springboot.esercizio2.MauroGiannoccaro.service;



import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.util.Streamable;
import org.springframework.stereotype.Service;

import it.its.formazione.springboot.esercizio2.MauroGiannoccaro.entity.BookingEntity;
import it.its.formazione.springboot.esercizio2.MauroGiannoccaro.mapper.BookingMapper;
import it.its.formazione.springboot.esercizio2.MauroGiannoccaro.model.BookingDTO;
import it.its.formazione.springboot.esercizio2.MauroGiannoccaro.repository.BookingRepository;

@Service
public class BookingServiceImpl implements BookingService {

    @Autowired
    private BookingRepository bookingRepository;
    @Autowired
    BookingMapper mapper;

    @Override
    public BookingEntity createBooking(BookingEntity booking) {
        return bookingRepository.save(booking);
    }

    @Override
    public List<BookingDTO> getAllBookings() {
        List<BookingDTO> listaBooking= Streamable.of(bookingRepository.findAll())
            .map(booking -> mapper.toDTO(booking))
            .toList();
            return  listaBooking;
    }

    @Override
    public BookingEntity getBookingById(Integer id) {
        Optional<BookingEntity> booking = bookingRepository.findById(id);
        return booking.orElse(null);  
    }

    @Override
    public BookingEntity updateBooking(Integer id, BookingEntity booking) {
        if (bookingRepository.existsById(id)) {
            booking.setId(id);  
            return bookingRepository.save(booking);
        }
        return null;  
    }

    @Override
    public void deleteBooking(Integer id) {
        bookingRepository.deleteById(id);
    }
}
