package it.its.formazione.springboot.esercizio2.MauroGiannoccaro.service;



import java.util.List;

import it.its.formazione.springboot.esercizio2.MauroGiannoccaro.entity.BookingEntity;
import it.its.formazione.springboot.esercizio2.MauroGiannoccaro.model.BookingDTO;




    public interface BookingService {

    BookingEntity createBooking(BookingEntity booking);

    List<BookingDTO> getAllBookings();

    BookingEntity getBookingById(Integer id);

    BookingEntity updateBooking(Integer id, BookingEntity booking);
    
    void deleteBooking(Integer id);
}

