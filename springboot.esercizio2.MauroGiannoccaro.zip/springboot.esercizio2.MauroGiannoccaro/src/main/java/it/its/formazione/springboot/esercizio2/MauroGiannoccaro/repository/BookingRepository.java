package it.its.formazione.springboot.esercizio2.MauroGiannoccaro.repository;



import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import it.its.formazione.springboot.esercizio2.MauroGiannoccaro.entity.BookingEntity;


    @Repository
public interface BookingRepository extends CrudRepository<BookingEntity, Integer> {
    
}

