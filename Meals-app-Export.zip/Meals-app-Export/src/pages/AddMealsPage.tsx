
import AddMealsFormComponent from "../components/AddMealsFormComponent"

const AddMeals = () => {
  return (
    <AddMealsFormComponent />
  )
}

export default AddMeals
